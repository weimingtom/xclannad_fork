
#if defined(PSP)
#include "config_PSP.h"
#elif defined(WINCE)
#include "config_WinCE.h"
#elif defined(IPHONE)
#include "config_iPhone.h"
#endif
