/*
	�t�@�C������ : CFMDrawSprocket.h
	���e         : Mac OS 9.x / Mac OS X ���p CFM�i PEF �o�C�i�� �j�A�v���P�[�V�����p
				   Carbon DrawSprocket API
	�����     : Mac OS 9.x : DrawSprocket Version 1.0  �ȍ~�i���� : DrawSprocket Version 1.7  �ȍ~�j
				                CarbonLib 1.2 �ȍ~
				   Mac OS X   : DrawSprocket Version 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~ �j
				                CFM�i PEF �o�C�i�� �j�A�v���P�[�V����
	���l         : 1. Mach-O �o�C�i���A�v���P�[�V�����ł͕s�v
				   2. Mac OS 9.x �ł� DrawSprocketLib �̃o�[�W�����ɂ���Ďg�p�s�̊֐������݂���
*/
#ifndef __CFMDRAWSPROCKET__
#define __CFMDRAWSPROCKET__

#if TARGET_API_MAC_CARBON && TARGET_RT_MAC_CFM

#ifndef __CARBON__
#include <Carbon.h>
#endif


#if PRAGMA_ONCE
#pragma once
#endif

#ifdef __cplusplus
extern "C" {
#endif

#if PRAGMA_IMPORT
#pragma import on
#endif

#if PRAGMA_STRUCT_ALIGN
    #pragma options align=power
#elif PRAGMA_STRUCT_PACKPUSH
    #pragma pack(push, 2)
#elif PRAGMA_STRUCT_PACK
    #pragma pack(2)
#endif

#if PRAGMA_ENUM_ALWAYSINT
    #if defined(__fourbyteints__) && !__fourbyteints__ 
        #define __DRAWSPROCKET__RESTORE_TWOBYTEINTS
        #pragma fourbyteints on
    #endif
    #pragma enumsalwaysint on
#elif PRAGMA_ENUM_OPTIONS
    #pragma option enum=int
#elif PRAGMA_ENUM_PACK
    #if __option(pack_enums)
        #define __DRAWSPROCKET__RESTORE_PACKED_ENUMS
        #pragma options(!pack_enums)
    #endif
#endif

/*
********************************************************************************
    DrawSprocket �萔
********************************************************************************
*/

enum DSpDepthMask
{
  kDSpDepthMask_1                = 1 << 0,
  kDSpDepthMask_2                = 1 << 1,
  kDSpDepthMask_4                = 1 << 2,
  kDSpDepthMask_8                = 1 << 3,
  kDSpDepthMask_16               = 1 << 4,
  kDSpDepthMask_32               = 1 << 5,
  kDSpDepthMask_All              = -1L
};
typedef enum DSpDepthMask DSpDepthMask;


enum DSpColorNeeds
{
  kDSpColorNeeds_DontCare        = 0L,
  kDSpColorNeeds_Request         = 1L,
  kDSpColorNeeds_Require         = 2L
};
typedef enum DSpColorNeeds DSpColorNeeds;


enum DSpContextState
{
  kDSpContextState_Active        = 0L,
  kDSpContextState_Paused        = 1L,
  kDSpContextState_Inactive      = 2L
};
typedef enum DSpContextState DSpContextState;


enum DSpContextOption
{
  kDSpContextOption_PageFlip     = 1 << 1,
  kDSpContextOption_DontSyncVBL  = 1 << 2,
  kDSpContextOption_Stereoscopic = 1 << 3
};
typedef enum DSpContextOption DSpContextOption;


enum DSpBufferKind
{
  kDSpBufferKind_Normal          = 0
};
typedef enum DSpBufferKind DSpBufferKind;


/*
********************************************************************************
    DrawSprocket �f�[�^�^
********************************************************************************
*/
typedef struct OpaqueDSpContextReference*			DSpContextReference;
typedef const struct OpaqueDSpContextReference*		DSpContextReferenceConst;
#define kDSpEveryContext							((DSpContextReference)NULL)
typedef CALLBACK_API_C( Boolean , DSpCallbackProcPtr )(DSpContextReference inContext, void *inRefCon);
typedef TVECTOR_UPP_TYPE(DSpCallbackProcPtr)		DSpCallbackUPP;

struct DSpContextAttributes
{
  Fixed					frequency;
  UInt32				displayWidth;
  UInt32				displayHeight;
  UInt32				reserved1;
  UInt32				reserved2;
  UInt32				colorNeeds;
  CTabHandle			colorTable;
  OptionBits			contextOptions;
  OptionBits			backBufferDepthMask;
  OptionBits			displayDepthMask;
  UInt32				backBufferBestDepth;
  UInt32				displayBestDepth;
  UInt32				pageCount;
  char					filler[3];
  Boolean				gameMustConfirmSwitch;
  UInt32				reserved3[4];
};
typedef struct DSpContextAttributes     DSpContextAttributes;
typedef DSpContextAttributes *          DSpContextAttributesPtr;


/*
********************************************************************************
    Carbon DrawSprocket API
********************************************************************************
*/
/*DSpCallbackUPP �C���^�[�t�F�[�X*/
/*
  CarbonLib �p NewDSpCallbackUPP
  �����
  Mac OS 8.1 �` Mac OS 9.x : ���p�\
  Mac OS X                 : ���p�\
  CarbonLib                : 1.2 �ȍ~
*/
extern DSpCallbackUPP							NewDSpCallbackUPP(DSpCallbackProcPtr	userRoutine);

/*
  CarbonLib �p DisposeDSpCallbackUPP
  �����
  Mac OS 8.1 �` Mac OS 9.x : ���p�\
  Mac OS X                 : ���p�\
  CarbonLib                : 1.2 �ȍ~
*/
extern void										DisposeDSpCallbackUPP(DSpCallbackUPP	userUPP);

/*
  CarbonLib �p InvokeDSpCallbackUPP
  �����
  Mac OS 8.1 �` Mac OS 9.x : ���p�\
  Mac OS X                 : ���p�\
  CarbonLib                : 1.2 �ȍ~
*/
extern Boolean									InvokeDSpCallbackUPP(DSpContextReference	inContext,
																	 void*					inRefCon,
																	 DSpCallbackUPP			userUPP);

/*DSp �I�u�W�F�N�g�C���^�[�t�F�[�X*/
/*
  CarbonLib �p DSpStartup
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.0 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpStartup(void);

/*
  CarbonLib �p DSpShutdown
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.0 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpShutdown(void);

/*
  CarbonLib �p DSpGetVersion
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.7 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern NumVersion								DSpGetVersion(void);

/*
  CarbonLib �p DSpGetMouse
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.0 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpGetMouse(Point*	outGlobalPoint);

/*
  CarbonLib �p DSpGetCurrentContext
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.7 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpGetCurrentContext(DisplayIDType			inDisplayID,
																	 DSpContextReference*	outContext);

/*
  CarbonLib �p DSpGetFirstContext
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.0 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpGetFirstContext(DisplayIDType			inDisplayID,
																   DSpContextReference*		outContext);

/*
  CarbonLib �p DSpGetNextContext
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.0 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpGetNextContext(DSpContextReference	inCurrentContext,
																  DSpContextReference*	outContext);

/*
  CarbonLib �p DSpSetDebugMode
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.0 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpSetDebugMode(Boolean	inDebugMode);

/*
  CarbonLib �p DSpSetBlankingColor
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.0 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpSetBlankingColor(const RGBColor*	inRGBColor);

/*
  CarbonLib �p DSpProcessEvent
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.0 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpProcessEvent(EventRecord*	inEvent,
																Boolean*		outEventWasProcessed);

/*
  CarbonLib �p DSpFindContextFromPoint
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.0 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpFindContextFromPoint(Point					inGlobalPoint,
																		DSpContextReference*	outContext);

/*
  CarbonLib �p DSpFindBestContext
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.0 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpFindBestContext(DSpContextAttributesPtr	inDesiredAttributes,
																   DSpContextReference*		outContext);

/*
  CarbonLib �p DSpFindBestContextOnDisplayID
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.7 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpFindBestContextOnDisplayID(DSpContextAttributesPtr	inDesiredAttributes,
																			  DSpContextReference*		outContext,
																			  DisplayIDType				inDisplayID);

/*DSpContext �I�u�W�F�N�g�C���^�[�t�F�[�X*/
/*
  CarbonLib �p DSpContext_Release
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.0 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpContext_Release(DSpContextReference	inContext);

/*
  CarbonLib �p DSpContext_Dispose
  �����
  Mac OS 8.1 �` Mac OS 9.x : ���p�s��
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpContext_Dispose(DSpContextReference	inContext);

/*
  CarbonLib �p DSpContext_GetMonitorFrequency
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.0 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpContext_GetMonitorFrequency(DSpContextReferenceConst	inContext,
																			   Fixed*					outFrequency);

/*
  CarbonLib �p DSpContext_GetAttributes
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.0 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpContext_GetAttributes(DSpContextReferenceConst	inContext,
																		 DSpContextAttributesPtr	outAttributes);

/*
  CarbonLib �p DSpContext_Reserve
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.0 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpContext_Reserve(DSpContextReference		inContext,
																   DSpContextAttributesPtr	inDesiredAttributes);

/*
  CarbonLib �p DSpContext_Reserve
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.0 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpContext_GetCLUTEntries(DSpContextReferenceConst	inContext,
																		  ColorSpec*				outEntries,
																		  UInt16					inStartingEntry,
																		  UInt16					inLastEntry);

/*
  CarbonLib �p DSpContext_Reserve
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.0 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpContext_SetCLUTEntries(DSpContextReference	inContext,
																		  const ColorSpec*		inEntries,
																		  UInt16				inStartingEntry,
																		  UInt16				inLastEntry);

/*
  CarbonLib �p DSpContext_GetState
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.0 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpContext_GetState(DSpContextReferenceConst	inContext,
																	DSpContextState*			outState);

/*
  CarbonLib �p DSpContext_SetState
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.0 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpContext_SetState(DSpContextReference	inContext,
																	DSpContextState		inState);

/*
  CarbonLib �p DSpContext_IsBusy
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.0 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpContext_IsBusy(DSpContextReference	inContext,
								 								  Boolean*				outBusyFlag);

/*
  CarbonLib �p DSpContext_GetDisplayID
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.0 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpContext_GetDisplayID(DSpContextReferenceConst	inContext,
																		DisplayIDType*				outDisplayID);

/*
  CarbonLib �p DSpContext_GetFrontBuffer
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.1 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpContext_GetFrontBuffer(DSpContextReferenceConst	inContext,
																		  CGrafPtr*					outFrontBuffer);

/*
  CarbonLib �p DSpContext_GetBackBuffer
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.0 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpContext_GetBackBuffer(DSpContextReference	inContext,
																		 DSpBufferKind			inBufferKind,
																		 CGrafPtr*				outBackBuffer);

/*
  CarbonLib �p DSpContext_GlobalToLocal
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.0 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpContext_GlobalToLocal(DSpContextReference	inContext,
																		 Point*					ioPoint);

/*
  CarbonLib �p DSpContext_LocalToGlobal
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.0 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpContext_LocalToGlobal(DSpContextReference	inContext,
																		 Point*					ioPoint);

/*
  CarbonLib �p DSpContext_FadeGammaIn
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.0 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpContext_FadeGammaIn(DSpContextReference	inContext,
																	   RGBColor*			inZeroIntensityColor);

/*
  CarbonLib �p DSpContext_FadeGammaOut
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.0 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpContext_FadeGammaOut(DSpContextReference	inContext,
																		RGBColor*			inZeroIntensityColor);

/*
  CarbonLib �p DSpContext_FadeGamma
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.0 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpContext_FadeGamma(DSpContextReference	inContext,
																	 SInt32					inPercentOfOriginalIntensity,
																	 RGBColor*				inZeroIntensityColor);

/*
  CarbonLib �p DSpContext_Queue
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.7 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpContext_Queue(DSpContextReference		inParentContext,
																 DSpContextReference		inChildContext,
																 DSpContextAttributesPtr	inDesiredAttributes);

/*
  CarbonLib �p DSpContext_Switch
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.7 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpContext_Switch(DSpContextReference	inOldContext,
																  DSpContextReference	inNewContext);

/*
  CarbonLib �p DSpContext_SwapBuffers
  �����
  Mac OS 8.1 �` Mac OS 9.x : DrawSprocketLib 1.0 �ȍ~
  Mac OS X                 : DrawSprocket.framework 1.9.9 �ȍ~�i Mac OS X 10.0.3 �ȍ~�j
  CarbonLib                : 1.2 �ȍ~
*/
extern OSStatus									DSpContext_SwapBuffers(DSpContextReference	inContext,
																	   DSpCallbackUPP		inBusyProc,
																	   void*				inUserRefCon);


#if PRAGMA_ENUM_ALWAYSINT
    #pragma enumsalwaysint reset
    #ifdef __DRAWSPROCKET__RESTORE_TWOBYTEINTS
        #pragma fourbyteints off
    #endif
#elif PRAGMA_ENUM_OPTIONS
    #pragma option enum=reset
#elif defined(__DRAWSPROCKET__RESTORE_PACKED_ENUMS)
    #pragma options(pack_enums)
#endif

#if PRAGMA_STRUCT_ALIGN
    #pragma options align=reset
#elif PRAGMA_STRUCT_PACKPUSH
    #pragma pack(pop)
#elif PRAGMA_STRUCT_PACK
    #pragma pack()
#endif

#ifdef PRAGMA_IMPORT_OFF
#pragma import off
#elif PRAGMA_IMPORT
#pragma import reset
#endif

#ifdef __cplusplus
}
#endif


#elif TARGET_RT_MAC_MACHO

/*Mach-O �o�C�i���A�v���P�[�V�������J������ꍇ*/
#ifndef __DRAWSPROCKET__
#include <DrawSprocket/DrawSprocket.h>
#endif

#else

/*Classic �A�v���P�[�V�������J������ꍇ*/
#ifndef __DRAWSPROCKET__
#include <DrawSprocket.h>
#endif

#endif	/*TARGET_API_MAC_CARBON && TARGET_RT_MAC_CFM*/

#endif	/*__CFMDRAWSPROCKET__*/