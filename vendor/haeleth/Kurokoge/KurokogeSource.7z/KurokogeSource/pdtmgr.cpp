/*=======================================================================
  AVG32-like scriptor for Macintosh
  Copyright 2000, K.Takagi(Kenjo)

  pdtmgr.cpp
    PDT�`��֘A

  �ύX����
      2005/03 : P.Jolly
                ���m�N���[���ύX�̃o�C�A�X�𒼂��܂����B���͂܂��{����
                AVG32�Ɣ�ׂ�Δ����ɈႤ���A��������ł��������m��܂���B
      2005/12 : P.Jolly
                �G�t�F�N�g���}�X�N��t���O���g���悤�ɂ��܂����B

=======================================================================*/

#include "pdtmgr.h"
#include "system.h"
#include "pdtbuf.h"
#include "pdtfile.h"
#include "common.h"
#include "debug.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

/************************************************************************
  class PDTMGR
    PDT�`��}�l�[�W��
************************************************************************/

PDTMGR::PDTMGR(SYSTEM* s, PDTBUFFER* pdtb, unsigned char* b)
{
	int i;
    for (i=0; i<MAXPDT; i++) pdt[i]=0;
	sys = s;
	pdt[0] = pdtb;
	pdt[0]->SetBuffer(b);

	temppdt = 0;
	getputpdt = 0;
	lines = 0;
};

PDTMGR::~PDTMGR(void)
{
	int i;
	for (i=0; i<MAXPDT; i++) delete pdt[i];
};


/* -------------------------------------------------------------------
  �`�惋�[�`���B
------------------------------------------------------------------- */
inline void PDT_Pixel(unsigned char* s, unsigned char* d, int maskc)
{
	unsigned int temp, m;

	if ( !maskc ) return;
	m = 256-maskc;

	temp = s[0]+((m*d[0])>>8);
	if ( temp>0xff ) d[0] = 0xff; else d[0] = (unsigned char)temp;
	temp = s[1]+((m*d[1])>>8);
	if ( temp>0xff ) d[1] = 0xff; else d[1] = (unsigned char)temp;
	temp = s[2]+((m*d[2])>>8);
	if ( temp>0xff ) d[2] = 0xff; else d[2] = (unsigned char)temp;
}


inline void PDT_PixelDst(unsigned char* s, unsigned char* d, int maskc)
{
	unsigned int temp, m;

	if ( !maskc ) {
		d[0] = s[0];
		d[1] = s[1];
		d[2] = s[2];
	} else {
		m = 256-maskc;
		temp = d[0]+((m*s[0])>>8);
		if ( temp>0xff ) d[0] = 0xff; else d[0] = (unsigned char)temp;
		temp = d[1]+((m*s[1])>>8);
		if ( temp>0xff ) d[1] = 0xff; else d[1] = (unsigned char)temp;
		temp = d[2]+((m*s[2])>>8);
		if ( temp>0xff ) d[2] = 0xff; else d[2] = (unsigned char)temp;
	}
}


inline void PDT_FadePixel(unsigned char* s, unsigned char* t, unsigned char* d, int maskc, int fade)
{
	unsigned int temp, m;

	if ( !maskc ) return;
	m = 256-maskc;

	temp = s[0]+((m*t[0])>>8);
	if ( temp>0xff ) temp = 0xff;
	temp = (( temp*fade + (256-fade)*t[0] )>>8);
	d[0] = (unsigned char)temp;
	temp = s[1]+((m*t[1])>>8);
	if ( temp>0xff ) temp = 0xff;
	temp = (( temp*fade + (256-fade)*t[1] )>>8);
	d[1] = (unsigned char)temp;
	temp = s[2]+((m*t[2])>>8);
	if ( temp>0xff ) temp = 0xff;
	temp = (( temp*fade + (256-fade)*t[2] )>>8);
	d[2] = (unsigned char)temp;
}


inline void PDT_FadePixelDst(unsigned char* s, unsigned char* t, unsigned char* d, int maskc, int fade)
{
	unsigned int temp, m;

	if ( !maskc ) {
		d[0] = s[0];
		d[1] = s[1];
		d[2] = s[2];
	} else {
		m = 256-maskc;
		temp = t[0]+((m*s[0])>>8);
		if ( temp>0xff ) temp = 0xff;
		temp = (( temp*fade + (256-fade)*s[0] )>>8);
		d[0] = (unsigned char)temp;
		temp = t[1]+((m*s[1])>>8);
		if ( temp>0xff ) temp = 0xff;
		temp = (( temp*fade + (256-fade)*s[1] )>>8);
		d[1] = (unsigned char)temp;
		temp = t[2]+((m*s[2])>>8);
		if ( temp>0xff ) temp = 0xff;
		temp = (( temp*fade + (256-fade)*s[2] )>>8);
		d[2] = (unsigned char)temp;
	}
}


void PDTMGR::Get(int sx1, int sy1, int sx2, int sy2, int srcpdt)
{
	unsigned char *srcbuf, *dstbuf, *dst, *src;
	int srcbpl, srcbpp, dstbpl, x, y, temp;
	
	if ( srcpdt<0 ) srcpdt = 0;
	if ( srcpdt>MAXPDT ) {
		dprintf("*************** Error in PDT# Src:%d\n", srcpdt);
		return;
	}
	if ( !pdt[srcpdt] ) return;		// ���S�̂���
	
	if ( sx1>sx2          ) { temp=sx1; sx1=sx2; sx2=temp; }
	if ( sy1>sy2          ) { temp=sy1; sx1=sy2; sy2=temp; }
	if ( sx1<0            ) { sx1=0; }
	if ( sy1<0            ) { sy1=0; }
	if ( sx2>639          ) { sx2=639; }
	if ( sy2>479          ) { sy2=479; }

	if ( getputpdt ) {
		delete getputpdt;
		getputpdt = 0;
	}
	dstbpl = (sx2-sx1+1)*3;
	getputpdt = new PDTBUFFER(sx2-sx1+1, sy2-sy1+1, 3, dstbpl, true);
	if ( getputpdt ) {
		srcbpl = pdt[srcpdt]->GetBPL();
		srcbpp = pdt[srcpdt]->GetBPP();
		srcbuf = pdt[srcpdt]->GetBuffer();
		if ( !srcpdt ) srcbuf++;
		dstbuf = getputpdt->GetBuffer();

		srcbuf += sy1*srcbpl+(sx1*srcbpp);
		for (y=sy1; y<=sy2; y++) {
			src = srcbuf;
			dst = dstbuf;
			for (x=sx1; x<=sx2; x++) {
				dst[0] = src[0];
				dst[1] = src[1];
				dst[2] = src[2];
				src += srcbpp;
				dst += 3;
			}
			srcbuf += srcbpl;
			dstbuf += dstbpl;
		}
	}
};


void PDTMGR::Put(int dx, int dy, int dstpdt)
{
	unsigned char *srcbuf, *dstbuf, *dst, *src;
	int srcbpl, dstbpp, dstbpl, x, y, update = 1;
	int sx1, sx2, sy1, sy2;

	if ( !getputpdt ) return;
	if ( dstpdt<0 ) { dstpdt = 0; update = 0; }
	if ( dstpdt>MAXPDT ) {
		dprintf("*************** Error in PDT# Dst:%d\n", dstpdt);
		return;
	}
	if ( !pdt[dstpdt] ) pdt[dstpdt] = new PDTBUFFER(640, 480, 3, 640*3, true);
	if ( !pdt[dstpdt] ) return;		// ���S�̂���

	sx1 = 0;
	sy1 = 0;
	sx2 = getputpdt->GetSizeX()-1;
	sy2 = getputpdt->GetSizeY()-1;
	if ( dx<0             ) { sx1-=dx; dx=0; }
	if ( dy<0             ) { sy1-=dy; dy=0; }
	if ( dx+(sx2-sx1)>639 ) { sx2-=(dx+(sx2-sx1)-639); }
	if ( dy+(sy2-sy1)>479 ) { sy2-=(dy+(sy2-sy1)-479); }

	srcbpl = getputpdt->GetBPL();
	dstbpl = pdt[dstpdt]->GetBPL();
	dstbpp = pdt[dstpdt]->GetBPP();
	srcbuf = getputpdt->GetBuffer();
	dstbuf = pdt[dstpdt]->GetBuffer();
	if ( !dstpdt ) dstbuf++;

	sys->LockPDT(dstpdt);
	srcbuf += sy1*srcbpl+(sx1*3);
	dstbuf += dy*dstbpl+(dx*dstbpp);
	for (y=sy1; y<=sy2; y++) {
		src = srcbuf;
		dst = dstbuf;
		for (x=sx1; x<=sx2; x++) {
			dst[0] = src[0];
			dst[1] = src[1];
			dst[2] = src[2];
			src += 3;
			dst += dstbpp;
		}
		srcbuf += srcbpl;
		dstbuf += dstbpl;
	}
	sys->UnlockPDT(dstpdt, dx, dy, sx2-sx1+dx, sy2-sy1+dy, update);
};


void PDTMGR::FillRect(int sx1, int sy1, int sx2, int sy2, int srcpdt, int r, int g, int b)
{
	unsigned char *msk, *mskbuf, *src, *srcbuf;
	unsigned int temp;
	int srcbpl, srcbpp, x, y;
	int update = 1;

	if ( srcpdt<0 ) { srcpdt = 0; update = 0; }
	if ( srcpdt>MAXPDT ) {
		dprintf("*************** Error in PDT# Src:%d\n", srcpdt);
		return;
	}
	if ( !pdt[srcpdt] ) pdt[srcpdt] = new PDTBUFFER(640, 480, 3, 640*3, true);
	if ( !pdt[srcpdt] ) return;		// ���S�̂���

	sys->LockPDT(srcpdt);
	
	if ( sx1>sx2          ) { temp=sx1; sx1=sx2; sx2=temp; }
	if ( sy1>sy2          ) { temp=sy1; sx1=sy2; sy2=temp; }
	if ( sx1<0            ) { sx1=0; }
	if ( sy1<0            ) { sy1=0; }
	if ( sx2>639          ) { sx2=639; }
	if ( sy2>479          ) { sy2=479; }

	srcbpl = pdt[srcpdt]->GetBPL();
	srcbpp = pdt[srcpdt]->GetBPP();
	srcbuf = pdt[srcpdt]->GetBuffer();
	mskbuf = pdt[srcpdt]->GetMaskBuffer();

	srcbuf += sy1*srcbpl+sx1*srcbpp;
	if ( !srcpdt ) srcbuf++;
	mskbuf += sy1*640+sx1;
	for (y=sy1; y<=sy2; y++) {
		src = srcbuf;
		msk = mskbuf;
		for (x=sx1; x<=sx2; x++) {
			src[0] = r;
			src[1] = g;
			src[2] = b;
			src += srcbpp;
		}
		memset(msk, 255, sx2-sx1+1);
		srcbuf += srcbpl;
		mskbuf += 640;
	}

	sys->UnlockPDT(srcpdt, sx1, sy1, sx2, sy2, update);
};


void PDTMGR::ClearRect(int sx1, int sy1, int sx2, int sy2, int srcpdt, int r, int g, int b)
{
	unsigned char *src, *srcbuf;
	int srcbpl, srcbpp, x, y;
	int temp;
	int update = 1;

	if ( srcpdt<0 ) { srcpdt = 0; update = 0; }
	if ( srcpdt>MAXPDT ) {
		dprintf("*************** Error in PDT# Src:%d\n", srcpdt);
		return;
	}
	if ( !pdt[srcpdt] ) pdt[srcpdt] = new PDTBUFFER(640, 480, 3, 640*3, true);
	if ( !pdt[srcpdt] ) return;		// ���S�̂���

	sys->LockPDT(srcpdt);
	
	if ( sx1>sx2          ) { temp=sx1; sx1=sx2; sx2=temp; }
	if ( sy1>sy2          ) { temp=sy1; sx1=sy2; sy2=temp; }
	if ( sx1<0            ) { sx1=0; }
	if ( sy1<0            ) { sy1=0; }
	if ( sx2>639          ) { sx2=639; }
	if ( sy2>479          ) { sy2=479; }

	srcbpl = pdt[srcpdt]->GetBPL();
	srcbpp = pdt[srcpdt]->GetBPP();
	srcbuf = pdt[srcpdt]->GetBuffer();

	srcbuf += sy1*srcbpl+sx1*srcbpp;
	if ( !srcpdt ) srcbuf++;
	for (y=sy1; y<=sy2; y++) {
		src = srcbuf;
		for (x=sx1; x<=sx2; x++) {
			src[0] = r;
			src[1] = g;
			src[2] = b;
			src += srcbpp;
		}
		srcbuf += srcbpl;
	}

	sys->UnlockPDT(srcpdt, sx1, sy1, sx2, sy2, update);
};


void PDTMGR::DrawRectLine(int sx1, int sy1, int sx2, int sy2, int srcpdt, int r, int g, int b)
{
	unsigned char *src, *srcbuf;
	int srcbpl, srcbpp, x, y;
	int temp;
	int update = 1;

	if ( srcpdt<0 ) { srcpdt = 0; update = 0; }
	if ( srcpdt>MAXPDT ) {
		dprintf("*************** Error in PDT# Src:%d\n", srcpdt);
		return;
	}
	if ( !pdt[srcpdt] ) pdt[srcpdt] = new PDTBUFFER(640, 480, 3, 640*3, true);
	if ( !pdt[srcpdt] ) return;		// ���S�̂���

	sys->LockPDT(srcpdt);
	
	if ( sx1>sx2          ) { temp=sx1; sx1=sx2; sx2=temp; }
	if ( sy1>sy2          ) { temp=sy1; sx1=sy2; sy2=temp; }
	if ( sx1<0            ) { sx1=0; }
	if ( sy1<0            ) { sy1=0; }
	if ( sx2>639          ) { sx2=639; }
	if ( sy2>479          ) { sy2=479; }

	srcbpl = pdt[srcpdt]->GetBPL();
	srcbpp = pdt[srcpdt]->GetBPP();
	srcbuf = pdt[srcpdt]->GetBuffer();

	srcbuf += sy1*srcbpl+sx1*srcbpp;
	if ( !srcpdt ) srcbuf++;
	for (y=sy1; y<=sy2; y++) {
		src = srcbuf;
		if ( (y==sy1)||(y==sy2) ) {
			for (x=sx1; x<=sx2; x++) {
				src[0] = r;
				src[1] = g;
				src[2] = b;
				src += srcbpp;
			}
		} else {
			src[0] = r;
			src[1] = g;
			src[2] = b;
			src += srcbpp*(sx2-sx1);
			src[0] = r;
			src[1] = g;
			src[2] = b;
		}
		srcbuf += srcbpl;
	}

	sys->UnlockPDT(srcpdt, sx1, sy1, sx2, sy2, update);
};


void PDTMGR::LoadFile(char* f, int dstpdt)
{
	PDTFILE* pdtfile;
//	char file[256];
	unsigned char *srcbuf, *dstbuf, *mask1, *mask2, *dst, *src;
	int srcbpl, dstbpl, x, y;
	int update = 1;

	if ( dstpdt<0 ) { dstpdt = 0; update = 0; }
	if ( dstpdt>MAXPDT ) {
		dprintf("*************** Error in PDT# Dst:%d\n", dstpdt);
		return;
	}
//	sprintf(file, ":%s:%s.PDT", sys->GetPDTDir(), f);
	if ( !pdt[dstpdt] ) pdt[dstpdt] = new PDTBUFFER(640, 480, 3, 640*3, true);
	if ( !pdt[dstpdt] ) return;		// ���S�̂���

	sys->LockPDT(dstpdt);

	if ( ((*f)=='*')||((*f)=='?') ) {	// �}�X�N���܂߂�PDT1����R�s�[
		if ( dstpdt!=1 ) {							// PDT1 -> PDT1 �͖���
			srcbpl = pdt[1]->GetBPL();
			dstbpl = pdt[dstpdt]->GetBPL();
			srcbuf = pdt[1]->GetBuffer();
			dstbuf = pdt[dstpdt]->GetBuffer();
			if ( dstpdt ) {							// PDT1 �� PDT2�`
				memcpy(dstbuf, srcbuf, 640*480*3);
			} else {								// PDT1 �� PDT0
				dstbuf++;
				for (y=0; y<=479; y++) {
					dst = dstbuf;
					src = srcbuf;
					for ( x=0; x<=639; x++ ) {
						dst[0] = *src++;
						dst[1] = *src++;
						dst[2] = *src++;
						dst += 4;
					}
					dstbuf += dstbpl;
					srcbuf += srcbpl;
				}
			}
			mask1 = pdt[1]->GetMaskBuffer();
			mask2 = pdt[dstpdt]->GetMaskBuffer();
			memcpy(mask2, mask1, 640*480);
		}
	} else {
//		pdtfile = new PDTFILE(file, sys);
		pdtfile = new PDTFILE(f, sys);
		if ( pdtfile ) pdtfile->CopyBuffer(pdt[dstpdt]);
		delete pdtfile;
	}

	sys->UnlockPDT(dstpdt, 0, 0, 639, 479, update);
};


void PDTMGR::LoadBaseFile(char* f, int dstpdt)
{
	PDTFILE* pdtfile;
//	char file[256];
	unsigned char *srcbuf, *dstbuf, *mask1, *mask2, *dst, *src;
	int srcbpl, dstbpl, x, y;
	int update = 1;

	if ( dstpdt<0 ) { dstpdt = 0; update = 0; }
	if ( dstpdt>MAXPDT ) {
		dprintf("*************** Error in PDT# Dst:%d\n", dstpdt);
		return;
	}
//	sprintf(file, ":%s:%s.PDT", sys->GetPDTDir(), f);
	if ( !pdt[dstpdt] ) pdt[dstpdt] = new PDTBUFFER(640, 480, 3, 640*3, true);
	if ( !pdt[dstpdt] ) return;		// ���S�̂���

	sys->LockPDT(dstpdt);

	if ( ((*f)=='*')||((*f)=='?') ) {	// �}�X�N���܂߂�PDT1����R�s�[
		if ( dstpdt!=1 ) {							// PDT1 -> PDT1 �͖���
			srcbpl = pdt[1]->GetBPL();
			dstbpl = pdt[dstpdt]->GetBPL();
			srcbuf = pdt[1]->GetBuffer();
			dstbuf = pdt[dstpdt]->GetBuffer();
			if ( dstpdt ) {							// PDT1 �� PDT2�`
				memcpy(dstbuf, srcbuf, 640*480*3);
			} else {								// PDT1 �� PDT0
				dstbuf++;
				for (y=0; y<=479; y++) {
					dst = dstbuf;
					src = srcbuf;
					for ( x=0; x<=639; x++ ) {
						dst[0] = *src++;
						dst[1] = *src++;
						dst[2] = *src++;
						dst += 4;
					}
					dstbuf += dstbpl;
					srcbuf += srcbpl;
				}
			}
			mask1 = pdt[1]->GetMaskBuffer();
			mask2 = pdt[dstpdt]->GetMaskBuffer();
//			memcpy(mask2, mask1, 640*480);
			memset(mask2, 0xff, 640*480);
		}
	} else {
//		pdtfile = new PDTFILE(file, sys);
		pdtfile = new PDTFILE(f, sys);
		if ( pdtfile ) pdtfile->CopyBuffer(pdt[dstpdt]);
		mask2 = pdt[dstpdt]->GetMaskBuffer();
		memset(mask2, 0xff, 640*480);
		delete pdtfile;
	}

	sys->UnlockPDT(dstpdt, 0, 0, 639, 479, update);
};


/*void PDTMGR::LoadEffect(char* f, EFFECT* e)
{
}
*/

// �}�X�N�t���Ō��o�b�t�@�ɏd�˂ēǂݍ���
void PDTMGR::LoadCopy(char* f, int sx1, int sy1, int sx2, int sy2, int dx, int dy, int dstpdt, int /*flag*/)
{
	PDTFILE* pdtfile;
//	char file[256];
	unsigned char *dst, *src, *msk, *srcbuf, *dstbuf, *mskbuf;
	int srcbpl, dstbpl, mskbpl, dstbpp, maxx, maxy, x, y;
	int temp, maskc;
	int update = 1;

	if ( dstpdt<0 ) { dstpdt = 0; update = 0; }
	if ( dstpdt>MAXPDT ) {
		dprintf("*************** Error in PDT# Dst:%d\n", dstpdt);
		return;
	}

//	sprintf(file, ":%s:%s.PDT", sys->GetPDTDir(), f);
	if ( !pdt[dstpdt] ) pdt[dstpdt] = new PDTBUFFER(640, 480, 3, 640*3, true);
	if ( !pdt[dstpdt] ) return;		// ���S�̂���

	sys->LockPDT(dstpdt);

//	pdtfile = new PDTFILE(file, sys);
	pdtfile = new PDTFILE(f, sys);
dprintf("File opened. : ");
dprintf(f);
dprintf("\n");
	if ( pdtfile ) {
		maxx = pdtfile->GetSizeX();
		maxy = pdtfile->GetSizeY();
dprintf("  Size - X:%d Y:%d\n", maxx, maxy);

		if ( sx1>sx2          ) { temp=sx1; sx1=sx2; sx2=temp; }
		if ( sy1>sy2          ) { temp=sy1; sx1=sy2; sy2=temp; }
		if ( sx1<0            ) { dx-=sx1; sx1=0; }
		if ( sy1<0            ) { dy-=sy1; sy1=0; }
		if ( sx2>=maxx        ) { sx2=maxx-1; }
		if ( sy2>=maxy        ) { sy2=maxy-1; }
		if ( dx<0             ) { sx1-=dx; dx=0; }
		if ( dy<0             ) { sy1-=dy; dy=0; }
		if ( dx+(sx2-sx1)>=640) { sx2-=(dx+(sx2-sx1)-640+1); }
		if ( dy+(sy2-sy1)>=480) { sy2-=(dy+(sy2-sy1)-480+1); }
dprintf("  Fixed Size - (%d, %d)-(%d, %d) ->", sx1, sy1, sx2, sy2);
dprintf(" (%d, %d)\n", dx, dy);

		srcbpl = maxx*3;
		dstbpl = pdt[dstpdt]->GetBPL();
		dstbpp = pdt[dstpdt]->GetBPP();
		mskbpl = maxx;

		srcbuf = pdtfile->GetBuffer();
		dstbuf = pdt[dstpdt]->GetBuffer();
		if ( !dstpdt ) dstbuf++;
		mskbuf = pdtfile->GetMaskBuffer();

		if ( mskbuf ) {
			srcbuf += sy1*srcbpl+sx1*3;
			dstbuf += dy*dstbpl+dx*dstbpp;
			mskbuf += sy1*mskbpl+sx1;
			for(y=sy1; y<=sy2; y++) {
				src = srcbuf;
				dst = dstbuf;
				msk = mskbuf;
				for (x=sx1; x<=sx2; x++) {
					maskc = *msk++;
					if ( maskc ) {
						maskc = 256-maskc;
						temp = (src[2]+((dst[0]*maskc)>>8));
						if ( temp>0xff ) dst[0] = 0xff; else dst[0] = temp;
						temp = (src[1]+((dst[1]*maskc)>>8));
						if ( temp>0xff ) dst[1] = 0xff; else dst[1] = temp;
						temp = (src[0]+((dst[2]*maskc)>>8));
						if ( temp>0xff ) dst[2] = 0xff; else dst[2] = temp;
					}
					src += 3;
					dst += dstbpp;
				}
				srcbuf += srcbpl;
				dstbuf += dstbpl;
				mskbuf += mskbpl;
			}
		} else {
			srcbuf += sy1*srcbpl+sx1*3;
			dstbuf += dy*dstbpl+dx*dstbpp;
			for(y=sy1; y<=sy2; y++) {
				src = srcbuf;
				dst = dstbuf;
				for (x=sx1; x<=sx2; x++) {
					dst[2] = *src++;
					dst[1] = *src++;
					dst[0] = *src++;
					dst += dstbpp;
				}
				srcbuf += srcbpl;
				dstbuf += dstbpl;
			}
		}
		delete pdtfile;
	}

	sys->UnlockPDT(dstpdt, dx, dy, sx2-sx1+dx, sy2-sy1+dy, update);
};


void PDTMGR::CopyBackBuffer(int sx1, int sy1, int sx2, int sy2, int srcpdt, int update)
{
	unsigned char *srcbuf, *dstbuf, *src, *dst;
	int srcbpl, dstbpl, x, y;
	int temp;

	if ( srcpdt<0 ) srcpdt = 0;
	if ( !srcpdt ) { 
		if ( update ) { sys->LockPDT(0); sys->UnlockPDT(0, sx1, sy1, sx2, sy2, 1); }
		return;
	}
	if ( srcpdt>MAXPDT ) {
		dprintf("*************** Error in PDT# Src:%d\n", srcpdt);
		return;
	}
	if ( !pdt[srcpdt] ) return;		// ���S�̂���
	if ( !pdt[0] ) return;			// ���S�̂���

	sys->LockPDT(0);

	if ( sx1>sx2          ) { temp=sx1; sx1=sx2; sx2=temp; }
	if ( sy1>sy2          ) { temp=sy1; sx1=sy2; sy2=temp; }
	if ( sx1<0            ) { sx1=0; }
	if ( sy1<0            ) { sy1=0; }
	if ( sx2>639          ) { sx2=639; }
	if ( sy2>479          ) { sy2=479; }

	srcbpl = pdt[srcpdt]->GetBPL();
	dstbpl = pdt[0]->GetBPL();
	srcbuf = pdt[srcpdt]->GetBuffer();
	dstbuf = pdt[0]->GetBuffer();

	srcbuf += sy1*srcbpl+(sx1*3);
	dstbuf += sy1*dstbpl+(sx1<<2);
	for (y=sy1; y<=sy2; y++) {
		src = srcbuf;
		dst = dstbuf;
		for ( x=sx1; x<=sx2; x++) {
			dst[1] = *src++;
			dst[2] = *src++;
			dst[3] = *src++;
			dst += 4;
		}
		srcbuf += srcbpl;
		dstbuf += dstbpl;
	}
	sys->UnlockPDT(0, sx1, sy1, sx2, sy2, update);
};


void PDTMGR::Copy(int sx1, int sy1, int sx2, int sy2, int srcpdt, int dx, int dy, int dstpdt, int flag)
{
	unsigned char *dst, *src, *srcbuf, *dstbuf, *mask1, *mask2;
	int srcbpl, dstbpl, srcbpp, dstbpp, x, y;
	int temp;
	int update = 1;

	if ( srcpdt<0 ) srcpdt = 0;
	if ( dstpdt<0 ) { dstpdt = 0; update = 0; }
	if ( (srcpdt>MAXPDT)||(dstpdt>MAXPDT) ) {
		dprintf("*************** Error in PDT# Src:%d Dst:%d\n", srcpdt, dstpdt);
		return;
	}
	if ( !pdt[srcpdt] ) return;		// ���S�̂���
	if ( !pdt[dstpdt] ) pdt[dstpdt] = new PDTBUFFER(640, 480, 3, 640*3, true);
	if ( !pdt[dstpdt] ) return;		// ���S�̂���

	if ( sx1>sx2          ) { temp=sx1; sx1=sx2; sx2=temp; }
	if ( sy1>sy2          ) { temp=sy1; sx1=sy2; sy2=temp; }
	if ( sx1<0            ) { dx-=sx1; sx1=0; }
	if ( sy1<0            ) { dy-=sy1; sy1=0; }
	if ( sx2>639          ) { sx2=639; }
	if ( sy2>479          ) { sy2=479; }
	if ( dx<0             ) { sx1-=dx; dx=0; }
	if ( dy<0             ) { sy1-=dy; dy=0; }
	if ( dx+(sx2-sx1)>639 ) { sx2-=(dx+(sx2-sx1)-639); }
	if ( dy+(sy2-sy1)>479 ) { sy2-=(dy+(sy2-sy1)-479); }
	if ( flag>255 ) flag = 255;
	if ( flag<0   ) flag = 0;

	srcbpl = pdt[srcpdt]->GetBPL();
	dstbpl = pdt[dstpdt]->GetBPL();
	srcbpp = pdt[srcpdt]->GetBPP();
	dstbpp = pdt[dstpdt]->GetBPP();
	srcbuf = pdt[srcpdt]->GetBuffer();
	if ( !srcpdt ) srcbuf++;
	dstbuf = pdt[dstpdt]->GetBuffer();
	if ( !dstpdt ) dstbuf++;
	mask1 = pdt[srcpdt]->GetMaskBuffer();
	mask2 = pdt[dstpdt]->GetMaskBuffer();

	sys->LockPDT(dstpdt);

	if ( flag ) {
		flag++;
		srcbuf += sy1*srcbpl+(sx1*srcbpp);
		dstbuf += dy*dstbpl+(dx*dstbpp);
		for (y=sy1; y<=sy2; y++) {
			src = srcbuf;
			dst = dstbuf;
			for (x=sx1; x<=sx2; x++) {
				PDT_FadePixel(src, dst, dst, 256, flag);
				src += srcbpp;
				dst += dstbpp;
			}
			srcbuf += srcbpl;
			dstbuf += dstbpl;
		}
		if (sx2>=sx1) {
			mask1 += sy1*640+sx1;
			mask2 += dy*640+dx;
			for (y=sy1; y<=sy2; y++) {
				memcpy(mask2, mask1, sx2-sx1+1);
				mask1 += 640;
				mask2 += 640;
			}
		}
	} else {
		if (sx2>=sx1) {
			srcbuf += sy1*srcbpl+(sx1*srcbpp);
			dstbuf += dy*dstbpl+(dx*dstbpp);
			for (y=sy1; y<=sy2; y++) {
				src = srcbuf;
				dst = dstbuf;
				for (x=sx1; x<=sx2; x++) {
					dst[0] = src[0];
					dst[1] = src[1];
					dst[2] = src[2];
					src += srcbpp;
					dst += dstbpp;
				}
				srcbuf += srcbpl;
				dstbuf += dstbpl;
			}
			mask1 += sy1*640+sx1;
			mask2 += dy*640+dx;
			for (y=sy1; y<=sy2; y++) {
				memcpy(mask2, mask1, sx2-sx1+1);
				mask1 += 640;
				mask2 += 640;
			}
		}
	}

	sys->UnlockPDT(dstpdt, dx, dy, sx2-sx1+dx, sy2-sy1+dy, update);
};


void PDTMGR::CopyReverse(int sx1, int sy1, int sx2, int sy2, int srcpdt, int dx, int dy, int dstpdt, int flag)
{
	unsigned char *dst, *src, *srcbuf, *dstbuf, *mask1, *mask2;
	int srcbpl, dstbpl, srcbpp, dstbpp, x, y;
	int temp;
	int update = 1;

	if ( srcpdt<0 ) srcpdt = 0;
	if ( dstpdt<0 ) { dstpdt = 0; update = 0; }
	if ( (srcpdt>MAXPDT)||(dstpdt>MAXPDT) ) {
		dprintf("*************** Error in PDT# Src:%d Dst:%d\n", srcpdt, dstpdt);
		return;
	}
	if ( !pdt[srcpdt] ) return;		// ���S�̂���
	if ( !pdt[dstpdt] ) pdt[dstpdt] = new PDTBUFFER(640, 480, 3, 640*3, true);
	if ( !pdt[dstpdt] ) return;		// ���S�̂���

	if ( sx1>sx2          ) { temp=sx1; sx1=sx2; sx2=temp; }
	if ( sy1>sy2          ) { temp=sy1; sx1=sy2; sy2=temp; }
	if ( sx1<0            ) { dx-=sx1; sx1=0; }
	if ( sy1<0            ) { dy-=sy1; sy1=0; }
	if ( sx2>639          ) { sx2=639; }
	if ( sy2>479          ) { sy2=479; }
	if ( dx<0             ) { sx1-=dx; dx=0; }
	if ( dy<0             ) { sy1-=dy; dy=0; }
	if ( dx+(sx2-sx1)>639 ) { sx2-=(dx+(sx2-sx1)-639); }
	if ( dy+(sy2-sy1)>479 ) { sy2-=(dy+(sy2-sy1)-479); }
	if ( flag>255 ) flag = 255;
	if ( flag<0   ) flag = 0;

	srcbpl = pdt[srcpdt]->GetBPL();
	dstbpl = pdt[dstpdt]->GetBPL();
	srcbpp = pdt[srcpdt]->GetBPP();
	dstbpp = pdt[dstpdt]->GetBPP();
	srcbuf = pdt[srcpdt]->GetBuffer();
	if ( !srcpdt ) srcbuf++;
	dstbuf = pdt[dstpdt]->GetBuffer();
	if ( !dstpdt ) dstbuf++;
	mask1 = pdt[srcpdt]->GetMaskBuffer();
	mask2 = pdt[dstpdt]->GetMaskBuffer();

	sys->LockPDT(dstpdt);

	if (sx2>=sx1) {
		srcbuf += sy2*srcbpl+(sx1*srcbpp);
		dstbuf += (dy+sy2-sy1)*dstbpl+(dx*dstbpp);
		for (y=sy2; y>=sy1; y--) {
			src = srcbuf;
			dst = dstbuf;
			for (x=sx1; x>=sx2; x++) {
				dst[0] = src[0];
				dst[1] = src[1];
				dst[2] = src[2];
				src += srcbpp;
				dst += dstbpp;
			}
			srcbuf -= srcbpl;
			dstbuf -= dstbpl;
		}
		mask1 += sy2*640+sx1;
		mask2 += (dy+sy2-sy1)*640+dx;
		for (y=sy2; y>=sy1; y--) {
			memcpy(mask2, mask1, sx2-sx1+1);
			mask1 -= 640;
			mask2 -= 640;
		}
	}

	sys->UnlockPDT(dstpdt, dx, dy, sx2-sx1+dx, sy2-sy1+dy, update);
};


void PDTMGR::AllCopy(int srcpdt, int dstpdt, int flag)
{
	unsigned char *dst, *src, *srcbuf, *dstbuf, *mask;
	int srcbpp, srcbpl, dstbpp, dstbpl, x, y;
	int update = 1;

	if ( srcpdt<0 ) srcpdt = 0;
	if ( dstpdt<0 ) { dstpdt = 0; update = 0; }
	if ( (srcpdt>MAXPDT)||(dstpdt>MAXPDT) ) {
		dprintf("*************** Error in PDT# Src:%d Dst:%d\n", srcpdt, dstpdt);
		return;
	}
	if ( !pdt[srcpdt] ) return;		// ���S�̂���
	if ( !pdt[dstpdt] ) pdt[dstpdt] = new PDTBUFFER(640, 480, 3, 640*3, true);
	if ( !pdt[dstpdt] ) return;		// ���S�̂���
	
	sys->LockPDT(dstpdt);

	if ( flag>255 ) flag = 255;
	if ( flag<0   ) flag = 0;

	srcbpp = pdt[srcpdt]->GetBPP();
	srcbpl = pdt[srcpdt]->GetBPL();
	dstbpp = pdt[dstpdt]->GetBPP();
	dstbpl = pdt[dstpdt]->GetBPL();
	srcbuf = pdt[srcpdt]->GetBuffer();
	if ( !srcpdt ) srcbuf++;
	dstbuf = pdt[dstpdt]->GetBuffer();
	if ( !dstpdt ) dstbuf++;

	if ( flag ) {
		flag++;
		for (y=0; y<=479; y++) {
			src = srcbuf+y*srcbpl;
			dst = dstbuf+y*dstbpl;
			for (x=0; x<=639; x++) {
				PDT_FadePixel(src, dst, dst, 256, flag);
				src += srcbpp;
				dst += dstbpp;
			}
		}
	} else {
		if ( (srcpdt)&&(dstpdt) ) {			// PDT0�ȊO���m
			memcpy(dstbuf, srcbuf, 640*480*3);
		} else {
			for (y=0; y<=479; y++) {
				src = srcbuf;
				dst = dstbuf;
				for (x=0; x<=639; x++) {
					dst[0] = src[0];
					dst[1] = src[1];
					dst[2] = src[2];
					src += srcbpp;
					dst += dstbpp;
				}
				srcbuf += srcbpl;
				dstbuf += dstbpl;
			}
		}
	}
	mask = pdt[dstpdt]->GetMaskBuffer();
	memset(mask, 255, 640*480);

	sys->UnlockPDT(dstpdt, 0, 0, 639, 479, update);
};


void PDTMGR::CopyWithMask(int sx1, int sy1, int sx2, int sy2, int srcpdt, int dx, int dy, int dstpdt, int flag)
{
	unsigned char *dst, *src, *msk, *msk2, *srcbuf, *dstbuf, *mskbuf, *mskbuf2, maskc;
	int srcbpl, dstbpl, srcbpp, dstbpp, x, y;
	int temp;
	int update = 1;

	if ( srcpdt<0 ) srcpdt = 0;
	if ( dstpdt<0 ) { dstpdt = 0; update = 0; }
	if ( (srcpdt>MAXPDT)||(dstpdt>MAXPDT) ) {
		dprintf("*************** Error in PDT# Src:%d Dst:%d\n", srcpdt, dstpdt);
		return;
	}
	if ( !pdt[srcpdt] ) return;		// ���S�̂���
	if ( !pdt[dstpdt] ) pdt[dstpdt] = new PDTBUFFER(640, 480, 3, 640*3, true);
	if ( !pdt[dstpdt] ) return;		// ���S�̂���

	sys->LockPDT(dstpdt);

	if ( sx1>sx2          ) { temp=sx1; sx1=sx2; sx2=temp; }
	if ( sy1>sy2          ) { temp=sy1; sx1=sy2; sy2=temp; }
	if ( sx1<0            ) { dx-=sx1; sx1=0; }
	if ( sy1<0            ) { dy-=sy1; sy1=0; }
	if ( sx2>639          ) { sx2=639; }
	if ( sy2>479          ) { sy2=479; }
	if ( dx<0             ) { sx1-=dx; dx=0; }
	if ( dy<0             ) { sy1-=dy; dy=0; }
	if ( dx+(sx2-sx1)>639 ) { sx2-=(dx+(sx2-sx1)-639); }
	if ( dy+(sy2-sy1)>479 ) { sy2-=(dy+(sy2-sy1)-479); }
	if ( flag>255 ) flag = 255;
	if ( flag<0   ) flag = 0;

	srcbpl = pdt[srcpdt]->GetBPL();
	dstbpl = pdt[dstpdt]->GetBPL();
	srcbpp = pdt[srcpdt]->GetBPP();
	dstbpp = pdt[dstpdt]->GetBPP();
	srcbuf = pdt[srcpdt]->GetBuffer();
	dstbuf = pdt[dstpdt]->GetBuffer();
	mskbuf = pdt[dstpdt]->GetMaskBuffer();
	mskbuf2 = pdt[srcpdt]->GetMaskBuffer();

	srcbuf += sy1*srcbpl+(sx1*srcbpp);
	if ( !srcpdt ) srcbuf++;
	dstbuf += dy*dstbpl+(dx*dstbpp);
	if ( !dstpdt ) dstbuf++;
	mskbuf += dy*640+dx;
	mskbuf2 += sy1*640+sx1;

	if ( flag ) {
		for(y=sy1; y<=sy2; y++) {
			src = srcbuf;
			dst = dstbuf;
			msk = mskbuf;
			msk2 = mskbuf2;
			for (x=sx1; x<=sx2; x++) {
				maskc = *msk;
				*msk++ = *msk2++;
				PDT_FadePixelDst(src, dst, dst, maskc, flag);
				src += srcbpp;
				dst += dstbpp;
			}
			srcbuf += srcbpl;
			dstbuf += dstbpl;
			mskbuf += 640;
			mskbuf2 += 640;
		}
	} else {
		for(y=sy1; y<=sy2; y++) {
			src = srcbuf;
			dst = dstbuf;
			msk = mskbuf;
			msk2 = mskbuf2;
			for (x=sx1; x<=sx2; x++) {
				maskc = *msk;
				*msk++ = *msk2++;
				PDT_PixelDst(src, dst, maskc);
				src += srcbpp;
				dst += dstbpp;
			}
			srcbuf += srcbpl;
			dstbuf += dstbpl;
			mskbuf += 640;
			mskbuf2 += 640;
		}
	}
	sys->UnlockPDT(dstpdt, dx, dy, sx2-sx1+dx, sy2-sy1+dy, update);
};


void PDTMGR::MaskCopy(int sx1, int sy1, int sx2, int sy2, int srcpdt, int dx, int dy, int dstpdt, int flag)
{
	unsigned char *dst, *src, *msk, *srcbuf, *dstbuf, *mskbuf, *mask2, maskc;
	int srcbpl, dstbpl, srcbpp, dstbpp, x, y;
	int temp;
	int update = 1;

	if ( srcpdt<0 ) srcpdt = 0;
	if ( dstpdt<0 ) { dstpdt = 0; update = 0; }
	if ( (srcpdt>MAXPDT)||(dstpdt>MAXPDT) ) {
		dprintf("*************** Error in PDT# Src:%d Dst:%d\n", srcpdt, dstpdt);
		return;
	}
	if ( !pdt[srcpdt] ) return;		// ���S�̂���
	if ( !pdt[dstpdt] ) pdt[dstpdt] = new PDTBUFFER(640, 480, 3, 640*3, true);
	if ( !pdt[dstpdt] ) return;		// ���S�̂���

	sys->LockPDT(dstpdt);

	if ( sx1>sx2          ) { temp=sx1; sx1=sx2; sx2=temp; }
	if ( sy1>sy2          ) { temp=sy1; sx1=sy2; sy2=temp; }
	if ( sx1<0            ) { dx-=sx1; sx1=0; }
	if ( sy1<0            ) { dy-=sy1; sy1=0; }
	if ( sx2>639          ) { sx2=639; }
	if ( sy2>479          ) { sy2=479; }
	if ( dx<0             ) { sx1-=dx; dx=0; }
	if ( dy<0             ) { sy1-=dy; dy=0; }
	if ( dx+(sx2-sx1)>639 ) { sx2-=(dx+(sx2-sx1)-639); }
	if ( dy+(sy2-sy1)>479 ) { sy2-=(dy+(sy2-sy1)-479); }
	if ( flag>255 ) flag = 255;
	if ( flag<0   ) flag = 0;

	srcbpl = pdt[srcpdt]->GetBPL();
	dstbpl = pdt[dstpdt]->GetBPL();
	srcbpp = pdt[srcpdt]->GetBPP();
	dstbpp = pdt[dstpdt]->GetBPP();
	srcbuf = pdt[srcpdt]->GetBuffer();
	dstbuf = pdt[dstpdt]->GetBuffer();
	mskbuf = pdt[srcpdt]->GetMaskBuffer();
	mask2 = pdt[dstpdt]->GetMaskBuffer();

	srcbuf += sy1*srcbpl+(sx1*srcbpp);
	if ( !srcpdt ) srcbuf++;
	dstbuf += dy*dstbpl+(dx*dstbpp);
	if ( !dstpdt ) dstbuf++;
	mskbuf += sy1*640+sx1;

	if ( flag ) {
		for(y=sy1; y<=sy2; y++) {
			src = srcbuf;
			dst = dstbuf;
			msk = mskbuf;
			for (x=sx1; x<=sx2; x++) {
				maskc = *msk++;
				PDT_FadePixel(src, dst, dst, maskc, flag);
				src += srcbpp;
				dst += dstbpp;
			}
			srcbuf += srcbpl;
			dstbuf += dstbpl;
			mskbuf += 640;
		}
	} else {
		for(y=sy1; y<=sy2; y++) {
			src = srcbuf;
			dst = dstbuf;
			msk = mskbuf;
			for (x=sx1; x<=sx2; x++) {
				maskc = *msk++;
				PDT_Pixel(src, dst, maskc);
				src += srcbpp;
				dst += dstbpp;
			}
			srcbuf += srcbpl;
			dstbuf += dstbpl;
			mskbuf += 640;
		}
	}
	sys->UnlockPDT(dstpdt, dx, dy, sx2-sx1+dx, sy2-sy1+dy, update);
};


void PDTMGR::MaskCopy(int sx1, int sy1, int sx2, int sy2, PDTBUFFER* srcpdt, int dx, int dy, int dstpdt, int flag)
{	// Used only in the ending scroll
	unsigned char *dst, *src, *msk, *srcbuf, *dstbuf, *mskbuf, maskc;
	int srcbpl, dstbpl, mskbpl, srcbpp, dstbpp, x, y;
	int temp;
	int update = 1;

	if ( dstpdt<0 ) { dstpdt = 0; update = 0; }
	if ( dstpdt>MAXPDT ) {
		dprintf("*************** Error in PDT# Dst:%d\n", dstpdt);
		return;
	}
	if ( !srcpdt ) return;		// ���S�̂���
	if ( !pdt[dstpdt] ) pdt[dstpdt] = new PDTBUFFER(640, 480, 3, 640*3, true);
	if ( !pdt[dstpdt] ) return;		// ���S�̂���
	
	sys->LockPDT(dstpdt);

	if ( sx1>sx2          ) { temp=sx1; sx1=sx2; sx2=temp; }
	if ( sy1>sy2          ) { temp=sy1; sx1=sy2; sy2=temp; }
	if ( sx1<0            ) { dx-=sx1; sx1=0; }
	if ( sy1<0            ) { dy-=sy1; sy1=0; }
	if ( sx2>639          ) { sx2=639; }
	if ( sy2>479          ) { sy2=479; }
	if ( dx<0             ) { sx1-=dx; dx=0; }
	if ( dy<0             ) { sy1-=dy; dy=0; }
	if ( dx+(sx2-sx1)>639 ) { sx2-=(dx+(sx2-sx1)-639); }
	if ( dy+(sy2-sy1)>479 ) { sy2-=(dy+(sy2-sy1)-479); }
	if ( flag>255 ) flag = 255;
	if ( flag<0   ) flag = 0;

	srcbpl = srcpdt->GetBPL();
	dstbpl = pdt[dstpdt]->GetBPL();
	mskbpl = srcpdt->GetSizeX();
	srcbpp = srcpdt->GetBPP();
	dstbpp = pdt[dstpdt]->GetBPP();
	srcbuf = srcpdt->GetBuffer();
	dstbuf = pdt[dstpdt]->GetBuffer();
	mskbuf = srcpdt->GetMaskBuffer();

	srcbuf += sy1*srcbpl+(sx1*srcbpp);
//	if ( !srcpdt ) srcbuf++;
	dstbuf += dy*dstbpl+(dx*dstbpp);
	if ( !dstpdt ) dstbuf++;
	mskbuf += sy1*mskbpl+sx1;

	if ( flag ) {
		flag++;
		for(y=sy1; y<=sy2; y++) {
			src = srcbuf;
			dst = dstbuf;
			msk = mskbuf;
			for (x=sx1; x<=sx2; x++) {
				maskc = *msk++;
				PDT_FadePixel(src, dst, dst, maskc, flag);
				src += srcbpp;
				dst += dstbpp;
			}
			srcbuf += srcbpl;
			dstbuf += dstbpl;
			mskbuf += mskbpl;
		}
	} else {
		for(y=sy1; y<=sy2; y++) {
			src = srcbuf;
			dst = dstbuf;
			msk = mskbuf;
			for (x=sx1; x<=sx2; x++) {
				maskc = *msk++;
				PDT_Pixel(src, dst, maskc);
				src += srcbpp;
				dst += dstbpp;
			}
			srcbuf += srcbpl;
			dstbuf += dstbpl;
			mskbuf += mskbpl;
		}
	}
	sys->UnlockPDT(dstpdt, dx, dy, sx2-sx1+dx, sy2-sy1+dy, update);
};


void PDTMGR::StretchCopy(int sx1, int sy1, int sx2, int sy2, int srcpdt, int dx1, int dy1, int dx2, int dy2, int dstpdt)
{
	unsigned char *dst, *src, *srcbuf, *dstbuf;//, *mask1, *mask2;
	int srcbpl, dstbpl, srcbpp, dstbpp, x, y;
	int temp, x1, y1, x2, y2, sw, sh, dw, dh;
	int update = 1;
	int xx[640], yy[480];

	if ( srcpdt<0 ) srcpdt = 0;
	if ( dstpdt<0 ) { dstpdt = 0; update = 0; }
	if ( (srcpdt>MAXPDT)||(dstpdt>MAXPDT) ) {
		dprintf("*************** Error in PDT# Src:%d Dst:%d\n", srcpdt, dstpdt);
		return;
	}
	if ( !pdt[srcpdt] ) return;		// ���S�̂���
	if ( !pdt[dstpdt] ) pdt[dstpdt] = new PDTBUFFER(640, 480, 3, 640*3, true);
	if ( !pdt[dstpdt] ) return;		// ���S�̂���

	if ( srcpdt==dstpdt ) {
		if ( temppdt ) {
			delete temppdt;
			temppdt = 0;
		}
		temppdt = new PDTBUFFER(640, 480, 3, 640*3, true);
		if ( temppdt ) {
			dstbuf = temppdt->GetBuffer();
			srcbpl = pdt[srcpdt]->GetBPL();
			srcbpp = pdt[srcpdt]->GetBPP();
			srcbuf = pdt[srcpdt]->GetBuffer();
			if ( !srcpdt ) srcbuf++;
			for (y=0; y<=479; y++) {
				src = srcbuf;
				dst = dstbuf;
				for (x=0; x<=639; x++) {
					dst[0] = src[0];
					dst[1] = src[1];
					dst[2] = src[2];
					src += srcbpp;
					dst += 3;
				}
				srcbuf += srcbpl;
				dstbuf += 640*3;
			}
			StretchCopy(sx1, sy1, sx2, sy2, temppdt, dx1, dy1, dx2, dy2, dstpdt);
			delete temppdt;
			temppdt = 0;
		}
		return;
	}

	sys->LockPDT(dstpdt);

	if ( sx1>sx2 ) { temp=sx1; sx1=sx2; sx2=temp; }
	if ( sy1>sy2 ) { temp=sy1; sx1=sy2; sy2=temp; }
	if ( dx1>dx2 ) { temp=dx1; dx1=dx2; dx2=temp; }
	if ( dy1>dy2 ) { temp=dy1; dx1=dy2; dy2=temp; }
	x1 = dx1; y1 = dy1;
	x2 = dx2; y2 = dy2;
	if ( dx1<0   ) { x1 = 0; }
	if ( dy1<0   ) { y1 = 0; }
	if ( dx2>639 ) { x2 = 639; }
	if ( dy2>479 ) { y2 = 479; }
	sw = sx2-sx1+1; sh = sy2-sy1+1;
	dw = dx2-dx1+1; dh = dy2-dy1+1;

	srcbpl = pdt[srcpdt]->GetBPL();
	dstbpl = pdt[dstpdt]->GetBPL();
	srcbpp = pdt[srcpdt]->GetBPP();
	dstbpp = pdt[dstpdt]->GetBPP();
	srcbuf = pdt[srcpdt]->GetBuffer();
	if ( !srcpdt ) srcbuf++;
	dstbuf = pdt[dstpdt]->GetBuffer();
	if ( !dstpdt ) dstbuf++;

	for (x=x1; x<=x2; x++) {
		xx[x] = ((x-dx1)*sw)/dw+sx1;
		if (xx[x]>639)
			xx[x] = -1;
		else
			xx[x] *= srcbpp;
	}
	for (y=y1; y<=y2; y++) {
		yy[y] = ((y-dy1)*sh)/dh+sy1;
		if (yy[y]>639)
			yy[y] = -1;
		else
			yy[y] *= srcbpl;
	}

	dstbuf += y1*dstbpl+(x1*dstbpp);
	for (y=y1; y<y2; y++) {
		dst = dstbuf;
		for (x=x1; x<x2; x++) {
			if ( (xx[x]>=0)&&(yy[y]>=0) ) {
				src = srcbuf+yy[y]+xx[x];
				dst[0] = src[0];
				dst[1] = src[1];
				dst[2] = src[2];
			}
			dst += dstbpp;
		}
		dstbuf += dstbpl;
	}

	sys->UnlockPDT(dstpdt, x1, y1, x2+1, y2+1, update);
};


// �A���g�k��p
void PDTMGR::StretchCopy(int sx1, int sy1, int sx2, int sy2, PDTBUFFER* srcpdt, int dx1, int dy1, int dx2, int dy2, int dstpdt)
{
	unsigned char *dst, *src, *srcbuf, *dstbuf;//, *mask1, *mask2;
	int srcbpl, dstbpl, dstbpp, x, y;
	int temp, x1, y1, x2, y2, sw, sh, dw, dh;
	int update = 1;
	int xx[640], yy[480];

	if ( dstpdt<0 ) { dstpdt = 0; update = 0; }
	if ( dstpdt>MAXPDT ) {
		dprintf("*************** Error in PDT# Dst:%d\n", dstpdt);
		return;
	}
	if ( !srcpdt ) return;			// ���S�̂���
	if ( !pdt[dstpdt] ) pdt[dstpdt] = new PDTBUFFER(640, 480, 3, 640*3, true);
	if ( !pdt[dstpdt] ) return;		// ���S�̂���

	sys->LockPDT(dstpdt);

	if ( sx1>sx2 ) { temp=sx1; sx1=sx2; sx2=temp; }
	if ( sy1>sy2 ) { temp=sy1; sx1=sy2; sy2=temp; }
	if ( dx1>dx2 ) { temp=dx1; dx1=dx2; dx2=temp; }
	if ( dy1>dy2 ) { temp=dy1; dx1=dy2; dy2=temp; }
	x1 = dx1; y1 = dy1;
	x2 = dx2; y2 = dy2;
	if ( dx1<0   ) { x1 = 0; }
	if ( dy1<0   ) { y1 = 0; }
	if ( dx2>639 ) { x2 = 639; }
	if ( dy2>479 ) { y2 = 479; }
	sw = sx2-sx1+1; sh = sy2-sy1+1;
	dw = dx2-dx1+1; dh = dy2-dy1+1;

	srcbpl = srcpdt->GetBPL();
	dstbpl = pdt[dstpdt]->GetBPL();
	dstbpp = pdt[dstpdt]->GetBPP();
	srcbuf = srcpdt->GetBuffer();
	dstbuf = pdt[dstpdt]->GetBuffer();
	if ( !dstpdt ) dstbuf++;

	for (x=x1; x<=x2; x++) {
		xx[x] = ((x-dx1)*sw)/dw+sx1;
		if (xx[x]>639)
			xx[x] = -1;
		else
			xx[x] *= 3;
	}
	for (y=y1; y<=y2; y++) {
		yy[y] = ((y-dy1)*sh)/dh+sy1;
		if (yy[y]>639)
			yy[y] = -1;
		else
			yy[y] *= srcbpl;
	}

	dstbuf += y1*dstbpl+(x1*dstbpp);
	for (y=y1; y<y2; y++) {
		dst = dstbuf;
		for (x=x1; x<x2; x++) {
			if ( (xx[x]>=0)&&(yy[y]>=0) ) {
				src = srcbuf+yy[y]+xx[x];
				dst[0] = src[0];
				dst[1] = src[1];
				dst[2] = src[2];
			}
			dst += dstbpp;
		}
		dstbuf += dstbpl;
	}

	sys->UnlockPDT(dstpdt, x1, y1, x2+1, y2+1, update);
};


// ���m�N�����ł͂Ȃ��A���ߐF�w��t���R�s�[�炵��
void PDTMGR::MonoCopy(int sx1, int sy1, int sx2, int sy2, int srcpdt, int dx, int dy, int dstpdt, int r, int g, int b)
{
	unsigned char *dst, *src, *srcbuf, *dstbuf;
	int srcbpl, dstbpl, srcbpp, dstbpp, x, y;
	int temp;
	int update = 1;

	if ( srcpdt<0 ) srcpdt = 0;
	if ( dstpdt<0 ) { dstpdt = 0; update = 0; }
	if ( (srcpdt>MAXPDT)||(dstpdt>MAXPDT) ) {
		dprintf("*************** Error in PDT# Src:%d Dst:%d\n", srcpdt, dstpdt);
		return;
	}
	if ( !pdt[srcpdt] ) return;		// ���S�̂���
	if ( !pdt[dstpdt] ) pdt[dstpdt] = new PDTBUFFER(640, 480, 3, 640*3, true);
	if ( !pdt[dstpdt] ) return;		// ���S�̂���

	if ( sx1>sx2          ) { temp=sx1; sx1=sx2; sx2=temp; }
	if ( sy1>sy2          ) { temp=sy1; sx1=sy2; sy2=temp; }
	if ( sx1<0            ) { dx-=sx1; sx1=0; }
	if ( sy1<0            ) { dy-=sy1; sy1=0; }
	if ( sx2>639          ) { sx2=639; }
	if ( sy2>479          ) { sy2=479; }
	if ( dx<0             ) { sx1-=dx; dx=0; }
	if ( dy<0             ) { sy1-=dy; dy=0; }
	if ( dx+(sx2-sx1)>639 ) { sx2-=(dx+(sx2-sx1)-639); }
	if ( dy+(sy2-sy1)>479 ) { sy2-=(dy+(sy2-sy1)-479); }
	if ( r>255 ) r = 255;
	if ( r<0   ) r = 0;
	if ( g>255 ) g = 255;
	if ( g<0   ) g = 0;
	if ( b>255 ) b = 255;
	if ( b<0   ) b = 0;

	srcbpl = pdt[srcpdt]->GetBPL();
	dstbpl = pdt[dstpdt]->GetBPL();
	srcbpp = pdt[srcpdt]->GetBPP();
	dstbpp = pdt[dstpdt]->GetBPP();
	srcbuf = pdt[srcpdt]->GetBuffer();
	if ( !srcpdt ) srcbuf++;
	dstbuf = pdt[dstpdt]->GetBuffer();
	if ( !dstpdt ) dstbuf++;
//	mskbuf = pdt[srcpdt]->GetMaskBuffer();

	sys->LockPDT(dstpdt);

	srcbuf += sy1*srcbpl+(sx1*srcbpp);
	dstbuf += dy*dstbpl+(dx*dstbpp);
//	mskbuf += sy1*640+sx1;
	for (y=sy1; y<=sy2; y++) {
		src = srcbuf;
		dst = dstbuf;
//		msk = mskbuf;
		for (x=sx1; x<=sx2; x++) {
//			maskc = *msk++;
			if ( (src[0]!=r)||(src[1]!=g)||(src[2]!=b) ) {
				dst[0]=src[0];
				dst[1]=src[1];
				dst[2]=src[2];
			}
			src += srcbpp;
			dst += dstbpp;
		}
		srcbuf += srcbpl;
		dstbuf += dstbpl;
//		mskbuf += 640;
	}

	sys->UnlockPDT(dstpdt, dx, dy, sx2-sx1+dx, sy2-sy1+dy, update);
};


void PDTMGR::FadeColor(int sx1, int sy1, int sx2, int sy2, int srcpdt, int r, int g, int b, int count)
{
	unsigned char *src, *srcbuf;
	int srcbpl, srcbpp, x, y;
	int temp;
	int update = 1;

	if ( srcpdt<0 ) { srcpdt = 0; update = 0; }
	if ( srcpdt>MAXPDT ) {
		dprintf("*************** Error in PDT# Src:%d\n", srcpdt);
		return;
	}
	if ( !pdt[srcpdt] ) return;		// ���S�̂���

	sys->LockPDT(srcpdt);

	if ( sx1>sx2 ) { temp=sx1; sx1=sx2; sx2=temp; }
	if ( sy1>sy2 ) { temp=sy1; sx1=sy2; sy2=temp; }
	if ( sx1<0   ) { sx1=0; }
	if ( sy1<0   ) { sy1=0; }
	if ( sx2>639 ) { sx2=639; }
	if ( sy2>479 ) { sy2=479; }
	if ( count>255 ) count = 255;
	if ( count<0   ) count = 0;
	count++;		// >>8�Ōv�Z����̂�

	srcbpl = pdt[srcpdt]->GetBPL();
	srcbpp = pdt[srcpdt]->GetBPP();
	srcbuf = pdt[srcpdt]->GetBuffer();
	if ( !srcpdt ) srcbuf++;

	srcbuf += sy1*srcbpl+(sx1*srcbpp);
	for(y=sy1; y<=sy2; y++) {
		src = srcbuf;
		for (x=sx1; x<=sx2; x++) {
			temp = src[0];
			temp += (((r-temp)*count)>>8);
			src[0] = temp;
			temp = src[1];
			temp += (((g-temp)*count)>>8);
			src[1] = temp;
			temp = src[2];
			temp += (((b-temp)*count)>>8);
			src[2] = temp;
			src += srcbpp;
		}
		srcbuf += srcbpl;
	}
	sys->UnlockPDT(srcpdt, sx1, sy1, sx2, sy2, update);
};


// ���b�Z�[�W�E�B���h�E�̂�[�ȐF�}�X�N��������
void PDTMGR::MakeColorMask(int sx1, int sy1, int sx2, int sy2, int srcpdt, int r, int g, int b)
{
	unsigned char *src, *srcbuf;
	int srcbpp, srcbpl, x, y;
	int temp;
	int update = 1;

	if ( srcpdt<0 ) { srcpdt = 0; update = 0; }
	if ( srcpdt>MAXPDT ) {
		dprintf("*************** Error in PDT# Src:%d\n", srcpdt);
		return;
	}
	if ( !pdt[srcpdt] ) return;		// ���S�̂���

	sys->LockPDT(srcpdt);

	if ( sx1>sx2 ) { temp=sx1; sx1=sx2; sx2=temp; }
	if ( sy1>sy2 ) { temp=sy1; sx1=sy2; sy2=temp; }
	if ( sx1<0   ) { sx1=0; }
	if ( sy1<0   ) { sy1=0; }
	if ( sx2>639 ) { sx2=639; }
	if ( sy2>479 ) { sy2=479; }
	if ( r>255 ) r = 255;
	if ( r<0   ) r = 0;
	if ( g>255 ) g = 255;
	if ( g<0   ) g = 0;
	if ( b>255 ) b = 255;
	if ( b<0   ) b = 0;

	r++;		// >>8�p
	g++;
	b++;

	srcbpp = pdt[srcpdt]->GetBPP();
	srcbpl = pdt[srcpdt]->GetBPL();
	srcbuf = pdt[srcpdt]->GetBuffer();
	if ( !srcpdt ) srcbuf++;

	srcbuf += sy1*srcbpl+(sx1*srcbpp);
	for(y=sy1; y<=sy2; y++) {
		src = srcbuf;
		for (x=sx1; x<=sx2; x++) {
			temp = ((src[0]*r)>>8);
			src[0] = temp;
			temp = ((src[1]*g)>>8);
			src[1] = temp;
			temp = ((src[2]*b)>>8);
			src[2] = temp;
			src += srcbpp;
		}
		srcbuf += srcbpl;
	}
	sys->UnlockPDT(srcpdt, sx1, sy1, sx2, sy2, update);
};


void PDTMGR::MakeMonochrome(int sx1, int sy1, int sx2, int sy2, int srcpdt)
{
	unsigned char *src, *srcbuf;
	int srcbpl, srcbpp, x, y;
	int temp, r, g, b;
	int update = 1;

	if ( srcpdt<0 ) { srcpdt = 0; update = 0; }
	if ( srcpdt>MAXPDT ) {
		dprintf("*************** Error in PDT# Src:%d\n", srcpdt);
		return;
	}
	if ( !pdt[srcpdt] ) return;		// ���S�̂���

	sys->LockPDT(srcpdt);

	if ( sx1>sx2 ) { temp=sx1; sx1=sx2; sx2=temp; }
	if ( sy1>sy2 ) { temp=sy1; sx1=sy2; sy2=temp; }
	if ( sx1<0   ) { sx1=0; }
	if ( sy1<0   ) { sy1=0; }
	if ( sx2>639 ) { sx2=639; }
	if ( sy2>479 ) { sy2=479; }

	srcbpl = pdt[srcpdt]->GetBPL();
	srcbpp = pdt[srcpdt]->GetBPP();
	srcbuf = pdt[srcpdt]->GetBuffer();
	if ( !srcpdt ) srcbuf++;

	srcbuf += sy1*srcbpl+(sx1*srcbpp);
	for(y=sy1; y<=sy2; y++) {
		src = srcbuf;
		for (x=sx1; x<=sx2; x++) {
			r = src[0];
			g = src[1];
			b = src[2];
			temp = (r*3+g*4+b*3)/10;
			src[0] = temp;
			src[1] = temp;
			src[2] = temp;
			src += srcbpp;
		}
		srcbuf += srcbpl;
	}
	sys->UnlockPDT(srcpdt, sx1, sy1, sx2, sy2, update);
};


void PDTMGR::MakeInvert(int sx1, int sy1, int sx2, int sy2, int srcpdt)
{
	unsigned char *src, *srcbuf;
	int srcbpl, srcbpp, x, y;
	int temp;
	int update = 1;

	if ( srcpdt<0 ) { srcpdt = 0; update = 0; }
	if ( srcpdt>MAXPDT ) {
		dprintf("*************** Error in PDT# Src:%d\n", srcpdt);
		return;
	}
	if ( !pdt[srcpdt] ) return;		// ���S�̂���

	sys->LockPDT(srcpdt);

	if ( sx1>sx2 ) { temp=sx1; sx1=sx2; sx2=temp; }
	if ( sy1>sy2 ) { temp=sy1; sx1=sy2; sy2=temp; }
	if ( sx1<0   ) { sx1=0; }
	if ( sy1<0   ) { sy1=0; }
	if ( sx2>639 ) { sx2=639; }
	if ( sy2>479 ) { sy2=479; }

	srcbpl = pdt[srcpdt]->GetBPL();
	srcbpp = pdt[srcpdt]->GetBPP();
	srcbuf = pdt[srcpdt]->GetBuffer();
	if ( !srcpdt ) srcbuf++;

	srcbuf += sy1*srcbpl+(sx1*srcbpp);
	for(y=sy1; y<=sy2; y++) {
		src = srcbuf;
		for (x=sx1; x<=sx2; x++) {
			src[0] = ~(src[0]);
			src[1] = ~(src[1]);
			src[2] = ~(src[2]);
			src += srcbpp;
		}
		srcbuf += srcbpl;
	}
	sys->UnlockPDT(srcpdt, sx1, sy1, sx2, sy2, update);
};


void PDTMGR::Swap(int sx1, int sy1, int sx2, int sy2, int srcpdt, int dx, int dy, int dstpdt)
{
	unsigned char *dst, *src, *srcbuf, *dstbuf;
	int srcbpl, dstbpl, srcbpp, dstbpp, x, y;
	int temp;
	int update = 1;

	if ( srcpdt<0 ) srcpdt = 0;
	if ( dstpdt<0 ) { dstpdt = 0; update = 0; }
	if ( (srcpdt>MAXPDT)||(dstpdt>MAXPDT) ) {
		dprintf("*************** Error in PDT# Src:%d Dst:%d\n", srcpdt, dstpdt);
		return;
	}
	if ( !pdt[srcpdt] ) return;		// ���S�̂���
	if ( !pdt[dstpdt] ) pdt[dstpdt] = new PDTBUFFER(640, 480, 3, 640*3, true);
	if ( !pdt[dstpdt] ) return;		// ���S�̂���

	if ( sx1>sx2          ) { temp=sx1; sx1=sx2; sx2=temp; }
	if ( sy1>sy2          ) { temp=sy1; sx1=sy2; sy2=temp; }
	if ( sx1<0            ) { dx-=sx1; sx1=0; }
	if ( sy1<0            ) { dy-=sy1; sy1=0; }
	if ( sx2>639          ) { sx2=639; }
	if ( sy2>479          ) { sy2=479; }
	if ( dx<0             ) { sx1-=dx; dx=0; }
	if ( dy<0             ) { sy1-=dy; dy=0; }
	if ( dx+(sx2-sx1)>639 ) { sx2-=(dx+(sx2-sx1)-639); }
	if ( dy+(sy2-sy1)>479 ) { sy2-=(dy+(sy2-sy1)-479); }

	srcbpl = pdt[srcpdt]->GetBPL();
	dstbpl = pdt[dstpdt]->GetBPL();
	srcbpp = pdt[srcpdt]->GetBPP();
	dstbpp = pdt[dstpdt]->GetBPP();
	srcbuf = pdt[srcpdt]->GetBuffer();
	if ( !srcpdt ) {
		srcbuf++;
		sys->LockPDT(srcpdt);
	}
	dstbuf = pdt[dstpdt]->GetBuffer();
	if ( !dstpdt ) {
		dstbuf++;
		if (srcpdt) sys->LockPDT(dstpdt);
	}

	srcbuf += sy1*srcbpl+(sx1*srcbpp);
	dstbuf += dy*dstbpl+(dx*dstbpp);
	for (y=sy1; y<=sy2; y++) {
		src = srcbuf;
		dst = dstbuf;
		for (x=sx1; x<=sx2; x++) {
			temp = src[0];
			src[0] = dst[0];
			dst[0] = temp;
			temp = src[1];
			src[1] = dst[1];
			dst[1] = temp;
			temp = src[2];
			src[2] = dst[2];
			dst[2] = temp;
			src += srcbpp;
			dst += dstbpp;
		}
		srcbuf += srcbpl;
		dstbuf += dstbpl;
	}

	if ( !srcpdt ) {
		sys->UnlockPDT(dstpdt, sx1, sy1, sx2, sy2, update);
	} else {
		sys->UnlockPDT(dstpdt, dx, dy, sx2-sx1+dx, sy2-sy1+dy, update);
	}
};


void PDTMGR::DrawString(int dx, int dy, int dstpdt, int r, int g, int b, char* s)
{
	RGBColor col, colbk;
	FontInfo info;
	int len, y/*, i*/;

	len = 0;
	while (s[len]) len++;

	len++;
	len *= (sys->GetFontX()+1);

	if ( dstpdt>0 ) {
		Copy(dx, dy, dx+len, dy+sys->GetFontY(), 0, dx, dy, BACKUPPDT, 0);
		Copy(dx, dy, dx+len, dy+sys->GetFontY(), dstpdt, dx, dy, -1, 0);
	}
	sys->LockPDT(0);
	TextFont(sys->GetFontID());
	TextSize(sys->GetFontSize());
	GetForeColor(&colbk);
	GetFontInfo(&info);
	y = dy+sys->GetFontSize()+(info.leading)/3-4;
	col.red   = (r<<8);
	col.green = (g<<8);
	col.blue  = (b<<8);
	RGBForeColor(&col);
	MoveTo(dx, dy + sys->GetFontSize());
	DrawText(s, 0, strlen(s));
//	for (i=0; (s[i]); ) {
//		MoveTo(dx+i*sys->GetFontX(), y);
//		if ( (*(unsigned char*)s)>=0x80 ) {
//			DrawText(s, i, 2);
//			i += 2;
//		} else {
//			DrawText(s, i, 1);
//			i++;
//		}
//	}
	RGBForeColor(&colbk);
	if ( !dstpdt )
		sys->UnlockPDT(0, dx, dy, dx+len, dy+sys->GetFontY(), 1);
	else
		sys->UnlockPDT(0, 0, 0, 0, 0, 0);
	if ( dstpdt>0 ) {
		Copy(dx, dy, dx+len, dy+sys->GetFontY(), 0, dx, dy, dstpdt, 0);
		Copy(dx, dy, dx+len, dy+sys->GetFontY(), BACKUPPDT, dx, dy, -1, 0);
	}
};



/* -------------------------------------------------------------------
  �G�t�F�N�g�����B�ꕔ�������čœK�����I����Ă܂���i��
------------------------------------------------------------------- */
// �h�b�g�ɂ��^���t�F�[�h�A�E�g�p�̃f�[�^
static const int EFF4X[16] = {0,2,0,2,1,3,1,3,0,2,0,2,1,3,1,3};
static const int EFF4Y[16] = {0,2,2,0,1,3,3,1,1,3,3,1,0,2,2,0};
static const int EFF61X[16] = {0,1,2,3,3,3,3,2,1,0,0,0,1,2,2,1};
static const int EFF61Y[16] = {0,0,0,0,1,2,3,3,3,3,2,1,1,1,2,2};
static const int EFF62X[16] = {0,1,2,3,0,1,2,3,0,1,2,3,0,1,2,3};
static const int EFF62Y[16] = {0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3};

void PDTMGR::Effect(EFFECT* e)
{
	unsigned char *dst, *src, *msk, *srcbuf, *dstbuf, *mskbuf, maskc;
	unsigned char *tmp, *tmpbuf;
	int srcbpp, srcbpl, dstbpp, dstbpl, mskbpl, x, y, xx, yy, xx2, yy2;
	int count, high, low, f1, f2, f3, f4;
	int temp, n, dif, fade, i, maxx, maxy;
	int sx, sy, ex, ey;				// Updated Region
	int backupflag = 0;				// PDT3�ւ̃o�b�N�A�b�v���s�����ǂ���
	maskc = 255;

	if ( !sys->CheckSkip() ) {
		if ( (sys->GetCurrentTimer()-(e->prevtime))<e->steptime ) return;
	}
	e->prevtime = sys->GetCurrentTimer();

	if ( !pdt[e->srcpdt] ) return;		// ���S�̂���

	sys->LockPDT(e->dstpdt);

	if ( !pdt[e->dstpdt] ) pdt[e->dstpdt] = new PDTBUFFER(640, 480, 3, 640*3, true);
	if ( !pdt[e->dstpdt] ) return;		// ���S�̂���

	if ( (!e->curcount)&&(e->cmd!=9999) ) {
		if ( e->sx1>e->sx2 ) { temp=e->sx1; e->sx1=e->sx2; e->sx2=temp; }
		if ( e->sy1>e->sy2 ) { temp=e->sy1; e->sx1=e->sy2; e->sy2=temp; }
		if ( e->sx1<0 ) { e->dx-=e->sx1; e->sx1=0; }
		if ( e->sy1<0 ) { e->dy-=e->sy1; e->sy1=0; }
		if ( e->sx2>639 ) { e->sx2=639; }
		if ( e->sy2>479 ) { e->sy2=479; }
		if ( e->dx<0    ) { e->sx1-=e->dx; e->dx=0; }
		if ( e->dy<0    ) { e->sy1-=e->dy; e->dy=0; }
		if ( e->dx+(e->sx2-e->sx1)>639 ) { e->sx2-=(e->dx+(e->sx2-e->sx1)-639); }
		if ( e->dy+(e->sy2-e->sy1)>479 ) { e->sy2-=(e->dy+(e->sy2-e->sy1)-479); }
	}
	srcbpp = pdt[e->srcpdt]->GetBPP();
	srcbpl = pdt[e->srcpdt]->GetBPL();
	dstbpp = pdt[e->dstpdt]->GetBPP();
	dstbpl = pdt[e->dstpdt]->GetBPL();
	mskbpl = pdt[e->srcpdt]->GetSizeX();
	srcbuf = pdt[e->srcpdt]->GetBuffer();
	if ( !e->srcpdt ) srcbuf++;
	dstbuf = pdt[e->dstpdt]->GetBuffer();
	if ( !e->dstpdt ) dstbuf++;
	mskbuf = pdt[e->srcpdt]->GetMaskBuffer();
//e->cmd = 35;
//e->cmd=114;
//e->step=8;
	switch (e->cmd) {
		case 0:				// �\�����Ȃ��œ]������
			e->cmd = 0;
			break;

		case 2:				// �u�ԕ\��
			dprintf("  Effect#2 Display immidiately.\n");
			dprintf("  %d:(%d,%d)-(%d,%d) ->", e->srcpdt, e->sx1, e->sy1, e->sx2, e->sy2);
			dprintf(" %d:(%d,%d)\n", e->dstpdt, e->dx, e->dy);
			srcbuf += e->sy1*srcbpl+e->sx1*srcbpp;
			dstbuf += e->dy*dstbpl+e->dx*dstbpp;
			mskbuf += e->sy1*640+e->sx1;
			for(y=e->sy1; y<=e->sy2; y++) {
				src = srcbuf;
				dst = dstbuf;
				msk = mskbuf;
				for (x=e->sx1; x<=e->sx2; x++) {
					if (e->mask) maskc = *msk++;
					PDT_Pixel(src, dst, maskc);
					src += srcbpp;
					dst += dstbpp;
				}
				srcbuf += srcbpl;
				dstbuf += dstbpl;
				mskbuf += 640;
			}
			e->cmd = 0;
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;

		case 4:				// �h�b�g�ɂ��^���t�F�[�h�C���^�A�E�g
		case 5:				// �����H
//dprintf("   Effect#4 in progress ... %d/16\n", e->curcount+1);
			srcbuf += (e->sy1+EFF4Y[e->curcount])*srcbpl+((e->sx1+EFF4X[e->curcount])*srcbpp);
			dstbuf += (e->dy+EFF4Y[e->curcount])*dstbpl+((e->dx+EFF4X[e->curcount])*dstbpp);
			mskbuf += (e->sy1+EFF4Y[e->curcount])*640+e->sx1+EFF4X[e->curcount];
			for(y=e->sy1+EFF4Y[e->curcount]; y<=e->sy2; y+=4) {
				src = srcbuf;
				dst = dstbuf;
				msk = mskbuf;
				for (x=e->sx1+EFF4X[e->curcount]; x<=e->sx2; x+=4) {
					if (e->mask) { maskc = *msk; msk+=4; }
					PDT_Pixel(src, dst, maskc);
					src += (srcbpp<<2);
					dst += (dstbpp<<2);
				}
				srcbuf += (srcbpl<<2);
				dstbuf += (dstbpl<<2);
				mskbuf += 640*4;
			}
			e->curcount++;
			if ( e->curcount==16 ) {
				e->cmd = 0;
				backupflag = 1;			// #4 Buckuped
			}
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;
			
		case 10:			// �ォ��1���C������
			if ( !e->step ) e->step = 1;
			for (y=(e->curcount*e->step); y<((e->curcount+1)*e->step); y++) {
				if ( y<=(e->sy2-e->sy1) )  {
					src = srcbuf+(e->sy1+y)*srcbpl+(e->sx1)*srcbpp;
					dst = dstbuf+(e->dy+y)*dstbpl+(e->dx)*dstbpp;
					msk = mskbuf+(e->sy1+y)*mskbpl+(e->sx1);
					for (x=e->sx1; x<=e->sx2; x++) {
						if (e->mask) maskc = *msk++;
						PDT_Pixel(src, dst, maskc);
						src += srcbpp;
						dst += dstbpp;
					}
				} else e->cmd = 0;
			}
			sx = e->dx; sy = e->dy+(e->curcount*e->step);
			ex = e->dx+e->sx2-e->sx1; ey = e->dy+((e->curcount+1)*e->step-1);
			e->curcount++;
			break;

		case 11:			// ������1���C������
			if ( !e->step ) e->step = 1;
			for (y=(e->curcount*e->step); y<((e->curcount+1)*e->step); y++) {
				if ( y<=(e->sy2-e->sy1) )  {
					src = srcbuf+(e->sy2-y)*srcbpl+(e->sx1)*srcbpp;
					dst = dstbuf+(e->dy+e->sy2-e->sy1-y)*dstbpl+(e->dx)*dstbpp;
					msk = mskbuf+(e->sy2-y)*mskbpl+(e->sx1);
					for (x=e->sx1; x<=e->sx2; x++) {
						if (e->mask) maskc = *msk++;
						PDT_Pixel(src, dst, maskc);
						src += srcbpp;
						dst += dstbpp;
					}
				} else e->cmd = 0;
			}
			sx = e->dx; ey = e->dy+e->sy2-e->sy1-(e->curcount*e->step);
			ex = e->dx+e->sx2-e->sx1; sy = e->dy+e->sy2-e->sy1-((e->curcount+1)*e->step-1);
			e->curcount++;
			break;
			
		case 12:			// ������1���C������
			if ( !e->step ) e->step = 1;
			for (x=(e->curcount*e->step); x<((e->curcount+1)*e->step); x++) {
				if ( x<=(e->sx2-e->sx1) ) {
					src = srcbuf+(e->sy1)*srcbpl+(e->sx1+x)*srcbpp;
					dst = dstbuf+(e->dy)*dstbpl+(e->dx+x)*dstbpp;
					msk = mskbuf+(e->sy1)*mskbpl+(e->sx1+x);
					for(y=e->sy1; y<=e->sy2; y++) {
						if (e->mask) maskc = *msk;
						PDT_Pixel(src, dst, maskc);
						src += srcbpl;
						dst += dstbpl;
						msk += mskbpl;
					}
				} else e->cmd = 0;
			}
			sx = e->dx+(e->curcount*e->step); sy = e->dy;
			ex = e->dx+((e->curcount+1)*e->step); ey = e->dy+e->sy2-e->sy1;
			e->curcount++;
			break;
			
		case 13:			// �E����1���C������
			if ( !e->step ) e->step = 1;
			for (x=(e->curcount*e->step); x<((e->curcount+1)*e->step); x++) {
				if ( x<=(e->sx2-e->sx1) ) {
					src = srcbuf+(e->sy1)*srcbpl+(e->sx2-x)*srcbpp;
					dst = dstbuf+(e->dy)*dstbpl+(e->dx+e->sx2-e->sx1-x)*dstbpp;
					msk = mskbuf+(e->sy1)*mskbpl+(e->sx2-x);
					for(y=e->sy1; y<=e->sy2; y++) {
						if (e->mask) maskc = *msk;
						PDT_Pixel(src, dst, maskc);
						src += srcbpl;
						dst += dstbpl;
						msk += mskbpl;
					}
				} else e->cmd = 0;
			}
			ex = e->dx+e->sx2-e->sx1-(e->curcount*e->step); sy = e->dy;
			sx = e->dx+e->sx2-e->sx1-((e->curcount+1)*e->step); ey = e->dy+e->sy2-e->sy1;
			e->curcount++;
			break;
			
		case 15:			// ���փX�N���[��
			if ( !e->step ) e->step = 1;
			e->curcount += e->step;
			if ( e->curcount>(e->sy2-e->sy1) )  {
				e->step -= (e->curcount-(e->sy2-e->sy1+1));
				e->curcount = e->sy2-e->sy1;
			}
			for(y=e->dy+(e->sy2-e->sy1); y>=e->dy; y--) {
				if ( (y-e->step)<e->dy ) {
					src = srcbuf+(e->sy2-(e->dy-(y-e->curcount)))*srcbpl+(e->sx1)*srcbpp;
					dst = dstbuf+y*dstbpl+(e->dx)*dstbpp;
//					msk = mskbuf+(y-dif)*mskbpl+(e->sx1);
					for (x=e->sx1; x<=e->sx2; x++) {
//						maskc = *msk++;
//						PDT_Pixel(src, dst, 255);
						dst[0] = src[0];
						dst[1] = src[1];
						dst[2] = src[2];
						src += srcbpp;
						dst += dstbpp;
					}
				} else {
					src = dstbuf+(y-e->step)*dstbpl+(e->dx)*dstbpp;
					dst = dstbuf+y*dstbpl+(e->dx)*dstbpp;
//					msk = mskbuf+(y-dif)*mskbpl+(e->sx1);
					for (x=e->dx; x<=(e->dx+(e->sx2-e->sx1)); x++) {
//						maskc = *msk++;
//						PDT_Pixel(src, dst, 255);
						dst[0] = src[0];
						dst[1] = src[1];
						dst[2] = src[2];
						src += dstbpp;
						dst += dstbpp;
					}
				}
			}
			if ( e->curcount>=(e->sy2-e->sy1) ) e->cmd = 0;
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;
			
		case 16:			// ��փX�N���[��
			if ( !e->step ) e->step = 1;
			e->curcount += e->step;
			if ( e->curcount>(e->sy2-e->sy1) )  {
				e->step -= (e->curcount-(e->sy2-e->sy1+1));
				e->curcount = e->sy2-e->sy1;
			}
			for(y=e->dy; y<=e->dy+(e->sy2-e->sy1); y++) {
				if ( (y+e->step)>(e->dy+(e->sy2-e->sy1)) ) {
					src = srcbuf+(e->sy1+y+e->curcount-(e->dy+(e->sy2-e->sy1)))*srcbpl+(e->sx1)*srcbpp;
					dst = dstbuf+y*dstbpl+(e->dx)*dstbpp;
//					msk = mskbuf+(y-dif)*mskbpl+(e->sx1);
					for (x=e->sx1; x<=e->sx2; x++) {
//						maskc = *msk++;
//						PDT_Pixel(src, dst, 255);
						dst[0] = src[0];
						dst[1] = src[1];
						dst[2] = src[2];
						src += srcbpp;
						dst += dstbpp;
					}
				} else {
					src = dstbuf+(y+e->step)*dstbpl+(e->dx)*dstbpp;
					dst = dstbuf+y*dstbpl+(e->dx)*dstbpp;
//					msk = mskbuf+(y-dif)*mskbpl+(e->sx1);
					for (x=e->dx; x<=(e->dx+(e->sx2-e->sx1)); x++) {
//						maskc = *msk++;
//						PDT_Pixel(src, dst, 255);
						dst[0] = src[0];
						dst[1] = src[1];
						dst[2] = src[2];
						src += dstbpp;
						dst += dstbpp;
					}
				}
			}
			if ( e->curcount>=(e->sy2-e->sy1) ) e->cmd = 0;
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;
			
		case 17:			// �E�փX�N���[��
			if ( !e->step ) e->step = 1;
			e->curcount += e->step;
			if ( e->curcount>(e->sx2-e->sx1) )  {
				e->step -= (e->curcount-(e->sx2-e->sx1+1));
				e->curcount = e->sx2-e->sx1;
			}
			for (x=e->dx+(e->sx2-e->sx1); x>=e->dx; x--) {
				if ( (x-e->step)<e->dx ) {
					src = srcbuf+(e->sy1)*srcbpl+(e->sx2-(e->dx-(x-e->curcount)))*srcbpp;
					dst = dstbuf+(e->dy)*dstbpl+x*dstbpp;
//					msk = mskbuf+(e->sy1)*mskbpl+(e->sx2-(e->dx-(x-e->curcount)))*srcbpp;
					for(y=e->sy1; y<=e->sy2; y++) {
//						maskc = *msk++;
//						PDT_Pixel(src, dst, maskc);
						dst[0] = src[0];
						dst[1] = src[1];
						dst[2] = src[2];
						src += srcbpl;
						dst += dstbpl;
					}
				} else {
					src = dstbuf+(e->dy)*dstbpl+(x-e->step)*dstbpp;
					dst = dstbuf+(e->dy)*dstbpl+x*dstbpp;
//					msk = mskbuf+(y-dif)*mskbpl+(e->sx1);
					for (y=e->dy; y<=(e->dy+(e->sy2-e->sy1)); y++) {
//						maskc = *msk++;
//						PDT_Pixel(src, dst, 255);
						dst[0] = src[0];
						dst[1] = src[1];
						dst[2] = src[2];
						src += dstbpl;
						dst += dstbpl;
					}
				}
			}
			if ( e->curcount>=(e->sx2-e->sx1) ) e->cmd = 0;
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;
			
		case 18:			// ���փX�N���[��
			if ( !e->step ) e->step = 1;
			e->curcount += e->step;
			if ( e->curcount>(e->sx2-e->sx1) )  {
				e->step -= (e->curcount-(e->sx2-e->sx1+1));
				e->curcount = e->sx2-e->sx1;
			}
			for (x=e->dx; x<=(e->dx+e->sx2-e->sx1); x++) {
				if ( (x+e->step)>e->dx+(e->sx2-e->sx1) ) {
					src = srcbuf+(e->sy1)*srcbpl+(e->sx1+x+e->curcount-(e->dx+(e->sx2-e->sx1)))*srcbpp;
					dst = dstbuf+(e->dy)*dstbpl+x*dstbpp;
//					msk = mskbuf+(y-dif)*mskbpl+(e->sx1);
					for(y=e->sy1; y<=e->sy2; y++) {
//						maskc = *msk++;
//						PDT_Pixel(src, dst, 255);
						dst[0] = src[0];
						dst[1] = src[1];
						dst[2] = src[2];
						src += srcbpl;
						dst += dstbpl;
					}
				} else {
					src = dstbuf+(e->dy)*dstbpl+(x+e->step)*dstbpp;
					dst = dstbuf+(e->dy)*dstbpl+x*dstbpp;
//					msk = mskbuf+(y-dif)*mskbpl+(e->sx1);
					for (y=e->dy; y<=(e->dy+(e->sy2-e->sy1)); y++) {
//						maskc = *msk++;
//						PDT_Pixel(src, dst, 255);
						dst[0] = src[0];
						dst[1] = src[1];
						dst[2] = src[2];
						src += dstbpl;
						dst += dstbpl;
					}
				}
			}
			if ( e->curcount>=(e->sx2-e->sx1) ) e->cmd = 0;
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;
			
		case 20:			// ���փX���C�h
			if ( !e->step ) e->step = 1;
			e->curcount += e->step;
			if ( e->curcount>(e->sy2-e->sy1) )  {
				e->step -= (e->curcount-(e->sy2-e->sy1+1));
				e->curcount = e->sy2-e->sy1;
			}
			for(y=e->dy+(e->sy2-e->sy1); y>=e->dy; y--) {
				if ( (y-e->curcount)<e->dy ) {
					src = srcbuf+(e->sy2-(e->dy-(y-e->curcount)))*srcbpl+(e->sx1)*srcbpp;
					dst = dstbuf+y*dstbpl+(e->dx)*dstbpp;
//					msk = mskbuf+(y-dif)*mskbpl+(e->sx1);
					for (x=e->sx1; x<=e->sx2; x++) {
//						maskc = *msk++;
//						PDT_Pixel(src, dst, 255);
						dst[0] = src[0];
						dst[1] = src[1];
						dst[2] = src[2];
						src += srcbpp;
						dst += dstbpp;
					}
				}
			}
			if ( e->curcount>=(e->sy2-e->sy1) ) e->cmd = 0;
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->curcount;
			break;
			
		case 21:			// ��փX���C�h
			if ( !e->step ) e->step = 1;
			e->curcount += e->step;
			if ( e->curcount>(e->sy2-e->sy1) )  {
				e->step -= (e->curcount-(e->sy2-e->sy1+1));
				e->curcount = e->sy2-e->sy1;
			}
			for(y=e->dy; y<=e->dy+(e->sy2-e->sy1); y++) {
				if ( (y+e->curcount)>(e->dy+(e->sy2-e->sy1)) ) {
					src = srcbuf+(e->sy1+y+e->curcount-(e->dy+(e->sy2-e->sy1)))*srcbpl+(e->sx1)*srcbpp;
					dst = dstbuf+y*dstbpl+(e->dx)*dstbpp;
//					msk = mskbuf+(y-dif)*mskbpl+(e->sx1);
					for (x=e->sx1; x<=e->sx2; x++) {
//						maskc = *msk++;
//						PDT_Pixel(src, dst, 255);
						dst[0] = src[0];
						dst[1] = src[1];
						dst[2] = src[2];
						src += srcbpp;
						dst += dstbpp;
					}
				}
			}
			if ( e->curcount>=(e->sy2-e->sy1) ) e->cmd = 0;
			sx = e->dx; sy = e->dy+e->curcount; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;
			
		case 22:			// �E�փX���C�h
			if ( !e->step ) e->step = 1;
			e->curcount += e->step;
			if ( e->curcount>(e->sx2-e->sx1) )  {
				e->step -= (e->curcount-(e->sx2-e->sx1+1));
				e->curcount = e->sx2-e->sx1;
			}
			for (x=e->dx+(e->sx2-e->sx1); x>=e->dx; x--) {
				if ( (x-e->curcount)<e->dx ) {
					src = srcbuf+(e->sy1)*srcbpl+(e->sx2-(e->dx-(x-e->curcount)))*srcbpp;
					dst = dstbuf+(e->dy)*dstbpl+x*dstbpp;
//					msk = mskbuf+(y-dif)*mskbpl+(e->sx1);
					for(y=e->sy1; y<=e->sy2; y++) {
//						maskc = *msk++;
//						PDT_Pixel(src, dst, 255);
						dst[0] = src[0];
						dst[1] = src[1];
						dst[2] = src[2];
						src += srcbpl;
						dst += dstbpl;
					}
				}
			}
			if ( e->curcount>=(e->sx2-e->sx1) ) e->cmd = 0;
			sx = e->dx; sy = e->dy; ex = e->dx+e->curcount; ey = e->dy+e->sy2-e->sy1;
			break;
			
		case 23:			// ���փX���C�h
			if ( !e->step ) e->step = 1;
			e->curcount += e->step;
			if ( e->curcount>(e->sx2-e->sx1) )  {
				e->step -= (e->curcount-(e->sx2-e->sx1+1));
				e->curcount = e->sx2-e->sx1;
			}
			for (x=e->dx; x<=(e->dx+e->sx2-e->sx1); x++) {
				if ( (x+e->curcount)>e->dx+(e->sx2-e->sx1) ) {
					src = srcbuf+(e->sy1)*srcbpl+(e->sx1+x+e->curcount-(e->dx+(e->sx2-e->sx1)))*srcbpp;
					dst = dstbuf+(e->dy)*dstbpl+x*dstbpp;
//					msk = mskbuf+(y-dif)*mskbpl+(e->sx1);
					for(y=e->sy1; y<=e->sy2; y++) {
//						maskc = *msk++;
//						PDT_Pixel(src, dst, 255);
						dst[0] = src[0];
						dst[1] = src[1];
						dst[2] = src[2];
						src += srcbpl;
						dst += dstbpl;
					}
				}
			}
			if ( e->curcount>=(e->sx2-e->sx1) ) e->cmd = 0;
			sx = e->dx+e->curcount; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;
			
		case 25:			// ��������l�p���L����
			xx  = ((e->sx2-e->sx1)/2)-e->curcount;
			yy  = ((e->sy2-e->sy1)/2)-e->curcount;
			xx2 = ((e->sx2-e->sx1)/2)+e->curcount+1;
			yy2 = ((e->sy2-e->sy1)/2)+e->curcount+1;
			if ( xx<0 ) xx = 0;
			if ( yy<0 ) yy = 0;
			if ( xx2>(e->sx2-e->sx1) ) xx2 = (e->sx2-e->sx1);
			if ( yy2>(e->sy2-e->sy1) ) yy2 = (e->sy2-e->sy1);
			src = srcbuf + (e->sy1+yy)*srcbpl+(e->sx1+xx)*srcbpp;
			dst = dstbuf + (e->dy+yy)*dstbpl+(e->dx+xx)*dstbpp;
			msk = mskbuf + (e->sy1+yy)*640+(e->sx1+xx);
			for (x=xx; x<=xx2; x++) {
				if (e->mask) maskc = *msk++;
				PDT_Pixel(src, dst, maskc);
				src += srcbpp;
				dst += dstbpp;
			}
			src = srcbuf + (e->sy1+yy2)*srcbpl+(e->sx1+xx)*srcbpp;
			dst = dstbuf + (e->dy+yy2)*dstbpl+(e->dx+xx)*dstbpp;
			msk = mskbuf + (e->sy1+yy2)*640+(e->sx1+xx);
			for (x=xx; x<=xx2; x++) {
				if (e->mask) maskc = *msk++;
				PDT_Pixel(src, dst, maskc);
				src += srcbpp;
				dst += dstbpp;
			}
			src = srcbuf + (e->sy1+yy)*srcbpl+(e->sx1+xx)*srcbpp;
			dst = dstbuf + (e->dy+yy)*dstbpl+(e->dx+xx)*dstbpp;
			msk = mskbuf + (e->sy1+yy)*640+(e->sx1+xx);
			for (y=yy; y<=yy2; y++) {
				if (e->mask) maskc = *msk;
				PDT_Pixel(src, dst, maskc);
				src += srcbpl;
				dst += dstbpl;
				msk += mskbpl;
			}
			src = srcbuf + (e->sy1+yy)*srcbpl+(e->sx1+xx2)*srcbpp;
			dst = dstbuf + (e->dy+yy)*dstbpl+(e->dx+xx2)*dstbpp;
			msk = mskbuf + (e->sy1+yy)*640+(e->sx1+xx2);
			for (y=yy; y<=yy2; y++) {
				if (e->mask) maskc = *msk;
				PDT_Pixel(src, dst, maskc);
				src += srcbpl;
				dst += dstbpl;
				msk += mskbpl;
			}
			e->curcount++;
			if ( (e->curcount>((e->sx2-e->sx1)/2))&&(e->curcount>((e->sy2-e->sy1)/2)) ) e->cmd = 0;
 			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;

		case 26:			// �O���璆���֎l�p
			n = (((e->sx2-e->sx1)>(e->sy2-e->sy1))?((e->sx2-e->sx1)/2):((e->sy2-e->sy1)/2));
			n = n-e->curcount;
			xx  = ((e->sx2-e->sx1)/2)-n;
			yy  = ((e->sy2-e->sy1)/2)-n;
			xx2 = ((e->sx2-e->sx1)/2)+n+1;
			yy2 = ((e->sy2-e->sy1)/2)+n+1;
			f1 = f2 = f3 = f4 = 1;
			if ( xx<0 ) { xx = 0; f1 = 0; }
			if ( yy<0 ) { yy = 0; f2 = 0; }
			if ( xx2>(e->sx2-e->sx1) ) { xx2 = (e->sx2-e->sx1); f3 = 0; }
			if ( yy2>(e->sy2-e->sy1) ) { yy2 = (e->sy2-e->sy1); f4 = 0; }
			if ( f2 ) {
				src = srcbuf + (e->sy1+yy)*srcbpl+(e->sx1+xx)*srcbpp;
				dst = dstbuf + (e->dy+yy)*dstbpl+(e->dx+xx)*dstbpp;
				msk = mskbuf + (e->sy1+yy)*640+(e->sx1+xx);
				for (x=xx; x<=xx2; x++) {
					if (e->mask) maskc = *msk++;
					PDT_Pixel(src, dst, maskc);
					src += srcbpp;
					dst += dstbpp;
				}
			}
			if ( f4 ) {
				src = srcbuf + (e->sy1+yy2)*srcbpl+(e->sx1+xx)*srcbpp;
				dst = dstbuf + (e->dy+yy2)*dstbpl+(e->dx+xx)*dstbpp;
				msk = mskbuf + (e->sy1+yy2)*640+(e->sx1+xx);
				for (x=xx; x<=xx2; x++) {
					if (e->mask) maskc = *msk++;
					PDT_Pixel(src, dst, maskc);
					src += srcbpp;
					dst += dstbpp;
				}
			}
			if ( f1 ) {
				src = srcbuf + (e->sy1+yy)*srcbpl+(e->sx1+xx)*srcbpp;
				dst = dstbuf + (e->dy+yy)*dstbpl+(e->dx+xx)*dstbpp;
				msk = mskbuf + (e->sy1+yy)*640+(e->sx1+xx);
				for (y=yy; y<=yy2; y++) {
					if (e->mask) maskc = *msk;
					PDT_Pixel(src, dst, maskc);
					src += srcbpl;
					dst += dstbpl;
					msk += mskbpl;
				}
			}
			if ( f3 ) {
				src = srcbuf + (e->sy1+yy)*srcbpl+(e->sx1+xx2)*srcbpp;
				dst = dstbuf + (e->dy+yy)*dstbpl+(e->dx+xx2)*dstbpp;
				msk = mskbuf + (e->sy1+yy)*640+(e->sx1+xx2);
				for (y=yy; y<=yy2; y++) {
					if (e->mask) maskc = *msk;
					PDT_Pixel(src, dst, maskc);
					src += srcbpl;
					dst += dstbpl;
					msk += mskbpl;
				}
			}
			e->curcount++;
			if ( n<=0 ) e->cmd = 0;
 			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;

		case 30:			// �������C���͍�����A��͉E����1���C������
			x = ((e->sx1+e->curcount)&0xfffe);
			if ( (x>=e->sx1)&&(x<=e->sx2) ) {
				src = srcbuf+(e->sy1)*srcbpl+x*srcbpp;
				dst = dstbuf+(e->dy)*dstbpl+(x-e->sx1+e->dx)*dstbpp;
				msk = mskbuf+(e->sy1)*mskbpl+x;
				for(y=e->sy1; y<=e->sy2; y++) {
					if (e->mask) maskc = *msk;
					PDT_Pixel(src, dst, maskc);
					src += srcbpl;
					dst += dstbpl;
					msk += mskbpl;
				}
			}
			x = ((e->sx2-e->curcount)&0xfffe)+1;
			if ( (x>=e->sx1)&&(x<=e->sx2) ) {
				src = srcbuf+(e->sy1)*srcbpl+x*srcbpp;
				dst = dstbuf+(e->dy)*dstbpl+(x-e->sx1+e->dx)*dstbpp;
				msk = mskbuf+(e->sy1)*mskbpl+x;
				for(y=e->sy1; y<=e->sy2; y++) {
					if (e->mask) maskc = *msk;
					PDT_Pixel(src, dst, maskc);
					src += srcbpl;
					dst += dstbpl;
					msk += mskbpl;
				}
			}
			if (e->curcount>(e->sx2-e->sx1)) e->cmd = 0;
			e->curcount+=2;
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;
			
		case 31:			// �������C���͏ォ��A��͉�����1���C������
			y = ((e->sy1+e->curcount)&0xfffe);
			if ( (y>=e->sy1)&&(y<=e->sy2) ) {
				src = srcbuf+y*srcbpl+e->sx1*srcbpp;
				dst = dstbuf+(y-e->sy1+e->dy)*dstbpl+e->dx*dstbpp;
				msk = mskbuf+y*mskbpl+e->sx1;
				for(x=e->sx1; x<=e->sx2; x++) {
					if (e->mask) maskc = *msk++;
					PDT_Pixel(src, dst, maskc);
					src += srcbpp;
					dst += dstbpp;
				}
			}
			y = ((e->sy2-e->curcount)&0xfffe)+1;
			if ( (y>=e->sy1)&&(y<=e->sy2) ) {
				src = srcbuf+y*srcbpl+e->sx1*srcbpp;
				dst = dstbuf+(y-e->sy1+e->dy)*dstbpl+e->dx*dstbpp;
				msk = mskbuf+y*mskbpl+e->sx1;
				for(x=e->sx1; x<=e->sx2; x++) {
					if (e->mask) maskc = *msk++;
					PDT_Pixel(src, dst, maskc);
					src += srcbpp;
					dst += dstbpp;
				}
			}
			if (e->curcount>(e->sy2-e->sy1)) e->cmd = 0;
			e->curcount+=2;
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;
			
		case 35:			// �������C���͍�����A��͉E����S���C����Ă�
			if ( !e->step ) e->step = 32;
			if ( !e->arg5 ) e->arg5 = 1;
			if ( !e->curcount ) {	// �X�N���[���o�b�t�@���R�s�[
				if ( temppdt ) {
					delete temppdt;
					temppdt = 0;
				}
				temppdt = new PDTBUFFER(640, 480, 3, 640*3, true);
				if ( !temppdt ) break;
				tmpbuf = temppdt->GetBuffer();
				for (y=0; y<=479; y++) {
					dst = dstbuf;
					tmp = tmpbuf;
					for (x=0; x<=639; x++) {
						tmp[0] = dst[0];
						tmp[1] = dst[1];
						tmp[2] = dst[2];
						dst += dstbpp;
						tmp += 3;
					}
					dstbuf += dstbpl;
					tmpbuf += 640*3;
				}
				tmpbuf = temppdt->GetBuffer();
				dstbuf = pdt[e->dstpdt]->GetBuffer();
				if ( !e->dstpdt ) dstbuf++;
			} else {
				if ( !temppdt ) break;
				tmpbuf = temppdt->GetBuffer();
			}
			e->curcount += e->step;
			if ( e->curcount>=(e->sx2-e->sx1) ) e->curcount = (e->sx2-e->sx1);
			for (y=0; y<=(e->sy2-e->sy1); y++) {
				if ( (y/e->arg5)&1 ) {
					xx = 0; n = 0;
					xx2 = e->curcount;
					src = srcbuf+(y+e->sy1)*srcbpl+e->sx1*srcbpp;
					dst = dstbuf+(y+e->dy)*dstbpl+(e->sx2-e->sx1+e->dx-xx2)*dstbpp;
					tmp = tmpbuf+(y+e->dy)*640+(e->sx2-e->sx1+e->dx-xx2)*3;
					msk = mskbuf+(y+e->sy1)*mskbpl+e->sx1;
					for (x=xx; x<=xx2; x++) {
						if (e->mask) n = 256-(*msk++);
						temp = src[0]+((n*tmp[0])>>8);
						if ( temp>0xff ) temp = 0xff;
						dst[0] = (unsigned char)temp;
						temp = src[1]+((n*tmp[1])>>8);
						if ( temp>0xff ) temp = 0xff;
						dst[1] = (unsigned char)temp;
						temp = src[2]+((n*tmp[2])>>8);
						if ( temp>0xff ) temp = 0xff;
						dst[2] = (unsigned char)temp;
						src += srcbpp;
						dst += dstbpp;
						tmp += 3;
					}
				} else {
					xx = 0; n = 0;
					xx2 = e->curcount;
					src = srcbuf+(y+e->sy1)*srcbpl+(e->sx2-xx2)*srcbpp;
					dst = dstbuf+(y+e->dy)*dstbpl+e->dx*dstbpp;
					tmp = tmpbuf+(y+e->dy)*640+e->dx*3;
					msk = mskbuf+(y+e->sy1)*mskbpl+(e->sx2-xx2);
					for (x=xx; x<=xx2; x++) {
						if (e->mask) n = 256-(*msk++);
						temp = src[0]+((n*tmp[0])>>8);
						if ( temp>0xff ) temp = 0xff;
						dst[0] = (unsigned char)temp;
						temp = src[1]+((n*tmp[1])>>8);
						if ( temp>0xff ) temp = 0xff;
						dst[1] = (unsigned char)temp;
						temp = src[2]+((n*tmp[2])>>8);
						if ( temp>0xff ) temp = 0xff;
						dst[2] = (unsigned char)temp;
						src += srcbpp;
						dst += dstbpp;
						tmp += 3;
					}
				}
			}
			if ( e->curcount>=(e->sx2-e->sx1) ) {
				e->cmd = 0;
				if ( temppdt ) delete temppdt;
				temppdt = 0;
			}
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;

		case 36:			// �������C���͏ォ��A��͉�����S���C����Ă�
			if ( !e->step ) e->step = 32;
			if ( !e->arg5 ) e->arg5 = 1;
			if ( !e->curcount ) {	// �X�N���[���o�b�t�@���R�s�[
				if ( temppdt ) {
					delete temppdt;
					temppdt = 0;
				}
				temppdt = new PDTBUFFER(640, 480, 3, 640*3, true);
				if ( !temppdt ) break;
				tmpbuf = temppdt->GetBuffer();
				for (y=0; y<=479; y++) {
					dst = dstbuf;
					tmp = tmpbuf;
					for (x=0; x<=639; x++) {
						tmp[0] = dst[0];
						tmp[1] = dst[1];
						tmp[2] = dst[2];
						dst += dstbpp;
						tmp += 3;
					}
					dstbuf += dstbpl;
					tmpbuf += 640*3;
				}
				tmpbuf = temppdt->GetBuffer();
				dstbuf = pdt[e->dstpdt]->GetBuffer();
				if ( !e->dstpdt ) dstbuf++;
			} else {
				if ( !temppdt ) break;
				tmpbuf = temppdt->GetBuffer();
			}
			e->curcount += e->step;
			if ( e->curcount>=(e->sy2-e->sy1) ) e->curcount = (e->sy2-e->sy1);
			for (x=0; x<=(e->sx2-e->sx1); x++) {
				if ( (x/e->arg5)&1 ) {
					yy = 0; n = 0;
					yy2 = e->curcount;
					src = srcbuf+(e->sy1)*srcbpl+(e->sx1+x)*srcbpp;
					dst = dstbuf+(e->dy+e->sy2-e->sy1-yy2)*dstbpl+(e->dx+x)*dstbpp;
					tmp = tmpbuf+(e->dy+e->sy2-e->sy1-yy2)*640+(e->dx+x)*3;
					msk = mskbuf+(e->sy1)*mskbpl+(x+e->sx1);
					for (y=yy; y<=yy2; y++) {
						if (e->mask) n = 256-(*msk);
						temp = src[0]+((n*tmp[0])>>8);
						if ( temp>0xff ) temp = 0xff;
						dst[0] = (unsigned char)temp;
						temp = src[1]+((n*tmp[1])>>8);
						if ( temp>0xff ) temp = 0xff;
						dst[1] = (unsigned char)temp;
						temp = src[2]+((n*tmp[2])>>8);
						if ( temp>0xff ) temp = 0xff;
						dst[2] = (unsigned char)temp;
						src += srcbpl;
						dst += dstbpl;
						tmp += 640*3;
						msk += mskbpl;
					}
				} else {
					yy = 0; n = 0;
					yy2 = e->curcount;
					src = srcbuf+(e->sy2-yy2)*srcbpl+(x+e->sx1)*srcbpp;
					dst = dstbuf+(e->dy)*dstbpl+(x+e->dx)*dstbpp;
					tmp = tmpbuf+(e->dy)*640+(x+e->dx)*3;
					msk = mskbuf+(e->sy2-yy2)*mskbpl+(x+e->sx1);
					for (y=yy; y<=yy2; y++) {
						if (e->mask) n = 256-(*msk);
						temp = src[0]+((n*tmp[0])>>8);
						if ( temp>0xff ) temp = 0xff;
						dst[0] = (unsigned char)temp;
						temp = src[1]+((n*tmp[1])>>8);
						if ( temp>0xff ) temp = 0xff;
						dst[1] = (unsigned char)temp;
						temp = src[2]+((n*tmp[2])>>8);
						if ( temp>0xff ) temp = 0xff;
						dst[2] = (unsigned char)temp;
						src += srcbpl;
						dst += dstbpl;
						tmp += 640*3;
						msk += mskbpl;
					}
				}
			}
			if ( e->curcount>=(e->sy2-e->sy1) ) {
				e->cmd = 0;
				if ( temppdt ) delete temppdt;
				temppdt = 0;
			}
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;

		case 40:			// �e���r������
			maxx = (e->sx2-e->sx1)/2;
			xx = maxx+e->sx1;
			yy = ((e->sy2-e->sy1)/2)+e->sy1;
			yy2 = (((e->curcount+1)*19)/maxx);
			if ( (yy-yy2)>=e->sy1 ) {
				src = srcbuf+(yy-yy2)*srcbpl+(xx-e->curcount)*srcbpp;
				dst = dstbuf+((yy-yy2)-e->sy1+e->dy)*dstbpl+((xx-e->sx1+e->dx)-e->curcount)*dstbpp;
				msk = mskbuf+(yy-yy2)*mskbpl+(xx-e->curcount);
				for(x=(xx-e->curcount); x<=(xx+e->curcount+1); x++) {
					if (e->mask) maskc = *msk++;
					PDT_Pixel(src, dst, maskc);
					src += srcbpp;
					dst += dstbpp;
				}
			}
			if ( (yy+yy2+1)<=e->sy2 ) {
				src = srcbuf+(yy+yy2+1)*srcbpl+(xx-e->curcount)*srcbpp;
				dst = dstbuf+((yy+yy2+1)-e->sy1+e->dy)*dstbpl+((xx-e->sx1+e->dx)-e->curcount)*dstbpp;
				msk = mskbuf+(yy+yy2+1)*mskbpl+(xx-e->curcount);
				for(x=(xx-e->curcount); x<=(xx+e->curcount+1); x++) {
					if (e->mask) maskc = *msk++;
					PDT_Pixel(src, dst, maskc);
					src += srcbpp;
					dst += dstbpp;
				}
			}
			src = srcbuf+(yy-yy2)*srcbpl+(xx-e->curcount)*srcbpp;
			dst = dstbuf+((yy-yy2)-e->sy1+e->dy)*dstbpl+((xx-e->sx1+e->dx)-e->curcount)*dstbpp;
			msk = mskbuf+(yy-yy2)*mskbpl+(xx-e->curcount);
			for(y=(yy-yy2); y<=(yy+yy2+1); y++) {
				if (e->mask) maskc = *msk;
				PDT_Pixel(src, dst, maskc);
				src += srcbpl;
				dst += dstbpl;
				msk += mskbpl;
			}
			src = srcbuf+(yy-yy2)*srcbpl+(xx+e->curcount+1)*srcbpp;
			dst = dstbuf+((yy-yy2)-e->sy1+e->dy)*dstbpl+(xx+e->curcount+1-e->sx1+e->dx)*dstbpp;
			msk = mskbuf+(yy-yy2)*mskbpl+(xx+e->curcount+1);
			for(y=(yy-yy2); y<=(yy+yy2+1); y++) {
				if (e->mask) maskc = *msk;
				PDT_Pixel(src, dst, maskc);
				src += srcbpl;
				dst += dstbpl;
				msk += mskbpl;
			}
			e->curcount++;
			if ( e->curcount>=maxx ) {
				for (y=e->sy1; y<=e->sy2; y++) {
					if ( (y<(yy-19))||(y>(yy+20)) ) {
						src = srcbuf+y*srcbpl+e->sx1*srcbpp;
						dst = dstbuf+(y-e->sy1+e->dy)*dstbpl+e->dx*dstbpp;
						msk = mskbuf+y*mskbpl+e->sx1;
						for(x=e->sx1; x<=e->sx2; x++) {
							if (e->mask) maskc = *msk++;
							PDT_Pixel(src, dst, maskc);
							src += srcbpp;
							dst += dstbpp;
						}
					}
				}
				e->cmd = 0;
			}
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;

		case 41:			// �e���r������
			maxx = (e->sx2-e->sx1)/2;
			xx = maxx+e->sx1;
			yy = ((e->sy2-e->sy1)/2)+e->sy1;
			yy2 = 19-(((e->curcount+1)*19)/maxx);
			if ( !e->curcount ) {
				for (y=e->sy1; y<=e->sy2; y++) {
					if ( (y<(yy-19))||(y>(yy+20)) ) {
						src = srcbuf+y*srcbpl+e->sx1*srcbpp;
						dst = dstbuf+(y-e->sy1+e->dy)*dstbpl+e->dx*dstbpp;
						msk = mskbuf+y*mskbpl+e->sx1;
						for(x=e->sx1; x<=e->sx2; x++) {
							if (e->mask) maskc = *msk++;
							PDT_Pixel(src, dst, maskc);
							src += srcbpp;
							dst += dstbpp;
						}
					}
				}
			}
			if ( (yy-yy2)>=e->sy1 ) {
				src = srcbuf+(yy-yy2)*srcbpl+e->sx1*srcbpp;
				dst = dstbuf+((yy-yy2)-e->sy1+e->dy)*dstbpl+e->dx*dstbpp;
				msk = mskbuf+(yy-yy2)*mskbpl+e->sx1;
				for(x=e->sx1; x<=e->sx2; x++) {
					if (e->mask) maskc = *msk++;
					PDT_Pixel(src, dst, maskc);
					src += srcbpp;
					dst += dstbpp;
				}
			}
			if ( (yy+yy2+1)<=e->sy2 ) {
				src = srcbuf+(yy+yy2+1)*srcbpl+e->sx1*srcbpp;
				dst = dstbuf+((yy+yy2+1)-e->sy1+e->dy)*dstbpl+e->dx*dstbpp;
				msk = mskbuf+(yy+yy2+1)*mskbpl+e->sx1;
				for(x=e->sx1; x<=e->sx2; x++) {
					if (e->mask) maskc = *msk++;
					PDT_Pixel(src, dst, maskc);
					src += srcbpp;
					dst += dstbpp;
				}
			}
			src = srcbuf+e->sy1*srcbpl+(e->sx1+e->curcount)*srcbpp;
			dst = dstbuf+e->dy*dstbpl+(e->dx+e->curcount)*dstbpp;
			msk = mskbuf+e->sy1*mskbpl+(e->sx1+e->curcount);
			n = e->sx2-e->sx1;
			for(y=e->sy1; y<=e->sy2; y++) {
				if (e->mask) maskc = *msk;
				PDT_Pixel(src, dst, maskc);
				src += srcbpl;
				dst += dstbpl;
				msk += mskbpl;
			}
			src = srcbuf+e->sy1*srcbpl+(e->sx2-e->curcount)*srcbpp;
			dst = dstbuf+e->dy*dstbpl+((e->dx+e->sx2-e->sx1)-e->curcount)*dstbpp;
			msk = mskbuf+e->sy1*mskbpl+(e->sx1-e->curcount);
			for(y=e->sy1; y<=e->sy2; y++) {
				if (e->mask) maskc = *msk;
				PDT_Pixel(src, dst, maskc);
				src += srcbpl;
				dst += dstbpl;
				msk += mskbpl;
			}
			e->curcount++;
			if ( e->curcount>=maxx ) e->cmd = 0;
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;

		case 45:			// �\���Ɋ����悤��  ����
							//                     ����
			xx  = ((e->sx2-e->sx1)/2)-e->curcount;
			yy  = ((e->sy2-e->sy1)/2)-e->curcount;
			xx2 = ((e->sx2-e->sx1)/2)+e->curcount+1;
			yy2 = ((e->sy2-e->sy1)/2)+e->curcount+1;
			f1 = f2 = f3 = f4 = 1;
			if ( xx<0 ) { xx = 0; f1 = 0; }
			if ( yy<0 ) { yy = 0; f2 = 0; }
			if ( xx2>(e->sx2-e->sx1) ) { xx2 = (e->sx2-e->sx1); f3 = 0; }
			if ( yy2>(e->sy2-e->sy1) ) { yy2 = (e->sy2-e->sy1); f4 = 0; }
			if ( f2 ) {
				src = srcbuf + (e->sy1+yy)*srcbpl+(e->sx1)*srcbpp;
				dst = dstbuf + (e->dy+yy)*dstbpl+(e->dx)*dstbpp;
				msk = mskbuf + (e->sy1+yy)*640+(e->sx1);
				for (x=0; x<=((e->sx2-e->sx1)/2); x++) {
					if (e->mask) maskc = *msk++;
					PDT_Pixel(src, dst, maskc);
					src += srcbpp;
					dst += dstbpp;
				}
			}
			if ( f4 ) {
				src = srcbuf + (e->sy1+yy2)*srcbpl+(e->sx1+((e->sx2-e->sx1)/2))*srcbpp;
				dst = dstbuf + (e->dy+yy2)*dstbpl+(e->dx+((e->sx2-e->sx1)/2))*dstbpp;
				msk = mskbuf + (e->sy1+yy2)*640+(e->sx1+((e->sx2-e->sx1)/2));
				for (x=((e->sx2-e->sx1)/2); x<=(e->sx2-e->sx1); x++) {
					if (e->mask) maskc = *msk++;
					PDT_Pixel(src, dst, maskc);
					src += srcbpp;
					dst += dstbpp;
				}
			}
			if ( f3 ) {
				src = srcbuf + (e->sy1)*srcbpl+(e->sx1+xx2)*srcbpp;
				dst = dstbuf + (e->dy)*dstbpl+(e->dx+xx2)*dstbpp;
				msk = mskbuf + (e->sy1)*640+(e->sx1+xx2);
				for (y=0; y<=((e->sy2-e->sy1)/2); y++) {
					if (e->mask) maskc = *msk++;
					PDT_Pixel(src, dst, maskc);
					src += srcbpl;
					dst += dstbpl;
				}
			}
			if ( f1 ) {
				src = srcbuf + (e->sy1+((e->sy2-e->sy1)/2))*srcbpl+(e->sx1+xx)*srcbpp;
				dst = dstbuf + (e->dy+((e->sy2-e->sy1)/2))*dstbpl+(e->dx+xx)*dstbpp;
				msk = mskbuf + (e->sy1+((e->sy2-e->sy1)/2))*640+(e->sx1+xx);
				for (y=((e->sy2-e->sy1)/2); y<=(e->sy2-e->sy1); y++) {
					if (e->mask) maskc = *msk++;
					PDT_Pixel(src, dst, maskc);
					src += srcbpl;
					dst += dstbpl;
				}
			}
			e->curcount++;
			if ( (e->curcount>((e->sx2-e->sx1)/2))&&(e->curcount>((e->sy2-e->sy1)/2)) ) e->cmd = 0;
 			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;

		case 50:			// �N���X�t�F�[�h�H�i�ʃo�b�t�@������j
			if ( !e->step ) e->step = 16;
			if ( !e->curcount ) {	// �X�N���[���o�b�t�@���R�s�[
				if ( temppdt ) {
					delete temppdt;
					temppdt = 0;
				}
				temppdt = new PDTBUFFER(640, 480, 3, 640*3, true);
				if ( !temppdt ) break;
				tmpbuf = temppdt->GetBuffer();
				for (y=0; y<=479; y++) {
					dst = dstbuf;
					tmp = tmpbuf;
					for (x=0; x<=639; x++) {
						tmp[0] = dst[0];
						tmp[1] = dst[1];
						tmp[2] = dst[2];
						dst += dstbpp;
						tmp += 3;
					}
					dstbuf += dstbpl;
					tmpbuf += 640*3;
				}
				tmpbuf = temppdt->GetBuffer();
				dstbuf = pdt[e->dstpdt]->GetBuffer();
				if ( !e->dstpdt ) dstbuf++;
			} else {
				if ( !temppdt ) break;
				tmpbuf = temppdt->GetBuffer();
			}
			e->curcount++;
			fade = ((e->curcount<<8)/e->step);
			srcbuf += e->sy1*srcbpl+e->sx1*srcbpp;
			dstbuf += e->dy*dstbpl+e->dx*dstbpp;
			tmpbuf += e->dy*640*3+e->dx*3;
			mskbuf += e->sy1*640+e->sx1;
			for(y=e->sy1; y<=e->sy2; y++) {
				src = srcbuf;
				dst = dstbuf;
				tmp = tmpbuf;
				msk = mskbuf;
				for (x=e->sx1; x<=e->sx2; x++) {
					if (e->mask) maskc = *msk++;
					PDT_FadePixel(src, tmp, dst, maskc, fade);
					src += srcbpp;
					dst += dstbpp;
					tmp += 3;
				}
				srcbuf += srcbpl;
				dstbuf += dstbpl;
				tmpbuf += 640*3;
				mskbuf += 640;
			}
			if ( e->curcount==e->step ) {
				e->cmd = 0;
				if ( temppdt ) delete temppdt;
				temppdt = 0;
				backupflag = 1;			// #50 Buckuped
			}
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;

		case 54:			// �N���X�t�F�[�h�i16�i�K�ŋP�x�̒Ⴂ������j
			if ( !e->step ) e->step = 16;
			high = ((0x100*(e->curcount+1))/e->step);
			low = ((0x100*e->curcount)/e->step);
			srcbuf += e->sy1*srcbpl+e->sx1*srcbpp;
			dstbuf += e->dy*dstbpl+e->dx*dstbpp;
			for(y=e->sy1; y<=e->sy2; y++) {
				src = srcbuf;
				dst = dstbuf;
				for (x=e->sx1; x<=e->sx2; x++) {
					if ( e->arg5 )
						temp = (dst[0]*299+dst[1]*587+dst[2]*114)/1000;
					else
						temp = (src[0]*299+src[1]*587+src[2]*114)/1000;
					if ( (temp>=low)&&(temp<high) ) {
						dst[0] = src[0];
						dst[1] = src[1];
						dst[2] = src[2];
					}
					src += srcbpp;
					dst += dstbpp;
				}
				srcbuf += srcbpl;
				dstbuf += dstbpl;
			}
			e->curcount++;
			if ( e->curcount==e->step ) {
				e->cmd = 0;
				if ( temppdt ) delete temppdt;
				temppdt = 0;
				backupflag = 1;			// #54 Buckuped?
			}
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;

		case 60:			// �h�b�g�ɂ��^���t�F�[�h�C���^�A�E�g (4x4)
			for(yy=(e->sy1+EFF4Y[e->curcount]*4); yy<=e->sy2; yy+=16) {
				for(y=yy; y<(yy+4); y++) {
					if ( y<=e->sy2 ) {
						src = srcbuf+y*srcbpl;
						dst = dstbuf+(y-e->sy1+e->dy)*dstbpl;
						msk = mskbuf+y*mskbpl;
						for (xx=(e->sx1+EFF4X[e->curcount]*4); xx<=e->sx2; xx+=16) {
							for (x=xx; x<(xx+4); x++) {
								if ( x<=e->sx2 ) {
									if (e->mask) maskc = *(msk+x);
									PDT_Pixel(src+x*srcbpp, dst+(x-e->sx1+e->dx)*dstbpp, maskc);
								}
							}
						}
					}
				}
			}
			e->curcount++;
			if ( e->curcount==16 ) {
				e->cmd = 0;
				backupflag = 1;
			}
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;
			
		case 61:			// 4x4���~��`���悤��
			for(yy=(e->sy1+EFF61Y[e->curcount]*4); yy<=e->sy2; yy+=16) {
				for(y=yy; y<(yy+4); y++) {
					if ( y<=e->sy2 ) {
						src = srcbuf+y*srcbpl;
						dst = dstbuf+(y-e->sy1+e->dy)*dstbpl;
						msk = mskbuf+y*mskbpl;
						for (xx=(e->sx1+EFF61X[e->curcount]*4); xx<=e->sx2; xx+=16) {
							for (x=xx; x<(xx+4); x++) {
								if ( x<=e->sx2 ) {
									if (e->mask) maskc = *(msk+x);
									PDT_Pixel(src+x*srcbpp, dst+(x-e->sx1+e->dx)*dstbpp, maskc);
								}
							}
						}
					}
				}
			}
			e->curcount++;
			if ( e->curcount==16 ) {
				e->cmd = 0;
// ???				backupflag = 1;
			}
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;
			
		case 62:			// 4x4��1���C������
			for(yy=(e->sy1+EFF62Y[e->curcount]*4); yy<=e->sy2; yy+=16) {
				for(y=yy; y<(yy+4); y++) {
					if ( y<=e->sy2 ) {
						src = srcbuf+y*srcbpl;
						dst = dstbuf+(y-e->sy1+e->dy)*dstbpl;
						msk = mskbuf+y*mskbpl;
						for (xx=(e->sx1+EFF62X[e->curcount]*4); xx<=e->sx2; xx+=16) {
							for (x=xx; x<(xx+4); x++) {
								if ( x<=e->sx2 ) {
									if (e->mask) maskc = *(msk+x);
									PDT_Pixel(src+x*srcbpp, dst+(x-e->sx1+e->dx)*dstbpp, maskc);
								}
							}
						}
					}
				}
			}
			e->curcount++;
			if ( e->curcount==16 ) {
				e->cmd = 0;
// ???				backupflag = 1;
			}
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;
			
		case 63:			// 4x4���~��`���悤�� (#61 reverse)
			for(yy=(e->sy1+EFF61Y[15-e->curcount]*4); yy<=e->sy2; yy+=16) {
				for(y=yy; y<(yy+4); y++) {
					if ( y<=e->sy2 ) {
						src = srcbuf+y*srcbpl;
						dst = dstbuf+(y-e->sy1+e->dy)*dstbpl;
						msk = mskbuf+y*mskbpl;
						for (xx=(e->sx1+EFF61X[15-e->curcount]*4); xx<=e->sx2; xx+=16) {
							for (x=xx; x<(xx+4); x++) {
								if ( x<=e->sx2 ) {
									if (e->mask) maskc = *(msk+x);
									PDT_Pixel(src+x*srcbpp, dst+(x-e->sx1+e->dx)*dstbpp, maskc);
								}
							}
						}
					}
				}
			}
			e->curcount++;
			if ( e->curcount==16 ) {
				e->cmd = 0;
// ???				backupflag = 1;
			}
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;
			
		case 70:			// Random Lines (Left to Right)
			if ( !e->step ) e->step = 32;
			if ( !e->arg5 ) e->arg5 = 64;
			if ( !e->curcount ) {
				if ( lines ) {
					delete[] lines;
					lines = 0;
				}
				lines = new int[e->sy2-e->sy1+1];
				for (i=0; i<=e->sy2-e->sy1; i++) {
					lines[i] = -(e->step*(rand()%e->arg5));
				}
			}
			count = 0;
			for (y=0; y<=(e->sy2-e->sy1); y++) {
				if ( lines[y]!=10000 ) {
					lines[y] += e->step;
					if ( lines[y]>0 ) {
						xx = lines[y]-e->step;
						if ( xx<0 ) xx = 0;
						xx2 = lines[y];
						if ( xx2>(e->sx2-e->sx1) ) xx2 = (e->sx2-e->sx1);
						src = srcbuf+(y+e->sy1)*srcbpl+(xx+e->sx1)*srcbpp;
						dst = dstbuf+(y+e->dy)*dstbpl+(xx+e->dx)*dstbpp;
						msk = mskbuf+(y+e->sy1)*mskbpl+(xx+e->sx1);
						for (x=xx; x<=xx2; x++) {
							if (e->mask) maskc = *msk++;
							PDT_Pixel(src, dst, maskc);
							src += srcbpp;
							dst += dstbpp;
						}
						if ( xx2==(e->sx2-e->sx1) ) lines[y] = 10000;
					}
				}
				if ( lines[y]==10000 ) count++;
			}
			e->curcount++;
			if ( count==(e->sy2-e->sy1+1) ) {
				e->cmd = 0;
				delete[] lines;
				lines = 0;
			}
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;

		case 71:			// Random Lines (Right to Left)
			if ( !e->step ) e->step = 32;
			if ( !e->arg5 ) e->arg5 = 64;
			if ( !e->curcount ) {
				if ( lines ) {
					delete[] lines;
					lines = 0;
				}
				lines = new int[e->sy2-e->sy1+1];
				for (i=0; i<=e->sy2-e->sy1; i++) {
					lines[i] = -(e->step*(rand()%e->arg5));
				}
			}
			count = 0;
			for (y=0; y<=(e->sy2-e->sy1); y++) {
				if ( lines[y]!=10000 ) {
					lines[y] += e->step;
					if ( lines[y]>0 ) {
						xx = lines[y]-e->step;
						if ( xx<0 ) xx = 0;
						xx2 = lines[y];
						if ( xx2>(e->sx2-e->sx1) ) xx2 = (e->sx2-e->sx1);
						src = srcbuf+(y+e->sy1)*srcbpl+(e->sx2-xx2)*srcbpp;
						dst = dstbuf+(y+e->dy)*dstbpl+(e->sx2-e->sx1+e->dx-xx2)*dstbpp;
						msk = mskbuf+(y+e->sy1)*mskbpl+(e->sx2-xx2);
						for (x=xx; x<=xx2; x++) {
							if (e->mask) maskc = *msk++;
							PDT_Pixel(src, dst, maskc);
							src += srcbpp;
							dst += dstbpp;
						}
						if ( xx2==(e->sx2-e->sx1) ) lines[y] = 10000;
					}
				}
				if ( lines[y]==10000 ) count++;
			}
			e->curcount++;
			if ( count==(e->sy2-e->sy1+1) ) {
				e->cmd = 0;
				delete[] lines;
				lines = 0;
			}
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;

		case 72:			// Random Lines (Top to Bottom)
			if ( !e->step ) e->step = 32;
			if ( !e->arg5 ) e->arg5 = 64;
			if ( !e->curcount ) {
				if ( lines ) {
					delete[] lines;
					lines = 0;
				}
				lines = new int[e->sx2-e->sx1+1];
				for (i=0; i<=e->sx2-e->sx1; i++) {
					lines[i] = -(e->step*(rand()%e->arg5));
				}
			}
			count = 0;
			for (x=0; x<=(e->sx2-e->sx1); x++) {
				if ( lines[x]!=10000 ) {
					lines[x] += e->step;
					if ( lines[x]>0 ) {
						yy = lines[x]-e->step;
						if ( yy<0 ) yy = 0;
						yy2 = lines[x];
						if ( yy2>(e->sy2-e->sy1) ) yy2 = (e->sy2-e->sy1);
						src = srcbuf+(yy+e->sy1)*srcbpl+(x+e->sx1)*srcbpp;
						dst = dstbuf+(yy+e->dy)*dstbpl+(x+e->dx)*dstbpp;
						msk = mskbuf+(yy+e->sy1)*mskbpl+(x+e->sx1);
						for (y=yy; y<=yy2; y++) {
							if (e->mask) maskc = *msk;
							PDT_Pixel(src, dst, maskc);
							src += srcbpl;
							dst += dstbpl;
							msk += mskbpl;
						}
						if ( yy2==(e->sy2-e->sy1) ) lines[x] = 10000;
					}
				}
				if ( lines[x]==10000 ) count++;
			}
			e->curcount++;
			if ( count==(e->sx2-e->sx1+1) ) {
				e->cmd = 0;
				delete[] lines;
				lines = 0;
			}
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;

		case 73:			// Random Lines (Bottom to Top)
			if ( !e->step ) e->step = 32;
			if ( !e->arg5 ) e->arg5 = 64;
			if ( !e->curcount ) {
				if ( lines ) {
					delete[] lines;
					lines = 0;
				}
				lines = new int[e->sx2-e->sx1+1];
				for (i=0; i<=e->sx2-e->sx1; i++) {
					lines[i] = -(e->step*(rand()%e->arg5));
				}
			}
			count = 0;
			for (x=0; x<=(e->sx2-e->sx1); x++) {
				if ( lines[x]!=10000 ) {
					lines[x] += e->step;
					if ( lines[x]>0 ) {
						yy = lines[x]-e->step;
						if ( yy<0 ) yy = 0;
						yy2 = lines[x];
						if ( yy2>(e->sy2-e->sy1) ) yy2 = (e->sy2-e->sy1);
						src = srcbuf+(e->sy2-yy2)*srcbpl+(e->sx1+x)*srcbpp;
						dst = dstbuf+(e->dy+e->sy2-e->sy1-yy2)*dstbpl+(e->dx+x)*dstbpp;
						msk = mskbuf+(e->sy2-yy2)*mskbpl+(e->sx1+x);
						for (y=yy; y<=yy2; y++) {
							if (e->mask) maskc = *msk;
							PDT_Pixel(src, dst, maskc);
							src += srcbpl;
							dst += dstbpl;
							msk += mskbpl;
						}
						if ( yy2==(e->sy2-e->sy1) ) lines[x] = 10000;
					}
				}
				if ( lines[x]==10000 ) count++;
			}
			e->curcount++;
			if ( count==(e->sx2-e->sx1+1) ) {
				e->cmd = 0;
				delete[] lines;
				lines = 0;
			}
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;

		case 80:			// Random Lines (Left to Right / Scroll)
			if ( !e->step ) e->step = 32;
			if ( !e->arg5 ) e->arg5 = 64;
			if ( !e->curcount ) {
				if ( lines ) {
					delete[] lines;
					lines = 0;
				}
				lines = new int[e->sy2-e->sy1+1];
				for (i=0; i<=e->sy2-e->sy1; i++) {
					lines[i] = -(e->step*(rand()%e->arg5));
				}
			}
			count = 0;
			for (y=0; y<=(e->sy2-e->sy1); y++) {
				if ( lines[y]!=10000 ) {
					lines[y] += e->step;
					if ( lines[y]>0 ) {
						xx = 0;
						xx2 = lines[y];
						if ( xx2>(e->sx2-e->sx1) ) xx2 = (e->sx2-e->sx1);
						src = srcbuf+(y+e->sy1)*srcbpl+(e->sx2-xx2)*srcbpp;
						dst = dstbuf+(y+e->dy)*dstbpl+e->dx*dstbpp;
						msk = mskbuf+(y+e->sy1)*mskbpl+e->sx1;		// �}�X�N�͕`���ɂ��킹�Ƃ�
						for (x=xx; x<=xx2; x++) {
							if (e->mask) maskc = *msk++;
							PDT_Pixel(src, dst, maskc);
							src += srcbpp;
							dst += dstbpp;
						}
						if ( xx2==(e->sx2-e->sx1) ) lines[y] = 10000;
					}
				}
				if ( lines[y]==10000 ) count++;
			}
			e->curcount++;
			if ( count==(e->sy2-e->sy1+1) ) {
				e->cmd = 0;
				delete[] lines;
				lines = 0;
			}
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;

		case 81:			// Random Lines (Right to Left / Scroll)
			if ( !e->step ) e->step = 32;
			if ( !e->arg5 ) e->arg5 = 64;
			if ( !e->curcount ) {
				if ( lines ) {
					delete[] lines;
					lines = 0;
				}
				lines = new int[e->sy2-e->sy1+1];
				for (i=0; i<=e->sy2-e->sy1; i++) {
					lines[i] = -(e->step*(rand()%e->arg5));
				}
			}
			count = 0;
			for (y=0; y<=(e->sy2-e->sy1); y++) {
				if ( lines[y]!=10000 ) {
					lines[y] += e->step;
					if ( lines[y]>0 ) {
						xx = 0;
						xx2 = lines[y];
						if ( xx2>(e->sx2-e->sx1) ) xx2 = (e->sx2-e->sx1);
						src = srcbuf+(y+e->sy1)*srcbpl+e->sx1*srcbpp;
						dst = dstbuf+(y+e->dy)*dstbpl+(e->sx2-e->sx1+e->dx-xx2)*dstbpp;
						msk = mskbuf+(y+e->sy1)*mskbpl+(e->sx2-xx2);
						for (x=xx; x<=xx2; x++) {
							if (e->mask) maskc = *msk++;
							PDT_Pixel(src, dst, maskc);
							src += srcbpp;
							dst += dstbpp;
						}
						if ( xx2==(e->sx2-e->sx1) ) lines[y] = 10000;
					}
				}
				if ( lines[y]==10000 ) count++;
			}
			e->curcount++;
			if ( count==(e->sy2-e->sy1+1) ) {
				e->cmd = 0;
				delete[] lines;
				lines = 0;
			}
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;

		case 82:			// Random Lines (Top to Bottom / Scroll)
			if ( !e->step ) e->step = 32;
			if ( !e->arg5 ) e->arg5 = 64;
			if ( !e->curcount ) {
				if ( lines ) {
					delete[] lines;
					lines = 0;
				}
				lines = new int[e->sx2-e->sx1+1];
				for (i=0; i<=e->sx2-e->sx1; i++) {
					lines[i] = -(e->step*(rand()%e->arg5));
				}
			}
			count = 0;
			for (x=0; x<=(e->sx2-e->sx1); x++) {
				if ( lines[x]!=10000 ) {
					lines[x] += e->step;
					if ( lines[x]>0 ) {
						yy = 0;
						yy2 = lines[x];
						if ( yy2>(e->sy2-e->sy1) ) yy2 = (e->sy2-e->sy1);
						src = srcbuf+(e->sy2-yy2)*srcbpl+(x+e->sx1)*srcbpp;
						dst = dstbuf+(e->dy)*dstbpl+(x+e->dx)*dstbpp;
						msk = mskbuf+(e->sy1)*mskbpl+(x+e->sx1);
						for (y=yy; y<=yy2; y++) {
							if (e->mask) maskc = *msk;
							PDT_Pixel(src, dst, maskc);
							src += srcbpl;
							dst += dstbpl;
							msk += mskbpl;
						}
						if ( yy2==(e->sy2-e->sy1) ) lines[x] = 10000;
					}
				}
				if ( lines[x]==10000 ) count++;
			}
			e->curcount++;
			if ( count==(e->sx2-e->sx1+1) ) {
				e->cmd = 0;
				delete[] lines;
				lines = 0;
			}
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;

		case 83:			// Random Lines (Bottom to Top / Scroll)
			if ( !e->step ) e->step = 32;
			if ( !e->arg5 ) e->arg5 = 64;
			if ( !e->curcount ) {
				if ( lines ) {
					delete[] lines;
					lines = 0;
				}
				lines = new int[e->sx2-e->sx1+1];
				for (i=0; i<=e->sx2-e->sx1; i++) {
					lines[i] = -(e->step*(rand()%e->arg5));
				}
			}
			count = 0;
			for (x=0; x<=(e->sx2-e->sx1); x++) {
				if ( lines[x]!=10000 ) {
					lines[x] += e->step;
					if ( lines[x]>0 ) {
						yy = 0;
						yy2 = lines[x];
						if ( yy2>(e->sy2-e->sy1) ) yy2 = (e->sy2-e->sy1);
						src = srcbuf+(e->sy1)*srcbpl+(e->sx1+x)*srcbpp;
						dst = dstbuf+(e->dy+e->sy2-e->sy1-yy2)*dstbpl+(e->dx+x)*dstbpp;
						msk = mskbuf+(e->sy2-yy2)*mskbpl+(e->sx1+x);
						for (y=yy; y<=yy2; y++) {
							if (e->mask) maskc = *msk;
							PDT_Pixel(src, dst, maskc);
							src += srcbpl;
							dst += dstbpl;
							msk += mskbpl;
						}
						if ( yy2==(e->sy2-e->sy1) ) lines[x] = 10000;
					}
				}
				if ( lines[x]==10000 ) count++;
			}
			e->curcount++;
			if ( count==(e->sx2-e->sx1+1) ) {
				e->cmd = 0;
				delete[] lines;
				lines = 0;
			}
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;

		case 100:			// �Z���^�ɍ�����E�i�S�Z�������Ɂj
			if ( !e->step ) e->step = 16;
			for (x=e->sx1; x<=e->sx2; x+=(e->step)) {
				src = srcbuf+(e->sy1)*srcbpl+(x+e->curcount)*srcbpp;
				dst = dstbuf+(e->sy1)*dstbpl+(x+e->curcount-(e->sx1)+(e->dx))*dstbpp;
				msk = mskbuf+(e->sy1)*mskbpl+(x+e->curcount);
				for (y=e->sy1; y<=e->sy2; y++) {
					if (e->mask) { maskc = *msk; msk += mskbpl; }
					PDT_Pixel(src, dst, maskc);
					src += srcbpl;
					dst += dstbpl;
				}
			}
			e->curcount++;
			if ( e->curcount>=e->step ) e->cmd = 0;
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;
			
		case 101:			// �Z���^�ɉE���獶�i�S�Z�������Ɂj
			if ( !e->step ) e->step = 16;
			dif = (e->step-e->curcount)-1;
			for (x=e->sx1; x<=e->sx2; x+=(e->step)) {
				src = srcbuf+(e->sy1)*srcbpl+(x+dif)*srcbpp;
				dst = dstbuf+(e->sy1)*dstbpl+(x+dif-(e->sx1)+(e->dx))*dstbpp;
				msk = mskbuf+(e->sy1)*mskbpl+(x+dif);
				for (y=e->sy1; y<=e->sy2; y++) {
					if (e->mask) { maskc = *msk; msk += mskbpl; }
					PDT_Pixel(src, dst, maskc);
					src += srcbpl;
					dst += dstbpl;
				}
			}
			e->curcount++;
			if ( e->curcount>=e->step ) e->cmd = 0;
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;
			
		case 102:			// �Z���^�ɏォ�牺�ցi�S�Z�������Ɂj
			if ( !e->step ) e->step = 16;
			for (y=e->sy1; y<=e->sy2; y+=(e->step)) {
				src = srcbuf+(y+e->curcount)*srcbpl+(e->sx1)*srcbpp;
				dst = dstbuf+(y+e->curcount-(e->sy1)+(e->dy))*dstbpl+(e->dx)*dstbpp;
				msk = mskbuf+(y+e->curcount)*mskbpl+(e->sx1);
				for (x=e->sx1; x<=e->sx2; x++) {
					if (e->mask) maskc = *msk++;
					PDT_Pixel(src, dst, maskc);
					src += srcbpp;
					dst += dstbpp;
				}
			}
			e->curcount++;
			if ( e->curcount>=e->step ) e->cmd = 0;
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;
			
		case 103:			// �Z���^�ɉ������ցi�S�Z�������Ɂj
			if ( !e->step ) e->step = 16;
			dif = (e->step-e->curcount)-1;
			for (y=e->sy1; y<=e->sy2; y+=(e->step)) {
				src = srcbuf+(y+e->curcount)*srcbpl+(e->sx1)*srcbpp;
				dst = dstbuf+(y+e->curcount-(e->sy1)+(e->dy))*dstbpl+(e->dx)*dstbpp;
				msk = mskbuf+(y+e->curcount)*mskbpl+(e->sx1);
				for (x=e->sx1; x<=e->sx2; x++) {
					if (e->mask) maskc = *msk++;
					PDT_Pixel(src, dst, maskc);
					src += srcbpp;
					dst += dstbpp;
				}
			}
			e->curcount++;
			if ( e->curcount>=e->step ) e->cmd = 0;
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;
			
		case 110:			// ���E�ɖ����J���悤�Ɂi�X�N���[�������j
							// Arg5=Direction  0:��������  1:�O������
			if ( !e->step ) e->step = 1;
			for (n=0; n<e->step; n++) {
				dif = e->curcount+n;
				if ( e->arg5 )
					x = dif+e->sx1;
				else
					x = (e->sx2-e->sx1)/2+e->sx1-dif;
				if (x>=0) {
					src = srcbuf+(e->sy1)*srcbpl+x*srcbpp;
					dst = dstbuf+(e->dy)*dstbpl+(x-e->sx1+e->dx)*dstbpp;
					msk = mskbuf+(e->sy1)*mskbpl+x;
					for (y=e->sy1; y<=e->sy2; y++) {
						if (e->mask) { maskc = *msk; msk += mskbpl; }
						PDT_Pixel(src, dst, maskc);
						src += srcbpl;
						dst += dstbpl;
					}
					if ( e->arg5 )
						x = e->sx2-dif;
					else
						x = (e->sx2-e->sx1)/2+e->sx1+dif;
					src = srcbuf+(e->sy1)*srcbpl+x*srcbpp;
					dst = dstbuf+(e->dy)*dstbpl+(x-e->sx1+e->dx)*dstbpp;
					msk = mskbuf+(e->sy1)*mskbpl+x;
					for (y=e->sy1; y<=e->sy2; y++) {
						if (e->mask) { maskc = *msk; msk += mskbpl; } 
						PDT_Pixel(src, dst, maskc);
						src += srcbpl;
						dst += dstbpl;
					}
				}
			}
			e->curcount += e->step;
			if ( e->curcount>(e->sx2-e->sx1)/2 ) e->cmd = 0;
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;
			
		case 111:			// �㉺�ɖ����J���悤�Ɂi�X�N���[�������j
							// Arg5=Direction  0:��������  1:�O������
			if ( !e->step ) e->step = 1;
			for (n=0; n<e->step; n++) {
				dif = e->curcount+n;
				if ( e->arg5 )
					y = dif+e->sy1;
				else
					y = (e->sy2-e->sy1)/2+e->sy1-dif;
				if (y>=0) {
					src = srcbuf+y*srcbpl+e->sx1*srcbpp;
					dst = dstbuf+(y-e->sy1+e->dy)*dstbpl+e->dx*dstbpp;
					msk = mskbuf+y*mskbpl+e->sx1;
					for (x=e->sx1; x<=e->sx2; x++) {
						if (e->mask) maskc = *msk++;
						PDT_Pixel(src, dst, maskc);
						src += srcbpp;
						dst += dstbpp;
					}
					if ( e->arg5 )
						y = e->sy2-dif;
					else
						y = (e->sy2-e->sy1)/2+e->sy1+dif;
					src = srcbuf+y*srcbpl+e->sx1*srcbpp;
					dst = dstbuf+(y-e->sy1+e->dy)*dstbpl+e->dx*dstbpp;
					msk = mskbuf+y*mskbpl+e->sx1;
					for (x=e->sx1; x<=e->sx2; x++) {
						if (e->mask) maskc = *msk++;
						PDT_Pixel(src, dst, maskc);
						src += srcbpp;
						dst += dstbpp;
					}
				}
			}
			e->curcount += e->step;
			if ( e->curcount>(e->sy2-e->sy1)/2 ) e->cmd = 0;
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;

		case 112:			// ���E�ɃX���C�h
							// Arg5=Direction  0:��������  1:�O������
			if ( !e->step ) e->step = 1;
			e->curcount += e->step;
			if ( e->curcount>=(e->sx2-e->sx1)/2 ) e->curcount = (e->sx2-e->sx1)/2;
			if ( e->arg5 ) {
				for (x=(((e->sx2-e->sx1)/2)-e->curcount); x<=((e->sx2-e->sx1)/2); x++) {
					src = srcbuf+(e->sy1)*srcbpl+(x+e->sx1)*srcbpp;
					dst = dstbuf+(e->dy)*dstbpl+(x-(((e->sx2-e->sx1)/2)-e->curcount)+e->dx)*dstbpp;
					for (y=e->sy1; y<=e->sy2; y++) {
						dst[0] = src[0];
						dst[1] = src[1];
						dst[2] = src[2];
						src += srcbpl;
						dst += dstbpl;
					}
				}
				for (x=((e->sx2-e->sx1)/2); x<=((e->sx2-e->sx1)/2)+e->curcount; x++) {
					src = srcbuf+(e->sy1)*srcbpl+(x+e->sx1)*srcbpp;
					dst = dstbuf+(e->dy)*dstbpl+(x+((e->sx2-e->sx1)/2)-e->curcount+e->dx)*dstbpp;
					for (y=e->sy1; y<=e->sy2; y++) {
						dst[0] = src[0];
						dst[1] = src[1];
						dst[2] = src[2];
						src += srcbpl;
						dst += dstbpl;
					}
				}
			} else {
				for (x=(((e->sx2-e->sx1)/2)-e->curcount); x<=((e->sx2-e->sx1)/2); x++) {
					src = srcbuf+(e->sy1)*srcbpl+(x-(((e->sx2-e->sx1)/2)-e->curcount)+e->sx1)*srcbpp;
					dst = dstbuf+(e->dy)*dstbpl+(x+e->dx)*dstbpp;
					for (y=e->sy1; y<=e->sy2; y++) {
						dst[0] = src[0];
						dst[1] = src[1];
						dst[2] = src[2];
						src += srcbpl;
						dst += dstbpl;
					}
				}
				for (x=((e->sx2-e->sx1)/2); x<=((e->sx2-e->sx1)/2)+e->curcount; x++) {
					src = srcbuf+(e->sy1)*srcbpl+(x+((e->sx2-e->sx1)/2)-e->curcount+e->sx1)*srcbpp;
					dst = dstbuf+(e->dy)*dstbpl+(x+e->dx)*dstbpp;
					for (y=e->sy1; y<=e->sy2; y++) {
						dst[0] = src[0];
						dst[1] = src[1];
						dst[2] = src[2];
						src += srcbpl;
						dst += dstbpl;
					}
				}
			}
			if ( e->curcount>=(e->sx2-e->sx1)/2 ) e->cmd = 0;
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;

		case 113:			// �㉺�ɃX���C�h
							// Arg5=Direction  0:��������  1:�O������
			if ( !e->step ) e->step = 1;
			e->curcount += e->step;
			if ( e->curcount>=(e->sy2-e->sy1)/2 ) e->curcount = (e->sy2-e->sy1)/2;
			if ( e->arg5 ) {
				for (y=(((e->sy2-e->sy1)/2)-e->curcount); y<=((e->sy2-e->sy1)/2); y++) {
					src = srcbuf+(e->sy1+y)*srcbpl+e->sx1*srcbpp;
					dst = dstbuf+(y-(((e->sy2-e->sy1)/2)-e->curcount)+e->dy)*dstbpl+(e->dx)*dstbpp;
					for (x=e->sx1; x<=e->sx2; x++) {
						dst[0] = src[0];
						dst[1] = src[1];
						dst[2] = src[2];
						src += srcbpp;
						dst += dstbpp;
					}
				}
				for (y=((e->sy2-e->sy1)/2); y<=((e->sy2-e->sy1)/2)+e->curcount; y++) {
					src = srcbuf+(e->sy1+y)*srcbpl+(e->sx1)*srcbpp;
					dst = dstbuf+(y+((e->sy2-e->sy1)/2)-e->curcount+e->dy)*dstbpl+(e->dx)*dstbpp;
					for (x=e->sx1; x<=e->sx2; x++) {
						dst[0] = src[0];
						dst[1] = src[1];
						dst[2] = src[2];
						src += srcbpp;
						dst += dstbpp;
					}
				}
			} else {
				for (y=(((e->sy2-e->sy1)/2)-e->curcount); y<=((e->sy2-e->sy1)/2); y++) {
					src = srcbuf+(y-(((e->sy2-e->sy1)/2)-e->curcount)+e->sy1)*srcbpl+(e->sx1)*srcbpp;
					dst = dstbuf+(y+e->dy)*dstbpl+(e->dx)*dstbpp;
					for (x=e->sx1; x<=e->sx2; x++) {
						dst[0] = src[0];
						dst[1] = src[1];
						dst[2] = src[2];
						src += srcbpp;
						dst += dstbpp;
					}
				}
				for (y=((e->sy2-e->sy1)/2); y<=((e->sy2-e->sy1)/2)+e->curcount; y++) {
					src = srcbuf+(y+((e->sy2-e->sy1)/2)-e->curcount+e->sy1)*srcbpl+(e->sx1)*srcbpp;
					dst = dstbuf+(y+e->dy)*dstbpl+(e->dx)*dstbpp;
					for (x=e->sy1; x<=e->sx2; x++) {
						dst[0] = src[0];
						dst[1] = src[1];
						dst[2] = src[2];
						src += srcbpp;
						dst += dstbpp;
					}
				}
			}
			if ( e->curcount>=(e->sy2-e->sy1)/2 ) e->cmd = 0;
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;

		case 114:			// ���E�ɃX�N���[���X���C�h
							// Arg5=Direction  0:��������  1:�O������
			if ( !e->step ) e->step = 1;
			if ( (e->curcount+e->step)>=(e->sx2-e->sx1)/2 ) {
				e->step = ((e->sx2-e->sx1)/2)-e->curcount;
			}
			if ( e->arg5 ) {
				for (x=((e->sx2-e->sx1)/2); x>=0; x--) {
					if ( x<=e->step ) {
						dif = (((e->sx2-e->sx1)/2)-(e->curcount+e->step-x));
						src = srcbuf+(e->sy1)*srcbpl+(dif+e->sx1)*srcbpp;
						dst = dstbuf+(e->dy)*dstbpl+(x+e->dx)*dstbpp;
						for (y=e->sy1; y<=e->sy2; y++) {
							dst[0] = src[0];
							dst[1] = src[1];
							dst[2] = src[2];
							src += srcbpl;
							dst += dstbpl;
						}
					} else {
						src = dstbuf+(e->dy)*dstbpl+(x+e->dx-e->step)*dstbpp;
						dst = dstbuf+(e->dy)*dstbpl+(x+e->dx)*dstbpp;
						for (y=e->sy1; y<=e->sy2; y++) {
							dst[0] = src[0];
							dst[1] = src[1];
							dst[2] = src[2];
							src += dstbpl;
							dst += dstbpl;
						}
					}
				}
				for (x=((e->sx2-e->sx1)/2)+1; x<=(e->sx2-e->sx1); x++) {
					if ( x>=(e->sx2-e->sx1-e->step) ) {
						dif = e->curcount+(x-(e->sx2-e->sx1-e->step));
						src = srcbuf+(e->sy1)*srcbpl+(((e->sx2-e->sx1)/2)+dif+e->sx1)*srcbpp;
						dst = dstbuf+(e->dy)*dstbpl+(x+e->dx)*dstbpp;
						for (y=e->sy1; y<=e->sy2; y++) {
							dst[0] = src[0];
							dst[1] = src[1];
							dst[2] = src[2];
							src += srcbpl;
							dst += dstbpl;
						}
					} else {
						src = dstbuf+(e->dy)*dstbpl+(x+e->dx+e->step)*dstbpp;
						dst = dstbuf+(e->dy)*dstbpl+(x+e->dx)*dstbpp;
						for (y=e->sy1; y<=e->sy2; y++) {
							dst[0] = src[0];
							dst[1] = src[1];
							dst[2] = src[2];
							src += dstbpl;
							dst += dstbpl;
						}
					}
				}
			} else {
				for (x=0; x<=((e->sx2-e->sx1)/2); x++) {
					if ( x>=(((e->sx2-e->sx1)/2)-e->step) ) {
						dif = e->curcount+(x-(((e->sx2-e->sx1)/2)-e->step));
						src = srcbuf+(e->sy1)*srcbpl+(e->sx1+dif)*srcbpp;
						dst = dstbuf+(e->dy)*dstbpl+(x+e->dx)*dstbpp;
						for (y=e->sy1; y<=e->sy2; y++) {
							dst[0] = src[0];
							dst[1] = src[1];
							dst[2] = src[2];
							src += srcbpl;
							dst += dstbpl;
						}
					} else {
						src = dstbuf+(e->dy)*dstbpl+(x+e->dx+e->step)*dstbpp;
						dst = dstbuf+(e->dy)*dstbpl+(x+e->dx)*dstbpp;
						for (y=e->sy1; y<=e->sy2; y++) {
							dst[0] = src[0];
							dst[1] = src[1];
							dst[2] = src[2];
							src += dstbpl;
							dst += dstbpl;
						}
					}
				}
				for (x=(e->sx2-e->sx1); x>=((e->sx2-e->sx1)/2)+1; x--) {
					if ( x<=(((e->sx2-e->sx1)/2)+e->step) ) {
						dif = e->curcount+((((e->sx2-e->sx1)/2)+e->step)-x);
						src = srcbuf+(e->sy1)*srcbpl+(e->sx2-dif)*srcbpp;
						dst = dstbuf+(e->dy)*dstbpl+(x+e->dx)*dstbpp;
						for (y=e->sy1; y<=e->sy2; y++) {
							dst[0] = src[0];
							dst[1] = src[1];
							dst[2] = src[2];
							src += srcbpl;
							dst += dstbpl;
						}
					} else {
						src = dstbuf+(e->dy)*dstbpl+(x+e->dx-e->step)*dstbpp;
						dst = dstbuf+(e->dy)*dstbpl+(x+e->dx)*dstbpp;
						for (y=e->sy1; y<=e->sy2; y++) {
							dst[0] = src[0];
							dst[1] = src[1];
							dst[2] = src[2];
							src += dstbpl;
							dst += dstbpl;
						}
					}
				}
			}
			e->curcount += e->step;
			if ( e->curcount>=(e->sx2-e->sx1)/2 ) e->cmd = 0;
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;

		case 115:			// �㉺�ɃX�N���[���X���C�h
							// Arg5=Direction  0:��������  1:�O������
			if ( !e->step ) e->step = 1;
			if ( (e->curcount+e->step)>=(e->sy2-e->sy1)/2 ) {
				e->step = ((e->sy2-e->sy1)/2)-e->curcount;
			}
			if ( e->arg5 ) {
				for (y=((e->sy2-e->sy1)/2); y>=0; y--) {
					if ( y<=e->step ) {
						dif = (((e->sy2-e->sy1)/2)-(e->curcount+e->step-y));
						src = srcbuf+(e->sx1)*srcbpp+(dif+e->sy1)*srcbpl;
						dst = dstbuf+(e->dx)*dstbpp+(y+e->dy)*dstbpl;
						for (x=e->sx1; x<=e->sx2; x++) {
							dst[0] = src[0];
							dst[1] = src[1];
							dst[2] = src[2];
							src += srcbpp;
							dst += dstbpp;
						}
					} else {
						src = dstbuf+(e->dx)*dstbpp+(y+e->dy-e->step)*dstbpl;
						dst = dstbuf+(e->dx)*dstbpp+(y+e->dy)*dstbpl;
						for (x=e->sx1; x<=e->sx2; x++) {
							dst[0] = src[0];
							dst[1] = src[1];
							dst[2] = src[2];
							src += dstbpp;
							dst += dstbpp;
						}
					}
				}
				for (y=((e->sy2-e->sy1)/2)+1; y<=(e->sy2-e->sy1); y++) {
					if ( y>=(e->sy2-e->sy1-e->step) ) {
						dif = e->curcount+(y-(e->sy2-e->sy1-e->step));
						src = srcbuf+(e->sx1)*srcbpp+(((e->sy2-e->sy1)/2)+dif+e->sy1)*srcbpl;
						dst = dstbuf+(e->dx)*dstbpp+(y+e->dy)*dstbpl;
						for (x=e->sx1; x<=e->sx2; x++) {
							dst[0] = src[0];
							dst[1] = src[1];
							dst[2] = src[2];
							src += srcbpp;
							dst += dstbpp;
						}
					} else {
						src = dstbuf+(e->dx)*dstbpp+(y+e->dy+e->step)*dstbpl;
						dst = dstbuf+(e->dx)*dstbpp+(y+e->dy)*dstbpl;
						for (x=e->sx1; x<=e->sx2; x++) {
							dst[0] = src[0];
							dst[1] = src[1];
							dst[2] = src[2];
							src += dstbpp;
							dst += dstbpp;
						}
					}
				}
			} else {
				for (y=0; y<=((e->sy2-e->sy1)/2); y++) {
					if ( y>=(((e->sy2-e->sy1)/2)-e->step) ) {
						dif = e->curcount+(y-(((e->sy2-e->sy1)/2)-e->step));
						src = srcbuf+(e->sx1)*srcbpp+(e->sy1+dif)*srcbpl;
						dst = dstbuf+(e->dx)*dstbpp+(y+e->dy)*dstbpl;
						for (x=e->sx1; x<=e->sx2; x++) {
							dst[0] = src[0];
							dst[1] = src[1];
							dst[2] = src[2];
							src += srcbpp;
							dst += dstbpp;
						}
					} else {
						src = dstbuf+(e->dx)*dstbpp+(y+e->dy+e->step)*dstbpl;
						dst = dstbuf+(e->dx)*dstbpp+(y+e->dy)*dstbpl;
						for (x=e->sx1; x<=e->sx2; x++) {
							dst[0] = src[0];
							dst[1] = src[1];
							dst[2] = src[2];
							src += dstbpp;
							dst += dstbpp;
						}
					}
				}
				for (y=(e->sy2-e->sy1); y>=((e->sy2-e->sy1)/2)+1; y--) {
					if ( y<=(((e->sy2-e->sy1)/2)+e->step) ) {
						dif = e->curcount+((((e->sy2-e->sy1)/2)+e->step)-y);
						src = srcbuf+(e->sx1)*srcbpp+(e->sy2-dif)*srcbpl;
						dst = dstbuf+(e->dx)*dstbpp+(y+e->dy)*dstbpl;
						for (x=e->sx1; x<=e->sx2; x++) {
							dst[0] = src[0];
							dst[1] = src[1];
							dst[2] = src[2];
							src += srcbpp;
							dst += dstbpp;
						}
					} else {
						src = dstbuf+(e->dx)*dstbpp+(y+e->dy-e->step)*dstbpl;
						dst = dstbuf+(e->dx)*dstbpp+(y+e->dy)*dstbpl;
						for (x=e->sx1; x<=e->sx2; x++) {
							dst[0] = src[0];
							dst[1] = src[1];
							dst[2] = src[2];
							src += dstbpp;
							dst += dstbpp;
						}
					}
				}
			}
			e->curcount += e->step;
			if ( e->curcount>=(e->sy2-e->sy1)/2 ) e->cmd = 0;
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;

		case 120:			// �Z���^�ɍ�����E��
			sx = 0; sy = e->dy; ex = 0; ey = e->dy+e->sy2-e->sy1;
			if ( !e->step ) e->step = 16;
			for (x=e->sx1, n=0; x<=e->sx2; x+=(e->step), n++) {
				dif = e->curcount-n;
				if ( (dif>=0)&&(dif<(e->step))&&((x+dif)<=e->sx2) ) {
					src = srcbuf+(e->sy1)*srcbpl+(x+dif)*srcbpp;
					dst = dstbuf+(e->dy)*dstbpl+(x+dif-(e->sx1)+(e->dx))*dstbpp;
					msk = mskbuf+(e->sy1)*mskbpl+(x+dif);
					for (y=e->sy1; y<=e->sy2; y++) {
						if (e->mask) { maskc = *msk; msk += mskbpl; }
						PDT_Pixel(src, dst, maskc);
						src += srcbpl;
						dst += dstbpl;
					}
					ex = x+dif;
					if ( !sx ) sx = x+dif;
				}
			}
			sx += (e->dx-e->sx1);
			ex += (e->dx-e->sx1);
			e->curcount++;
			if ( e->curcount>=(((e->sx2-e->sx1)/e->step)+e->step) ) e->cmd = 0;
			break;
			
		case 121:			// �Z���^�ɉE���獶��
			sx = 0; sy = e->dy; ex = 0; ey = e->dy+e->sy2-e->sy1;
			if ( !e->step ) e->step = 16;
			for (x=e->sx2, n=0; x>=e->sx1; x-=(e->step), n++) {
				dif = e->curcount-n;
				if ( (dif>=0)&&(dif<(e->step))&&((x-dif)>=e->sx1) ) {
					src = srcbuf+(e->sy1)*srcbpl+(x-dif)*srcbpp;
					dst = dstbuf+(e->dy)*dstbpl+(x-dif-(e->sx1)+(e->dx))*dstbpp;
					msk = mskbuf+(e->sy1)*mskbpl+(x-dif);
					for (y=e->sy1; y<=e->sy2; y++) {
						if (e->mask) { maskc = *msk; msk += mskbpl; }
						PDT_Pixel(src, dst, maskc);
						src += srcbpl;
						dst += dstbpl;
					}
					sx = x-dif;
					if ( !ex ) ex = x-dif;
				}
			}
			sx += (e->dx-e->sx1);
			ex += (e->dx-e->sx1);
			e->curcount++;
			if ( e->curcount>=(((e->sx2-e->sx1)/e->step)+e->step) ) e->cmd = 0;
			break;
			
		case 122:			// �Z���^�ɏォ�牺��
			sx = e->dx; sy = 0; ex = e->dx+e->sx2-e->sx1; ey = 0;
			if ( !e->step ) e->step = 16;
			for(y=e->sy1, n=0; y<=e->sy2; y+=(e->step), n++) {
				dif = e->curcount-n;
				if ( (dif>=0)&&(dif<(e->step))&&((y+dif)<=e->sy2) ) {
					src = srcbuf+(y+dif)*srcbpl+(e->sx1)*srcbpp;
					dst = dstbuf+(y+dif-(e->sy1)+(e->dy))*dstbpl+(e->dx)*dstbpp;
					msk = mskbuf+(y+dif)*mskbpl+(e->sx1);
					for (x=e->sx1; x<=e->sx2; x++) {
						if (e->mask) maskc = *msk++;
						PDT_Pixel(src, dst, maskc);
						src += srcbpp;
						dst += dstbpp;
					}
					ey = y+dif;
					if ( !sy ) sy = y+dif;
				}
			}
			sy += (e->dy-e->sy1);
			ey += (e->dy-e->sy1);
			e->curcount++;
			if ( e->curcount>=(((e->sy2-e->sy1)/e->step)+e->step) ) e->cmd = 0;
			break;
			
		case 123:			// �Z���^�ɉ�������
			sx = e->dx; sy = 0; ex = e->dx+e->sx2-e->sx1; ey = 0;
			if ( !e->step ) e->step = 16;
			for(y=e->sy2, n=0; y>=e->sy1; y-=(e->step), n++) {
				dif = e->curcount-n;
				if ( (dif>=0)&&(dif<(e->step))&&((y-dif)>=e->sy1) ) {
					src = srcbuf+(y-dif)*srcbpl+(e->sx1)*srcbpp;
					dst = dstbuf+(y-dif-(e->sy1)+(e->dy))*dstbpl+(e->dx)*dstbpp;
					msk = mskbuf+(y-dif)*mskbpl+(e->sx1);
					for (x=e->sx1; x<=e->sx2; x++) {
						if (e->mask) maskc = *msk++;
						PDT_Pixel(src, dst, maskc);
						src += srcbpp;
						dst += dstbpp;
					}
					sy = y-dif;
					if ( !ey ) ey = y-dif;
				}
			}
			sy += (e->dy-e->sy1);
			ey += (e->dy-e->sy1);
			e->curcount++;
			if ( e->curcount>=(((e->sy2-e->sy1)/e->step)+e->step) ) e->cmd = 0;
			break;
			
		case 150:			// ��`��90�x x 4
			if ( !e->step ) e->step = 1;
			maxx = (e->sx2-e->sx1)+1;
			maxy = (e->sy2-e->sy1)+1;
			if ( !e->curcount ) {			// ����
				xx = ((e->sx2-e->sx1)>>1)+1;
				yy = ((e->sy2-e->sy1)>>1)+1;
				if ( lines ) delete[] lines;
				tmp = new unsigned char[maxx*maxy];
				lines = (int*)tmp;
				for (y=0; y<maxy; y++) {
					for (x=0; x<maxx; x++) {
						if ( y<yy ) {
							if ( x<xx ) {			// ����
								if ( !(xx-x-1) )
									n = 90;
								else
									n = atan2(yy-y-1, xx-x-1)*180/3.1416;
							} else {				// �E��
								if ( !(yy-y-1) )
									n = 90;
								else
									n = atan2(x-xx, yy-y-1)*180/3.1416;
							}
						} else {					// ����
							if ( x<xx ) {
								if ( !(y-yy) )
									n = 90;
								else
									n = atan2(xx-x-1, y-yy)*180/3.1416;
							} else {				// �E��
								if ( !(x-xx) )
									n = 90;
								else
									n = atan2(y-yy, x-xx)*180/3.1416;
							}
						}
						if ( n<0 ) n = 0;
						if ( n>89 ) n = 89;
						tmp[y*maxx+x] = (int)(n/e->step);
					}
				}
			} else {
				tmp = (unsigned char*)lines;
			}
			for(y=e->sy1; y<=e->sy2; y++) {
				src = srcbuf;
				dst = dstbuf;
				msk = mskbuf;
				for (x=e->sx1; x<=e->sx2; x++) {
					if (e->mask) maskc = *msk++;
					if (tmp[(y-e->sy1)*maxx+(x-e->sx1)]==e->curcount) PDT_Pixel(src, dst, maskc);
					src += srcbpp;
					dst += dstbpp;
				}
				srcbuf += srcbpl;
				dstbuf += dstbpl;
				mskbuf += 640;
			}
			e->curcount++;
			if ( (e->curcount*e->step)>=90 ) {
				e->cmd = 0;
				backupflag = 1;
				if ( tmp ) delete[] tmp;
				lines = 0;
			}
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;

		case 160:			// �������炾�񂾂�g��
			if ( !e->step ) e->step = 32;
			e->curcount++;
			xx = (e->sx2-e->sx1)/2;
			yy = (e->sy2-e->sy1)/2;
			if ( xx>yy ) {
				if ( (e->curcount*e->step)>=xx ) {
					e->cmd = 0;
					xx2 = xx;
				} else
					xx2 = (e->curcount*e->step);
				yy2 = (yy*xx2)/xx;
			} else {
				if ( (e->curcount*e->step)>=yy ) {
					e->cmd = 0;
					yy2 = yy;
				} else
					yy2 = (e->curcount*e->step);
				xx2 = (xx*yy2)/yy;
			}
			sys->UnlockPDT(e->dstpdt, 0, 0, 0, 0, 0);
			StretchCopy( e->sx1, e->sy1, e->sx2, e->sy2, e->srcpdt,
						 e->dx+xx-xx2,
						 e->dy+yy-yy2,
						 e->dx+xx+xx2+1,
						 e->dy+yy+yy2+1,
						 e->dstpdt);
			if ( e->curcount==e->step ) e->cmd = 0;
			return;
			break;

		case 163:			// �g�債�Ă����Đ؂�ւ��ďk���i���ˊ�Q�j
			tmpbuf = pdt[3]->GetBuffer();
			if ( !e->curcount ) {
				e->steptime <<= 5;		// �Ȃ񂩑���������
				// �o�b�N�A�b�v�����
				for (y=0; y<=479; y++) {
					dst = dstbuf;
					tmp = tmpbuf;
					for (x=0; x<=639; x++) {
						tmp[0] = dst[0];
						tmp[1] = dst[1];
						tmp[2] = dst[2];
						dst += dstbpp;
						tmp += 3;
					}
					dstbuf += dstbpl;
					tmpbuf += 640*3;
				}
				tmpbuf = pdt[3]->GetBuffer();
				dstbuf = pdt[e->dstpdt]->GetBuffer();
				if ( !e->dstpdt ) dstbuf++;
			}
			xx = (e->sx2-e->sx1)/2;
			yy = (e->sy2-e->sy1)/2;
			if ( e->curcount<8 ) {
				n = e->curcount;
				i = 3;
			} else {
				n = 15-e->curcount;
				i = e->srcpdt;
			}
			xx2 = (xx/(1<<n));
			yy2 = (yy/(1<<n));
			sys->UnlockPDT(e->dstpdt, 0, 0, 0, 0, 0);
			StretchCopy( e->sx1+xx-xx2,
						 e->sy1+yy-yy2,
						 e->sx1+xx+xx2+1,
						 e->sy1+yy+yy2+1,
						 i,
						 e->dx,
						 e->dy,
						 e->dx+e->sx2-e->sx1,
						 e->dy+e->sy2-e->sy1,
						 e->dstpdt);
			e->curcount++;
			if ( e->curcount>=16 ) e->cmd = 0;
			return;
 			break;

		case 170:			// ���X�^�X�N���[�����Ȃ����ʐ؂�ւ�
							// 4���C�����K���Z�b�g�ix120�g�j�A�p�x�ω��͕K��4�x�݂���
			tmpbuf = pdt[3]->GetBuffer();
			if ( !e->curcount ) {
				e->arg5 = 0;		// �U��
				// �o�b�N�A�b�v�����
				for (y=0; y<=479; y++) {
					dst = dstbuf;
					tmp = tmpbuf;
					for (x=0; x<=639; x++) {
						tmp[0] = dst[0];
						tmp[1] = dst[1];
						tmp[2] = dst[2];
						dst += dstbpp;
						tmp += 3;
					}
					dstbuf += dstbpl;
					tmpbuf += 640*3;
				}
				tmpbuf = pdt[3]->GetBuffer();
				dstbuf = pdt[e->dstpdt]->GetBuffer();
				if ( !e->dstpdt ) dstbuf++;
			}
			if ( e->curcount<=63 ) {
				// �U�����傫���Ȃ��Ă���			//�i10pixel x 64��A�A�����m�ł͂Ȃ������j
				e->arg5 += 10;
			} else if ( e->curcount>=104 ) {		//�i10pixel x 64��A�A�����m�ł͂Ȃ������j
				// �U�����������Ȃ��Ă���
				e->arg5 -= 10;
			} else {
				// �U���ő厞�A���X��src�o�b�t�@��CG�ƒu��������
				// 4���C��1�g��40�Z�b�g��160pixel�����ɌJ��Ԃ��ɂ��Ă邯�ǁA��������m����Ȃ������c�c
				n = (e->curcount-64)<<2;
				for (y=(e->sy1+n); y<=e->sy2; y+=160) {
					for (i=y; (i<(y+4))&&(i<=e->sy2); i++) {
						tmp = tmpbuf+i*640*3+e->sx1*3;
						src = srcbuf+i*srcbpl+e->sx1*srcbpp;
						for (x=e->sx1; x<=e->sx2; x++) {
							tmp[0] = src[0];
							tmp[1] = src[1];
							tmp[2] = src[2];
							tmp += 3;
							src += srcbpp;
						}
					}
				}
			}
			// 1��̕`�斈�ɁA�J�n�p�x��4�x�ω�������ۂ�
			n = ((e->curcount%90)<<2);
			tmpbuf += e->sy1*640*3+e->sx1*3;
			dstbuf += e->dy*dstbpl+e->dx*dstbpp;
			for (y=e->sy1; y<=e->sy2; y+=4) {
				xx = e->arg5*sin(n*3.1416/180);
				for (i=0; (i<4)&&((y+i)<=e->sy2); i++) {
					tmp = tmpbuf;
					dst = dstbuf;
					xx2 = (e->sx1+xx);
					// �摜�������ɂ��˂��Ă�ꍇ�p�̕␳
					if ( xx2<e->sx1 ) {
						tmp += (e->sx1-xx2)*3;
						xx2 = e->sx1;
					}
					// �摜���E���ɂ��˂��Ă�ꍇ�B���������Ŗ��߂�
					for (x=e->sx1; (x<xx2)&&(x<=e->sx2)&&(x>=e->sx1); x++) {
						dst[0] = dst[1] = dst[2] = 0;
						dst += dstbpp;
					}
					// �摜�{��
					for (x=xx2; (x<=(e->sx2+xx))&&(x<=e->sx2); x++) {
						dst[0] = tmp[0];
						dst[1] = tmp[1];
						dst[2] = tmp[2];
						tmp += 3;
						dst += dstbpp;
					}
					// ���̖��ߎn�ߒn�_�����[��������ɍ��ɂ͂ݏo���Ă�ꍇ�̕␳
					xx2 = (e->sx2+xx+1);
					if ( xx2<e->sx1 ) {
						xx2 = e->sx1;
					}
					// �摜�������ɂ��˂��Ă�ꍇ�B�E�������Ŗ��߂�
					for (x=xx2; (x<=e->sx2); x++) {
						dst[0] = dst[1] = dst[2] = 0;
						dst += dstbpp;
					}
					tmpbuf += 640*3;
					dstbuf += dstbpl;
				}
				// 1�Z�b�g�i4���C���j����4�x�p�x���ω�������ۂ�
				n = (n+4)%360;
			}
			e->curcount++;
			// 64�i�U�������j�{40�i�摜���ցj�{64�i�U�������j��168��őS�ďI��
			if ( e->curcount>=168 ) e->cmd = 0;
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;

		case 180:			// 16x16�̃h�b�g�������_���� (32�i�K)
			maxx = (e->sx2-e->sx1+16)>>4;
			maxy = (e->sy2-e->sy1+16)>>4;
			if ( !e->curcount ) {
				if ( lines ) delete[] lines;
				lines = new int[maxx*maxy];
				for (y=0; y<maxy; y++) {
					for (x=0; x<maxx; x++) {
						lines[y*maxx+x] = sys->GetRandom(0, 31);
					}
				}
			}
			for(yy=e->sy1; yy<=e->sy2; yy+=16) {
				for(y=yy; y<(yy+16); y++) {
					if ( y<=e->sy2 ) {
						src = srcbuf+y*srcbpl;
						dst = dstbuf+(y-e->sy1+e->dy)*dstbpl;
						msk = mskbuf+y*mskbpl;
						for (xx=e->sx1; xx<=e->sx2; xx+=16) {
							if ( lines[(maxx*((yy-e->sy1)>>4))+((xx-e->sx1)>>4)]==e->curcount ) {
								for (x=xx; x<(xx+16); x++) {
									if ( x<=e->sx2 ) {
										if (e->mask) maskc = *(msk+x);
										PDT_Pixel(src+x*srcbpp, dst+(x-e->sx1+e->dx)*dstbpp, maskc);
									}
								}
							}
						}
					}
				}
			}
			e->curcount++;
			if ( e->curcount==32 ) {
				e->cmd = 0;
				backupflag = 1;
				if ( lines ) delete[] lines;
				lines = 0;
			}
			sx = e->dx; sy = e->dy; ex = e->dx+e->sx2-e->sx1; ey = e->dy+e->sy2-e->sy1;
			break;

		case 1000:			// Scroll Screen Switch / Use Effect
			if ( !e->step ) e->step = 16;
			if ( !e->curcount ) {	// Backup the source buffer
				Copy(0, 0, 639, 479, 0, 0, 0, 3, 0);
			}

			e->curcount += e->step;
			if ( e->curcount>e->arg6 )  {
				e->step -= (e->curcount-e->arg6);
				e->curcount = e->arg6;
			}
			if ( e->arg4 ) {	// ���փX�N���[��
				for(y=e->sy2; y>=e->sy1; y--) {
					if ( (y-e->step)<e->sy1 ) {
						src = srcbuf+(e->sy2-e->curcount+(y-e->sy1))*srcbpl+e->sx1*srcbpp;
						dst = dstbuf+y*dstbpl+(e->sx1)*dstbpp;
						for (x=e->sx1; x<=e->sx2; x++) {
							dst[0] = src[0];
							dst[1] = src[1];
							dst[2] = src[2];
							src += srcbpp;
							dst += dstbpp;
						}
					} else {
						src = dstbuf+(y-e->step)*dstbpl+(e->sx1)*dstbpp;
						dst = dstbuf+y*dstbpl+(e->sx1)*dstbpp;
						for (x=e->sx1; x<=e->sx2; x++) {
							dst[0] = src[0];
							dst[1] = src[1];
							dst[2] = src[2];
							src += dstbpp;
							dst += dstbpp;
						}
					}
				}
				if ( e->curcount>=e->arg6 ) {
					CopyReverse(e->sx1, e->sy1, e->sx2, e->sy2-e->arg6, 1, e->sx1, e->sy1+e->arg6, 1, 0);
					Copy(e->sx1, e->sy2-e->arg6+1, e->sx2, e->sy2, 3, e->sx1, e->sy1, 1, 0);
					e->cmd = 0;
				}
			} else {			// ��փX�N���[��
				for(y=e->sy1; y<=e->sy2; y++) {
					if ( (y+e->step)>e->sy2 ) {
						src = srcbuf+(y+e->curcount-(e->sy2-e->sy1))*srcbpl+e->sx1*srcbpp;
						dst = dstbuf+y*dstbpl+e->sx1*dstbpp;
						for (x=e->sx1; x<=e->sx2; x++) {
							dst[0] = src[0];
							dst[1] = src[1];
							dst[2] = src[2];
							src += srcbpp;
							dst += dstbpp;
						}
					} else {
						src = dstbuf+(y+e->step)*dstbpl+(e->sx1)*dstbpp;
						dst = dstbuf+y*dstbpl+(e->sx1)*dstbpp;
						for (x=e->sx1; x<=e->sx2; x++) {
							dst[0] = src[0];
							dst[1] = src[1];
							dst[2] = src[2];
							src += dstbpp;
							dst += dstbpp;
						}
					}
				}
				if ( e->curcount>=e->arg6 ) {
					Copy(e->sx1, e->sy1+e->arg6, e->sx2, e->sy2, 1, e->sx1, e->sy1, 1, 0);
					Copy(e->sx1, e->sy1, e->sx2, e->sy1+e->arg6-1, 3, e->sx1, e->sy2-e->arg6, 1, 0);
					e->cmd = 0;
				}
			}
			sx = e->sx1; sy = e->sy1; ex = e->sx2; ey = e->sy2;
			break;

		case 9999:			// Continuous Stretch Blt / Use Effect
			if ( !e->step ) e->step = 16;
			if ( !e->curcount ) {	// Backup the source buffer
				if ( temppdt ) {
					delete temppdt;
					temppdt = 0;
				}
				temppdt = new PDTBUFFER(640, 480, 3, 640*3, true);
				if ( !temppdt ) break;
				tmpbuf = temppdt->GetBuffer();
				for (y=0; y<=479; y++) {
					src = srcbuf;
					tmp = tmpbuf;
					for (x=0; x<=639; x++) {
						tmp[0] = src[0];
						tmp[1] = src[1];
						tmp[2] = src[2];
						src += srcbpp;
						tmp += 3;
					}
					srcbuf += srcbpl;
					tmpbuf += 640*3;
				}
//				tmpbuf = temppdt->GetBuffer();
//				srcbuf = pdt[e->srcpdt]->GetBuffer();
//				if ( !e->srcpdt ) srcbuf++;

				if ( e->sx1>e->sx2 ) { temp=e->sx1; e->sx1=e->sx2; e->sx2=temp; }
				if ( e->sy1>e->sy2 ) { temp=e->sy1; e->sx1=e->sy2; e->sy2=temp; }
				if ( e->dx>e->arg1 ) { temp=e->dx; e->dx=e->arg1; e->arg1=temp; }
				if ( e->dy>e->arg2 ) { temp=e->dy; e->dy=e->arg2; e->arg2=temp; }
				if ( e->arg3>e->arg5 ) { temp=e->arg3; e->arg3=e->arg5; e->arg5=temp; }
				if ( e->arg4>e->arg6 ) { temp=e->arg4; e->arg4=e->arg6; e->arg6=temp; }
			} else {
				if ( !temppdt ) break;
			}
			e->curcount++;
			sys->UnlockPDT(e->dstpdt, 0, 0, 0, 0, 0);
			StretchCopy( (((e->arg3-e->sx1)*e->curcount)/e->step)+e->sx1,
						 (((e->arg4-e->sy1)*e->curcount)/e->step)+e->sy1,
						 (((e->arg5-e->sx2)*e->curcount)/e->step)+e->sx2,
						 (((e->arg6-e->sy2)*e->curcount)/e->step)+e->sy2,
						 temppdt,
						 e->dx, e->dy, e->arg1, e->arg2, e->dstpdt);
			if ( e->curcount>=e->step ) {
				e->cmd = 0;
				delete temppdt;
				temppdt = 0;
			}
			return;
			break;

		default:
			dprintf("********* Un-Impremented Effect : %d\n", e->cmd);
			e->cmd = 0;
			break;
	}

	sys->UnlockPDT(e->dstpdt, sx, sy, ex+1, ey+1, 1);

	// �G�t�F�N�g�̂������́A�I�����PDT0�̓��e��PDT3�ɂ������Ă�݂���
	// �iKanon�̂���̂Ƃ��̐�Ƃ��ARibbon2�̎����Ƃ��j
	// ���Ȃ��Ƃ�#4�Ƃ��̃t�F�[�h�n�͎c���Ă�͗l�B�e���|�����Ƃ��Ďg���
	// �Ă�̂��ȁH
	if ( backupflag ) AllCopy(0, 3, 0);
};


/* -------------------------------------------------------------------
  �t�F�[�h�C���^�A�E�g�����BEffect�g���΂悩�������ȁE�E�E
------------------------------------------------------------------- */
void PDTMGR::ScreenFade(unsigned int cmd, unsigned int count, int r, int g, int b)
{
	unsigned char *dst, *dstbuf;
	int dstbpl, x, y;

	if ( !pdt[0] ) return;		// ���S�̂���
	sys->LockPDT(0);

	dstbpl = pdt[0]->GetBPL();
	dstbuf = pdt[0]->GetBuffer();

	switch (cmd) {
		case 0x10:
		case 0x11:
//			dstbuf += EFF4Y[count]*dstbpl+(EFF4X[count]<<2);
			for(y=0; y<=479; y++) {
				dst = dstbuf;
				for (x=0; x<=639; x++) {
					dst++;
					*(dst++) = r;
					*(dst++) = g;
					*(dst++) = b;
//					dst += 12;
				}
//				dstbuf += (dstbpl<<2);
				dstbuf += dstbpl;
			}
			break;
		default:
			dstbuf += EFF4Y[count]*dstbpl+(EFF4X[count]<<2);
			for(y=EFF4Y[count]; y<=479; y+=4) {
				dst = dstbuf;
				for (x=EFF4X[count]; x<=639; x+=4) {
					dst++;
					*(dst++) = r;
					*(dst++) = g;
					*(dst++) = b;
					dst += 12;
				}
				dstbuf += (dstbpl<<2);
			}
			break;
	}

	sys->UnlockPDT(0, 0, 0, 639, 479, 1);
};
