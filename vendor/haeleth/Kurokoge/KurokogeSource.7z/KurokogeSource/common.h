/*=======================================================================
  AVG32-like scriptor for Macintosh
  Copyright 2000, K.Takagi(Kenjo)

  common.h
    ��ʓI�Ȓ�`�̗�
=======================================================================*/

#ifndef _avg32_common_h
#define _avg32_common_h

void Error(char* msg);

#endif// _avg32_common_h
