/*=======================================================================
  AVG32-like scriptor for Macintosh
  Copyright 2000, K.Takagi(Kenjo)

  system.h
    Mac�V�X�e���ˑ�����

  �ύX����
      2002/01/14 : F.Shiraishi
				   TARGET_CARBON �}�N���� TARGET_API_MAC_CARBON �}�N���ɕύX

      2002/01/14 : F.Shiraishi
				   �C���N���[�h�t�@�C���� Carbon.h, DSpFullScreen.h, pdtmacro.h 
				   �ɕύX

      2002/01/14 : F.Shiraishi
					Mac OS X �ł̃t���X�N���[�����ɑΉ�����ׁAbkfullscreen �����o�̌^��
					Ptr ���� FullScreenStatusRef �ɕύX

      2002/01/14 : F.Shiraishi
					��L�}�E�X�J�[�\���̍��W�n�ϊ����W�b�N�Ŏg�p����
					�}�E�X�J�[�\���̃��[�J�����W���擾���郋�[�`�� SYSTEM::GetLocalMouse()
					�̊֐��v���g�^�C�v���A�N�Z�X�w�� public �ɒǉ�

      2005/02 : P.Jolly
                    �p��łj�����������������߁A���b�Z�[�W���[�`���𒼂�����B

=======================================================================*/

#ifndef _system_h
#define _system_h

#ifndef __CARBON__
#include <Carbon.h>
#endif
#ifndef __DSPFULLSCREEN__
#include "DSpFullScreen.h"
#endif
#ifndef _pdtmacro_h
#include "pdtmacro.h"
#endif

#define MAX_SEL 256
#define MAXSELECT 24
#define MAX_SE 16

#define MAX_MENU 32

struct EFFECT {
	int sx1;
	int sy1;
	int sx2;
	int sy2;
	int dx;
	int dy;
	unsigned int cmd;
	unsigned int steptime;
	unsigned int prevtime;
	int srcpdt;
	int dstpdt;
	int mask;
	int step;
	int curcount;
	int arg1;
	int arg2;
	int arg3;
	int arg4;
	int arg5;
	int arg6;
};

struct ANM {
	int sx1;
	int sy1;
	int sx2;
	int sy2;
	int dx;
	int dy;
	int wait;
};

struct INIFILE {
	EFFECT sel[MAX_SEL];
	char cd[100][32];
	struct DSTABLE {
		char name[32];
		char file[32];
		int cutsize;
	} dsound[100];
	int dsnum;
	char name[26][128];
	char wakufile[32];
	char savefile[32];
	char caption[128];
	char pdtdir[32];
	char anmdir[32];
	char txtdir[32];
	char wavdir[32];
	char curdir[32];
	char arddir[32];
	char othdir[32];
	char pdtpack[32];
	char anmpack[32];
	char txtpack[32];
	char wavpack[32];
	char curpack[32];
	char ardpack[32];
	char othpack[32];
	char pdtpackflag;
	char anmpackflag;
	char txtpackflag;
	char wavpackflag;
	char curpackflag;
	char ardpackflag;
	char othpackflag;
	char koedir[32];
	char movdir[32];
	char bgmdir[32];
	char exfont[32];
	char regname[256];
	char saveheader[128];
	char savenotitle[256];
	char se[MAX_SE][32];
	int musictype;
	int musiclinear;
	int wavlinear;
	int koelinear;
	int koetype;
	int exfontx;
	int exfonty;
	int exfontmaxx;
	int exfontmaxy;
	int colortable[16][3];
	int fadetable[16][3];
	int shake[16][16][3];
	int shakecount[16];
	int wincolor[3];
	int wincolorflag;
	int sysmenusw[32];
	int winstyle;
	int winatrx1;
	int winatry1;
	int winatrx2;
	int winatry2;
	int winx;
	int winy;
	int mesx;
	int mesy;
	int subwinx;
	int subwiny;
	int subwinmin;
	int fontx;
	int fonty;
	int fontcolor;
	int kagecolor;
	int meswait;
	int fontsize;
	int nameindent;
	int namesp;
	int selblinkcount;
	int selblinktime;
	int startseen;
	int menuseen;
	int savefilenum;
	int defaultfadetime;
	int mesiconwait;
	int mesiconx;
	int mesicony;
	int mesiconnum;
	int novelmode;
};

class FLAGS;
class CGMODE;
class SCENARIO;
class NOVELFONT;
class PDTMGR;
class PDTBUFFER;
class PDTFILE;
class SOUND;
class AVG32MOUSE;

class SYSTEM
{
private:
	WindowPtr hWnd;
	FLAGS* flags;
	CGMODE* cgm;
	PDTMACRO* macro;
	SCENARIO* scn;
	NOVELFONT* nvlfont;
	PDTMGR* mgr;
	SOUND* sound;
	AVG32MOUSE* mouse;
	MACROITEM mm;

	MenuHandle menus[MAX_MENU+1];
	int menushier[MAX_MENU+1];
	int menuid[MAX_MENU*2];
	int menusysid[MAX_MENU*2];
	int menuflag[MAX_MENU+1];
	unsigned char menuname[MAX_MENU+1][256];
	int popupflag;
	MenuHandle applmenu;
	MenuHandle systmenu;
	MenuHandle filemenu;
	MenuHandle popupmenu;
	MenuHandle debugmenu;
	int savemenuflag;

	EFFECT scnefct;
	unsigned char mesbuf[2048];
	unsigned char* mesbufptr;
	int mesredraw;
	int hankaku;
	short fontid;
	int mesindent;
	int indentflag;
	int curmesx, curmesy;
	unsigned int curmestime;
	int mesicon;
	unsigned int mesiconbase;
	int oldmesx, oldmesy;
	int oldwinx, oldwiny;
	int subwinflag;
	int AbortFlag;

	char selitem[MAXSELECT][255];
	int selitemnum;
	int selitemenable[MAXSELECT];
	int selitemcolor[MAXSELECT];
	int selitemid[MAXSELECT];
	bool selitemflag;
	int selitemold;
	int selfinish;
	int selfinishcount;
	unsigned int selfinishbase;
	int selnovelsetup;
	int selcurid;

	int shakepattern;
	int shakecount;
	unsigned int shakebase;
	unsigned int shaketime;

	int curanmseen;
	int curanmstream;
	int curanmframe;
	int endanmstream;
	int endanmframe;
	int maxanmseen;
	int maxanmstream;
	int maxanmframe;
	unsigned int prevanmtime;
	unsigned int anmwait;
	unsigned char* anmbuf;
	ANM anmcell[256];

	int multianmseen[64];
	int multianmstream[64];
	int multianmframe[64];
	int multiendanmstream[64];
	int multiendanmframe[64];
	int multianmwait[64];
	int multianmprevtime[64];
	char curanmname[16];
	int multianmnum;

	GWorldPtr offscreen;
	PixMapHandle pixmap;
	GDHandle gd_backup;
	GWorldPtr gw_backup;

	int MesWinFlag;
	int MesIconFlag;
	int MesWinStyle;
	int MesWinStyleForce;
	int MesWinX1, MesWinY1, MesWinX2, MesWinY2;
	int MacroItemNum;
	int RunningFlag;
	int ActiveFlag;
	int SkipEnableFlag;
	int MouseClickFlag;
	int KeyDownFlag;
	unsigned int MouseClickTime;
	unsigned int KeyDownTime;
	UnsignedWide TimerBase;
	int LastMouseX;
	int LastMouseY;
	int KeySelect;

	int doubletext;
	int doubleline;

	EFFECT loadefct;
	int loadingtime;
	int loadingcount;

	char loadingtitle[256];
	char curtitle[256];
	char loadingbgm[64];
	char savedataflag[32];
	char savedatatitle[32][256];
	int savedatadate[32];
	int savedatatime[32];

	int hidewindow;
	int curfont;
	int loading;

	INIFILE ini;

	int version;
	FullScreenStatusRef bkfullscreen;
	int FullScrSW;
	int FullScrMenu;

	// for Message Speed Change Dialog
	static unsigned int MsgDlgTimebase;
	static int MsgDlgCount;
	static unsigned char MsgDlgBuf[256];
	static short MsgDlgSpeed;
	static Handle MsgDlgItem;

	void AboutDlg(void);
	int QuitDlg(void);
	int MenuDlg(void);
	void ColorCfgDlg(void);
	void MsgSpeedDlg(void);
	static pascal Boolean MsgDlgFilter(DialogPtr dlg, EventRecord* ev, short* item);
	void MenuFunc(long m);
	void MouseDownFunc(EventRecord* ev);
	void MouseUpFunc(EventRecord* ev);
	void KeyDownFunc(char code);
	void Update(WindowPtr wnd);
	void OSEventFunc(unsigned long mes);
	void IdleFunc(void);

	int CheckSkipKey(void);

	void CheckINIItem(char* buf);
	void CheckSetupINIItem(char* buf);
	bool CmpStr(char* src, char* dst);
	bool SearchChar(char* &buf, char c);
	int ReadNum(char* &buf);
	void ReadString(char* &buf, char *out);

	void UpdateScreen(WindowRef);
	int Select_Finish(void);
public :
	SYSTEM(WindowPtr wnd, GWorldPtr os, PixMapHandle pm, PDTBUFFER* pdtb);
	~SYSTEM(void);

	static SYSTEM* Create(WindowPtr wnd);
	void Init(void);
	void Reset(void);
	void EventLoop(void);
	void ChangeFullScreen(int sw);
	void MenuON(void);
	void MenuOFF(void);

	void Abort(char* mes);
	void Quit(void);

	void GetLocalMouse(Point*);

	void ConvertCapital(unsigned char* buf);

	int GetStartSeen(void) { return ini.startseen; };
	int GetMenuSeen(void) { return ini.menuseen; };

	char* GetPDTDir(void) { return ini.pdtdir; };
	int GetFontSize(void) { return ini.fontsize; };
	int GetFontX(void) { return ini.fontx; };
	int GetFontY(void) { return ini.fonty; };
	int GetFontID(void) { return fontid; };
	void SetNovelModeFlag(int sw);
	void SetMsgSpeed(int n);
	int GetMsgSpeed(void);
	void SetFontSize(int x, int y);
	void GetFontSize(int* x, int* y);
	int GetKageColor(void) { return ini.kagecolor; };
	void SetKageColor(int c);
	int GetCGPercentage(void);
	int GetCGFlag(int n);
	int GetCGFlagNum(int n);
	int GetCGAllNum(void);
	int GetCGNum(void);
	char* GetCGName(int n);
	void GetFadeColor(int c, int *r, int *g, int* b) { *r=ini.fadetable[c][0]; *g=ini.fadetable[c][1]; *b=ini.fadetable[c][2]; };
	int GetFadeTime(void) { return ini.defaultfadetime; };
	void GetNameString(int num, char* buf);
	void SetNameString(int num, char* buf);
	void GetMesWinColor(int* flag, int* r, int* g, int* b);
	void SetMesWinColor(int flag, int r, int g, int b);
	void SetSkipEnable(int sw) { SkipEnableFlag = sw; };

	void NameInputDlg(char* title1, char* title2, int index1, int index2);
	void ConvertString(unsigned char* out, char* in);
	void SetWindowTitle(char* s, int flag);

	int CheckSkip(void);
	int GetKeyInput(void);

	void ResetTimer(void);
	unsigned int GetCurrentTimer(void);
	int GetTimer(void);
	int GetRandom(int lo, int hi);
	int GetDateTime(int n);

	void CheckVersion(void);
	int Version(void) { return version; }
	void Terminate(void) { RunningFlag = 0; };
	int IsActive(void) { return ActiveFlag; };

	int ReadINIFile(char* f);
	unsigned char* ReadFile(char* file, char* type, int* size);
	unsigned char* Unpack(unsigned char* src, int* size);

	void SnrPDT_ScreenFade(unsigned int cmd, unsigned int count, int r, int g, int b);
	void SnrPDT_LoadFile(char* f, int dst);
	void SnrPDT_LoadCopy(char* f, int sx1, int sy1, int sx2, int sy2, int dx, int dy, int dstpdt, int flag, int subcmd);
	void SnrPDT_LoadEffect(char* f, EFFECT* e);
	void SnrPDT_Copy(int sx1, int sy1, int sx2, int sy2, int src, int dx, int dy, int dst, int flag);
	void SnrPDT_CopyBackBuffer(int sx1, int sy1, int sx2, int sy2, int src, int update);
	void SnrPDT_MaskCopy(int sx1, int sy1, int sx2, int sy2, int src, int dx, int dy, int dst, int flag);
	void SnrPDT_MaskCopy(int sx1, int sy1, int sx2, int sy2, PDTBUFFER* src, int dx, int dy, int dst, int flag);
	void SnrPDT_MonoCopy(int sx1, int sy1, int sx2, int sy2, int src, int dx, int dy, int dst, int r, int g, int b);
	void SnrPDT_FadeColor(int sx1, int sy1, int sx2, int sy2, int src, int c1, int c2, int c3, int count);
	void SnrPDT_CopyWithMask(int sx1, int sy1, int sx2, int sy2, int src, int dx, int dy, int dst, int flag);
	void SnrPDT_MakeMonochrome(int sx1, int sy1, int sx2, int sy2, int src);
	void SnrPDT_MakeInvert(int sx1, int sy1, int sx2, int sy2, int src);
	void SnrPDT_MakeColorMask(int sx1, int sy1, int sx2, int sy2, int src, int r, int g, int b);
	void SnrPDT_StretchCopy(int sx1, int sy1, int sx2, int sy2, int src, int dx1, int dy1, int dx2, int dy2, int dst);
	void SnrPDT_Effect(EFFECT* effect);
	void SnrPDT_FillRect(int sx1, int sy1, int sx2, int sy2, int srcpdt, int r, int g, int b);
	void SnrPDT_ClearRect(int sx1, int sy1, int sx2, int sy2, int srcpdt, int r, int g, int b);
	void SnrPDT_DrawRectLine(int sx1, int sy1, int sx2, int sy2, int srcpdt, int r, int g, int b);
	void SnrPDT_AllCopy(int srcpdt, int dstpdt, int flag);
	void SnrPDT_Swap(int sx1, int sy1, int sx2, int sy2, int src, int dx, int dy, int dst);
	void SnrPDT_MultiLoadFile(char* f);
	void SnrPDT_MultiLoadPDT(int n);
	void SnrPDT_Get(int sx1, int sy1, int sx2, int sy2, int srcpdt);
	void SnrPDT_Put(int dx, int dy, int dstpdt);
	void SnrPDT_DrawString(int dx, int dy, int dstpdt, int r, int g, int b, char* s);

	void Effect(EFFECT* effect);

	PDTBUFFER* MakePDT(char* f);
	PDTFILE* OpenPDT(char* f);

	bool MesWin_Setup(int n);
	void MesWin_DrawWaku(void);
	void MesWin_Draw(void);
	void MesWin_Hide(void);
	void MesWin_HideTemp(void);
	void MesWin_SetMes(char* buf);
	void MesWin_ClearMes(void);
	void MesWin_ClearWindow(void);
	int MesWin_LineFeed(void);
	void MesWin_ResetMesPos(void);
	void MesWin_PutChar(void);
	void MesWin_PutChar_Novel(void);
	int MesWin_PrintMes(void);
	int MesWin_PrintMesAll(void);
	int GetMesWait(void) { return ini.meswait; };
	void MesWin_DrawIcon(int n);
	void MesWin_DrawIcon_Novel(int n);
	void MesWin_HideIcon(void);
	void MesWin_SetPos(int x, int y);
	void MesWin_GetPos(int* x, int* y);
	void MesWin_SetSubPos(int x, int y);
	void MesWin_GetSubPos(int* x, int* y);
	void MesWin_SetSize(int w, int h);
	void MesWin_GetSize(int* w, int* h);
	void MesWin_SetSubSize(int w);
	void MesWin_GetSubSize(int* w);
	void MesWin_PutNovelChar(int dx, int dy, int c);
	void MesWin_DrawNovelIcon(int dx, int dy, int c);
	void MesWin_PutExFont(int dx, int dy, int c);
	int MesWin_InEffect(void);
	void MesWin_DoubleText(int flag) { doubletext = flag; };
	void ChangeFontColor(int n);
	void ChangeMesWinStyle(int n);

	void CopySel(int sel, EFFECT* e);
	int GetMacroNum(void) { return macro->GetMacroNum(); };
	void DeleteMacro(int n) { macro->DeleteMacro(n); };
	void ClearMacro(void) { macro->ClearMacro(); };

	void LockPDT(int n);
	void UnlockPDT(int n, int x1, int y1, int x2, int y2, int update);
	void ClearScreen(void);

	void Select_AddItem(char* buf, int flag, int col);
	int Select(void);
	int Select_Novel(void);
	void Select_SubWinSetup(void);
	void Select_SubWinClose(void);

	bool ScreenShake(void);
	void ScreenShakeSetup(int n);
	
	int GetAnmCell(int seen, int stream, int frame);
	bool AnimationSetup(char* f, int n);
	bool AnimationExec(void);
	void MultiAnimationSetup(char* f, int n);
	void MultiAnimationExec(void);
	void MultiAnimationClear(void);
	void MultiAnimationStop(char* f, int n);

	int LoadInt(unsigned char* buf, int pos);
	void LoadStr(unsigned char* dst, int pos, char* src, int len);
	int Load(FLAGS* f, int n, int* seenptr, int* posptr);
	void SaveInt(unsigned char* buf, int pos, int n);
	void SaveStr(unsigned char* dst, int pos, char* src, int len);
	void Save(FLAGS* f, int n, int seen, int pos);
	void LoadGlobalFlags(FLAGS* f);
	void SaveGlobalFlags(FLAGS* f);
	bool LoadingProc(void);
	void AddSaveLoadMenu(void);
	void SetMenuTable(MenuHandle* m);
	int PopupLoadMenu(void);
	void MenuEnable(int num, int sw);
	int GetMenuEnable(int num);
	void PopupMenuEnable(int sw);
	void PopupContextMenu(void);
	int CheckSaveData(int num);
	int CheckSaveDataDate(int num);
	int CheckSaveDataTime(int num);
	char* CheckSaveDataTitle(int num);
	void SetSaveDataTitle(int num, char* buf);

	int CheckNovelSave(void);

	void PlaySE(int n);

	void TakeScreenShot();
};

WindowRef MakeWindow640x480( void );

#endif
