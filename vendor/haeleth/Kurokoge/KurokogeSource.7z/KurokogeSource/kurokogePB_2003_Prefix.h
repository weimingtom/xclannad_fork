//
// Prefix header for all source files of the 'kurokogePB_2003' target in the 'kurokogePB_2003' project.
//

#include <Carbon/Carbon.h>
