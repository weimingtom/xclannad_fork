/*
 *  CD.cpp
 *  CD
 *
 *  Created by keta on Thu Jan 16 2003.
 *  Copyright (c) 2003 __MyCompanyName__. All rights reserved.
 *
 */

#include <stdio.h>
#include <CoreFoundation/CoreFoundation.h>

#include "CD.h"




/*------------------------------------------------------------------
	Cのテキストを Str255に
------------------------------------------------------------------*/

static void CopyCToPascal( const char *in, Str255 out )
{
    short len;
	
    len = strlen( in );
    out[0] = len;
	
    for( short i = 0; i < len; i++ )
        out[i+1] = in[i];
}




/*------------------------------------------------------------------
    コンストラクタ
------------------------------------------------------------------*/

CD::CD() : mNowPlaying(NULL)
{
    EnterMovies();
}


/*------------------------------------------------------------------
    デストラクタ
------------------------------------------------------------------*/

CD::~CD()
{
    map<int, soundFile *>::iterator it;

    for( it = mTrackMap.begin(); it != mTrackMap.end(); it++ )
    {
        if( it->second != NULL )
            delete it->second;
    }

    ExitMovies();
}



/*------------------------------------------------------------------
    再生
------------------------------------------------------------------*/
OSErr CD::play( int track )
{
    map<int, soundFile *>::iterator it;
    
    it = mTrackMap.find( track );

    if( mTrackMap.end() != it )
    {
        mNowPlaying = it->second;
        mNowPlaying->play();

        return noErr;
    }
    else
    {
        // 何らかのエラーをとりあえず返しておく
        return 1;
    }
}


/*------------------------------------------------------------------
    再生
------------------------------------------------------------------*/
OSErr CD::play()
{
    if( mNowPlaying != NULL )
        return mNowPlaying->play();
    else
        return noErr;
}



/*------------------------------------------------------------------
    一時停止
------------------------------------------------------------------*/
OSErr CD::pause()
{
    if( mNowPlaying != NULL )
        return mNowPlaying->pause();
    else
        return noErr;
}



/*------------------------------------------------------------------
    一時停止
------------------------------------------------------------------*/
OSErr CD::resume()
{
    if( mNowPlaying != NULL )
        return mNowPlaying->resume();
    else
        return noErr;
}



/*------------------------------------------------------------------
    停止
------------------------------------------------------------------*/
OSErr CD::stop()
{
    OSErr result = noErr;
    
    if( mNowPlaying != NULL )
    {
        result = mNowPlaying->stop();
        mNowPlaying = NULL;
    }
    
    return result;
}


/*------------------------------------------------------------------
    時々呼んでやらないと止まる
------------------------------------------------------------------*/
OSErr CD::task()
{
    bool done;

    if( mNowPlaying != NULL )
    {
        mNowPlaying->isDone( done );
    
        if( done == true )
            mNowPlaying->play();
    
        MoviesTask( nil, 0 );
    }
    
    return noErr;
}



/*------------------------------------------------------------------
    ボリューム関連
------------------------------------------------------------------*/
OSErr CD::setVolume( int Volume )
{
    return noErr;
}

OSErr CD::getVolume( int &Volume )
{
    return noErr;
}




/*------------------------------------------------------------------
    FSSpecを受け取って、soundFileを作り、mapに追加
------------------------------------------------------------------*/

void CD::add( int trackNum, FSSpec spec )
{
    soundFile	*sound;
    
    sound = new soundFile( &spec );

    mTrackMap.insert(pair<int, soundFile *>(trackNum, sound));
}



/*------------------------------------------------------------------
    状況に応じたCDクラスを返す
------------------------------------------------------------------*/

CD *CD::create()
{
/*
    OSErr 	result = noErr;
    long	systemVersion;
    
    if(Gestalt(gestaltSystemVersion, &systemVersion) != noErr)
        systemVersion = 0;

    for( ItemCount volumeIndex = 1; result == noErr || result != nsvErr; volumeIndex++ )
    {
        FSVolumeRefNum	actualVolume;
        HFSUniStr255	volumeName;
        FSVolumeInfo	volumeInfo;

        bzero((void *) &volumeInfo, sizeof(volumeInfo));

        result = FSGetVolumeInfo(kFSInvalidVolumeRefNum,
                                 volumeIndex,
                                 &actualVolume,
                                 kFSVolInfoFSInfo,
                                 &volumeInfo,
                                 &volumeName,
                                 NULL); 
         
        if (result == noErr)
        {
            // OS X 10.0ではバグがあるので駄目。
            // OS X 10.1以降で使用可能。
            if ((systemVersion >= 0x00001000 && systemVersion < 0x00001010 &&
                    volumeInfo.signature == kAudioCDFilesystemID) ||
                    volumeInfo.filesystemID == kAudioCDFilesystemID)
            {
                // AudioCDがマウントされていたらCDから再生
                return new CDAudio();
            }
        }
    }

*/    
    // だめだったらファイルから再生
    return new alternativeCDSound();
}







/*------------------------------------------------------------------
    コンストラクタ
    CDがマウントされているときに使われる
------------------------------------------------------------------*/

/*

CDAudio::CDAudio()
{
    OSErr 	result = noErr;
    long	systemVersion;

    for( ItemCount volumeIndex = 1; result == noErr || result != nsvErr; volumeIndex++ )
    {
        FSVolumeRefNum	actualVolume;
        HFSUniStr255	volumeName;
        FSVolumeInfo	volumeInfo;

        bzero((void *) &volumeInfo, sizeof(volumeInfo));

        result = FSGetVolumeInfo(kFSInvalidVolumeRefNum,
                                 volumeIndex,
                                 &actualVolume,
                                 kFSVolInfoFSInfo,
                                 &volumeInfo,
                                 &volumeName,
                                 NULL); 
         
        if (result == noErr)
        {
            // OS X 10.0ではバグがあるので駄目。
            // OS X 10.1以降で使用可能。
            if ((systemVersion >= 0x00001000 && systemVersion < 0x00001010 &&
                    volumeInfo.signature == kAudioCDFilesystemID) ||
                    volumeInfo.filesystemID == kAudioCDFilesystemID) // It's an audio CD
            {
                FSRefParam	fsRefPB;
                FSRef		tocPlistFSRef;
                HParamBlockRec 	pb;
                
                // get stuff from .TOC.plist                                                   
                fsRefPB.ioCompletion = NULL;
                fsRefPB.ioNamePtr = "\p.TOC.plist";
                fsRefPB.ioVRefNum = actualVolume;
                fsRefPB.ioDirID = 0;
                fsRefPB.newRef = &tocPlistFSRef;
                result = PBMakeFSRefSync(&fsRefPB);
                
                if (result != noErr)
                    printf("PBMakeFSRefSync returned %d\n", result);
                else
                    CheckTOCData(&tocPlistFSRef);

                pb.fileParam.ioNamePtr = NULL;		// specify volume by vrefnum
                pb.fileParam.ioVRefNum = actualVolume;
                PBFlushVolSync((ParamBlockRec *) &pb);	// ignore errors from flush
                
                pb.ioParam.ioNamePtr = NULL;
                pb.ioParam.ioVRefNum = actualVolume;
                result = PBUnmountVol((ParamBlockRec *) &pb);
                
                if (result != noErr)
                    printf("PBUnmountVol returned %d\n", result);
            }
        }
    }
}



void CDAudio::CheckTOCData(const FSRef *theFSRef)
{

    HFSUniStr255	dataForkName;
    OSErr		theErr;
    SInt16		forkRefNum;
    SInt64		forkSize;
    Ptr			forkData;
    ByteCount		actualRead;
    CFDataRef		dataRef = 0;
    CFPropertyListRef	propertyListRef = 0;

    theErr = FSGetDataForkName ( &dataForkName );
    if ( theErr != noErr )
    {
        printf ( "Error getting data fork name\n" );
        return;
    }
    
    theErr = FSOpenFork ( theFSRef, dataForkName.length, dataForkName.unicode, 
                            fsRdPerm, &forkRefNum );
    if ( theErr != noErr )
    {
        printf ( "Error opening data fork\n" );
        return;
    }
    
    theErr = FSGetForkSize ( forkRefNum, &forkSize );
    if ( theErr != noErr )
    {
        printf ( "Error %d getting fork size\n", theErr );
        return;
    }
    
    // Allocate some memory for the XML data
    forkData = NewPtr ( forkSize );
    if (forkData == NULL)
    {
        printf ( "Error allocating memory for XML data\n" );
        return;
    }
    
    theErr = FSReadFork ( forkRefNum, fsFromStart, 0, forkSize, forkData, &actualRead );
    if ( theErr != noErr )
    {
        printf ( "Error %d opening data fork\n", theErr );
        return;
    }
    
    dataRef = CFDataCreate ( kCFAllocatorDefault, (UInt8 *)forkData, forkSize );
    if ( dataRef != 0 )
    {
            
        CFStringRef	errorString;
        
        propertyListRef = CFPropertyListCreateFromXMLData ( kCFAllocatorDefault,
                                                            dataRef,
                                                            kCFPropertyListImmutable,
                                                            &errorString );

        if ( errorString != 0 )
                CFRelease ( errorString );
        
        // Now we got the Property List in memory. Parse it.
        
        // First, make sure the root item is a CFDictionary. If not, release and bail.
        if ( CFGetTypeID ( propertyListRef ) == CFDictionaryGetTypeID ( ) )
        {
            CFStringRef	RawTOCDataString = CFSTR( "Format 0x02 TOC Data" );
            CFStringRef	SessionsString = CFSTR( "Sessions" );


            
            CFDataRef	theRawTOCDataRef	= 0;
            CFArrayRef	theSessionArrayRef	= 0;
            CFIndex	numSessions		= 0;
            UInt32	index			= 0;
            
            // This is how we get the Raw TOC Data
            theRawTOCDataRef =
            ( CFDataRef )CFDictionaryGetValue( propertyListRef, RawTOCDataString );
            
            // Get the session array info.
            theSessionArrayRef =
            ( CFArrayRef )CFDictionaryGetValue( propertyListRef, SessionsString );
            
            // Find out how many sessions there are.
            numSessions = CFArrayGetCount ( theSessionArrayRef );
            
            printf ( "Number of sessions = %ld\n", ( UInt32 ) numSessions );

            printf ( "\n" );
            
            for ( index = 0; index < numSessions; index++ )
            {
                CFStringRef	FirstTrackInSessionString = CFSTR("First Track");
                CFStringRef	LastTrackInSessionString = CFSTR("Last Track");
                CFStringRef	LeadoutBlockString = CFSTR("Leadout Block");
                CFStringRef	SessionTypeString = CFSTR("Session Type");
                CFStringRef	SessionNumberKeyString = CFSTR("Session Number");
                CFStringRef	TrackArrayString = CFSTR("Track Array");

                    
                CFDictionaryRef	theSessionDict		= 0;
                CFNumberRef	firstTrackNumber	= 0;
                CFNumberRef	lastTrackNumber 	= 0;
                CFNumberRef	leadoutBlock		= 0;
                CFNumberRef	sessionNumber		= 0;
                CFNumberRef	sessionType		= 0;
                CFArrayRef	trackArray		= 0;
                CFIndex		numTracks		= 0;
                UInt32		trackIndex		= 0;
                UInt32		value			= 0;
                
                theSessionDict
                    = (CFDictionaryRef)CFArrayGetValueAtIndex( theSessionArrayRef, index );
                
                firstTrackNumber
                    =(CFNumberRef)CFDictionaryGetValue( theSessionDict, FirstTrackInSessionString);
                
                lastTrackNumber
                    = (CFNumberRef)CFDictionaryGetValue( theSessionDict, LastTrackInSessionString );

                leadoutBlock
                    =(CFNumberRef)CFDictionaryGetValue( theSessionDict, LeadoutBlockString );
                
                sessionType
                    =(CFNumberRef)CFDictionaryGetValue( theSessionDict, SessionTypeString );
                
                sessionNumber
                    =(CFNumberRef)CFDictionaryGetValue ( theSessionDict, SessionNumberKeyString );
                
                if ( CFNumberGetValue ( sessionNumber, kCFNumberSInt32Type, &value ) )
                {
                    printf ( "-----------------------------------\n" );
                    printf ( "Session Number %ld\n", value );
                    printf ( "-----------------------------------\n" );
                }
                
                if ( CFNumberGetValue ( firstTrackNumber, kCFNumberSInt32Type, &value ) )
                {
                    printf ( "First Track in session = %ld\n", value );
                }
                
                if ( CFNumberGetValue ( lastTrackNumber, kCFNumberSInt32Type, &value ) )
                {
                    printf ( "Last Track in session = %ld\n", value );
                }

                if ( CFNumberGetValue ( leadoutBlock, kCFNumberSInt32Type, &value ) )
                {
                    printf ( "Leadout block for session = %ld\n", value );
                }

                if ( CFNumberGetValue ( sessionType, kCFNumberSInt32Type, &value ) )
                {
                        
                    if ( value == 0 )
                    {
                        printf ( "Session Type is CD-DA or CD-ROM with first track in Mode 1\n" );
                    }
                    
                    else if ( value == 16 )
                    {
                        printf ( "Session Type is CD-I\n" );
                    }
                    
                    else if ( value == 32 )
                    {
                        printf ( "Session Type is CD-ROM XA with first track in Mode 2\n" );
                    }

                }
                
                trackArray
                    =(CFArrayRef)CFDictionaryGetValue( theSessionDict, TrackArrayString );
                
                numTracks = CFArrayGetCount ( trackArray );

                printf ( "\n" );
                
                for ( trackIndex = 0; trackIndex < numTracks; trackIndex++ )
                {
                    CFStringRef	PointKeyString = CFSTR("Point");
                    CFStringRef	SessionNumberKeyString = CFSTR("Session Number");
                    CFStringRef	StartBlockKeyString = CFSTR("Start Block");
                    CFStringRef	DataKeyString = CFSTR("Data");

                    
                    CFDictionaryRef	theTrackDict	= 0;
                    CFNumberRef		trackNumber	= 0;
                    CFNumberRef		sessionNumber 	= 0;
                    CFNumberRef		startBlock	= 0;
                    CFBooleanRef	isDataTrack	= kCFBooleanFalse;
                    UInt32		value		= 0;
                    
                    theTrackDict
                        = ( CFDictionaryRef ) CFArrayGetValueAtIndex ( trackArray, trackIndex );
                    
                    trackNumber
                        = ( CFNumberRef )  CFDictionaryGetValue ( theTrackDict, PointKeyString );
                    
                    sessionNumber 
                        = ( CFNumberRef )  CFDictionaryGetValue ( theTrackDict, SessionNumberKeyString );

                    startBlock
                        = ( CFNumberRef )  CFDictionaryGetValue ( theTrackDict, StartBlockKeyString );
                    
                    isDataTrack
                        = ( CFBooleanRef ) CFDictionaryGetValue ( theTrackDict, DataKeyString );
                                                            
                    if ( CFNumberGetValue ( trackNumber, kCFNumberSInt32Type, &value ) )
                    {
                        printf ( "Track Number = %ld\n", value );
                    }
                    
                    if ( CFNumberGetValue ( sessionNumber, kCFNumberSInt32Type, &value ) )
                    {
                        printf ( "It resides in session %ld\n", value );
                    }
                    
                    if ( CFNumberGetValue ( startBlock, kCFNumberSInt32Type, &value ) )
                    {
                        printf ( "Track starts at block = %ld\n", value );
                    }

                    if ( isDataTrack == kCFBooleanTrue )
                    {
                        printf ( "This is a DATA track\n" );
                    }
                    
                    else
                    {
                        printf ( "This is an AUDIO track\n" );
                    }

                    printf ( "\n" );
                                                            
                }
                                                
            }
        
        }

        CFRelease ( propertyListRef );
        
    }
    
    CFRelease ( dataRef );
    DisposePtr ( forkData );
    FSCloseFork ( forkRefNum );
}







*/



/*------------------------------------------------------------------
    AudioCDがマウントされていないときの
    代替音源クラスのコンストラクタ
------------------------------------------------------------------*/

alternativeCDSound::alternativeCDSound()
{
    // 親ディレクトリのIDを得る
    getParentDirID();

    // kMaxTrackNum(99)個
    for( int i = 1; i < kMaxTrackNum; i++ )
    {
        // 見つかった
        if( find( i ) == noErr )
            CD::add( i, mFSSpec );
    }
}


/*------------------------------------------------------------------
    デストラクタ
------------------------------------------------------------------*/

alternativeCDSound::~alternativeCDSound()
{

}



/*------------------------------------------------------------------
    トラックを探す
------------------------------------------------------------------*/

OSErr alternativeCDSound::find( int trackNum )
{
    /*!
        ありそうなファイル名
    */
    char fileNameCandidate[][255] = 
    {
        "%d",
        "%d.mp3",
        "%d.cdda",
        "%d.aif",
        "%d.aiff",
        "%d.wav",
        "%d.wave",

    	"Track %d",
        "Track %d.mp3",
    	"Track %d.cdda",
    	"Track %d.aif",
    	"Track %d.aiff",
    	"Track %d.wav",
    	"Track %d.wave",

        "%02d",
        "%02d.mp3",
        "%02d.cdda",
        "%02d.aif",
        "%02d.aiff",
        "%02d.wav",
        "%02d.wave",

    	"Track %02d",
    	"Track %02d.mp3",
    	"Track %02d.cdda",
    	"Track %02d.aif",
    	"Track %02d.aiff",
    	"Track %02d.wav",
    	"Track %02d.wave"
    };

    for( size_t i = 0; i < 7 * 4; i++ )
    {
        char	c_name[255];
        Str255	p_str;
        OSErr	err;

        // "Track 10.mp3"といったファイル名を次々作ってみる
        sprintf( c_name, fileNameCandidate[i], trackNum );
        CopyCToPascal( c_name, p_str );
        
        // 見つかったらreturn
        err = FSMakeFSSpec( 0, mParentDirID, p_str, &mFSSpec );
        if( err == noErr )
            return noErr;
    }
    
    // ここに来たということは見つからなかったので、なんらかのエラーを返す
    return 1;
}



/*------------------------------------------------------------------
    親のディレクトリIDを得る
------------------------------------------------------------------*/

void alternativeCDSound::getParentDirID()
{
    OSErr err;
    ProcessSerialNumber psn;
    FSCatalogInfo info;
    HFSUniStr255 name;

    mParentDirID = 0;

    err = GetCurrentProcess(&psn);
    if( err != noErr )
        return;

    FSRef location;

    err = GetProcessBundleLocation(&psn, &location);
    if( err != noErr )
        return;

    FSGetCatalogInfo( &location, kFSCatInfoParentDirID,
                             &info, &name, NULL, NULL);
    
    mParentDirID = info.parentDirID;
}


























/*------------------------------------------------------------------
    コンストラクタ
------------------------------------------------------------------*/

soundFile::soundFile( FSSpec *theSpec ) : mSound(NULL)
{
    OSErr err;
    short movieRefNum;
    short resID;
	
    mSound = NULL;

    if ( noErr == OpenMovieFile( theSpec, &movieRefNum, fsRdPerm ))
    {
        err = NewMovieFromFile(	&mSound,
                                movieRefNum,
                                &resID,
                                NULL,
                                newMovieActive,
                                NULL );
    }
         
    if (err)
    {
        if (mSound)
        {
            DisposeMovie(mSound);
            mSound = NULL;
        }
    }
    else
    {
        SetMovieVolume(mSound, kFullVolume);
        GoToBeginningOfMovie(mSound);
    }
}


/*------------------------------------------------------------------
    デストラクタ
------------------------------------------------------------------*/

soundFile::~soundFile()
{
    if( mSound != NULL )
    {
        DisposeMovie( mSound );
        mSound = NULL;
    }
}


/*------------------------------------------------------------------
    抱えているサウンドを再生する
------------------------------------------------------------------*/

OSErr soundFile::play()
{
    if( mSound != NULL )
    {
        GoToBeginningOfMovie( mSound );
        resume();
    }
    
    return noErr;
}


/*------------------------------------------------------------------
    止める
------------------------------------------------------------------*/

OSErr soundFile::stop()
{
    if( mSound != NULL )
    {
        pause();
        GoToBeginningOfMovie( mSound );
    }
    
    return noErr;
}


/*------------------------------------------------------------------
    一時停止
------------------------------------------------------------------*/

OSErr soundFile::pause()
{
    if( mSound != NULL )
        StopMovie( mSound );
    
    return noErr;
}


/*------------------------------------------------------------------
    止めていたのを再開
------------------------------------------------------------------*/

OSErr soundFile::resume()
{
    if( mSound != NULL )
        StartMovie( mSound );
    
    return noErr;
}


/*------------------------------------------------------------------
    終わっているか？
------------------------------------------------------------------*/

OSErr soundFile::isDone( bool &done )
{
    if( mSound != NULL )
        done = IsMovieDone( mSound );
    
    return noErr;
}
