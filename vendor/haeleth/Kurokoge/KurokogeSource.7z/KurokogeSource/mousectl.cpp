/*=======================================================================
  AVG32-like scriptor for Macintosh
  Copyright 2000, K.Takagi(Kenjo)

  mousectl.h
    �}�E�X�֘A

  �ύX����
      2002/01/14 : F.Shiraishi
					�}�E�X�J�[�\���̃��[�J�����W���擾���郋�[�`���� GetMouse() API ����
					SYSTEM::GetLocalMouse() �֐��ɕύX
=======================================================================*/

#include <stdio.h>
#include <string.h>
#include <time.h>

#include "common.h"
#include "debug.h"
#include "mousectl.h"
#include "system.h"


//#define MENUFLAG (((EnableFlag)&&(PopupFlag)&&(DrawFlag))?1:0)
//#define MENUFLAG (((EnableFlag)&&(PopupFlag))?1:0)
#define MENUFLAG (((EnableFlag)||(PopupFlag))?1:0)

AVG32MOUSE::AVG32MOUSE(SYSTEM* s)
{
	sys = s;
	Style = 0;
	PosX = -999;
	PosY = -999;
	EnableFlag = 0;
	PopupFlag = 0;
	MenuFlag = 1;
	DrawFlag = 1;
	ClickFlag = -1;
	RightClick = 0;
}


AVG32MOUSE::~AVG32MOUSE(void)
{
}


void AVG32MOUSE::Show(void)
{
	int oldflag;
	if ( !DrawFlag ) {
		DrawCursor();
		oldflag = MenuFlag;
		DrawFlag = 1;
		MenuFlag = MENUFLAG;
		if ( oldflag!=MenuFlag ) {
			sys->PopupMenuEnable(MenuFlag);
		}
	}
}


void AVG32MOUSE::Hide(void)
{
	int oldflag;
	if ( DrawFlag ) {
		HideCursor();
		oldflag = MenuFlag;
		DrawFlag = 0;
		MenuFlag = MENUFLAG;
		if ( oldflag!=MenuFlag ) {
			sys->PopupMenuEnable(MenuFlag);
		}
	}
}


void AVG32MOUSE::StartPDTDraw(void)
{
	int oldflag = MenuFlag;
	EnableFlag = 0;
	MenuFlag = MENUFLAG;
	if ( oldflag!=MenuFlag ) {
		sys->PopupMenuEnable(MenuFlag);
	}
}


void AVG32MOUSE::FinishPDTDraw(void)
{
//	int oldflag = MenuFlag;
//	EnableFlag = 1;
//	MenuFlag = MENUFLAG;
//	if ( oldflag!=MenuFlag ) {
//		sys->PopupMenuEnable(MenuFlag);
//	}
}


void AVG32MOUSE::EnablePopup(void)
{
//	int oldflag = MenuFlag;
//	PopupFlag = 1;
//	MenuFlag = MENUFLAG;
//	if ( oldflag!=MenuFlag ) {
//		sys->PopupMenuEnable(MenuFlag);
//	}
}


void AVG32MOUSE::TextIconStart(void)
{
	int oldflag = MenuFlag;
	EnableFlag = 1;
	MenuFlag = MENUFLAG;
	if ( oldflag!=MenuFlag ) {
		sys->PopupMenuEnable(MenuFlag);
	}
}


void AVG32MOUSE::TextIconEnd(void)
{
	int oldflag = MenuFlag;
	EnableFlag = 0;
	MenuFlag = MENUFLAG;
	if ( oldflag!=MenuFlag ) {
		sys->PopupMenuEnable(MenuFlag);
	}
}


void AVG32MOUSE::DisablePopup(void)
{
	int oldflag = MenuFlag;
	PopupFlag = 0;
	MenuFlag = MENUFLAG;
	if ( oldflag!=MenuFlag ) {
		sys->PopupMenuEnable(MenuFlag);
	}
}


int AVG32MOUSE::GetPopupFlag(void)
{
	return (PopupFlag^1);
}


void AVG32MOUSE::SetStyle(int n)
{
	Style = n;
	if ( DrawFlag ) {
		HideCursor();
		DrawCursor();
	}
}


void AVG32MOUSE::Move(int x, int y)
{
	if ( (x<0)||(x>639) ) x = -999;
	if ( (y<0)||(y>479) ) y = -999;
	if ( (PosX!=x)||(PosY!=y) ) {
		if ( DrawFlag ) {
			HideCursor();
		}
		PosX = x;
		PosY = y;
		if ( DrawFlag ) {
			DrawCursor();
		}
//		if ( y<8 ) sys->MenuON(); else sys->MenuOFF();
	}
}


void AVG32MOUSE::GetPos(int* x, int* y)
{
	*x = PosX;
	*y = PosY;
}


void AVG32MOUSE::ButtonDown(void)
{
    KeyMap		theKey;
    // bit6:RCtrl, bit3:LCtrl
    // Ctrl�L�[�����ŉE�N���b�N�iMac�W���j
    GetKeys( theKey );
    if((theKey[1] & 0x08) != 0 )
        RightClick = 1;
}


void AVG32MOUSE::ButtonUp(void)
{
	ClickTime = sys->GetCurrentTimer();
	if ( RightClick ) {
		if ( MenuFlag ) {				// �R���e�L�X�g���j���[��Enable�Ȃ�\��
			sys->PopupContextMenu();
		} else {						// �����łȂ���΁A�P�ɉE�N���b�N�Ƃ��ď��𑗂�
			ClickFlag = 1;
		}
	} else {
		ClickFlag = 0;
	}
	RightClick = 0;
}


void AVG32MOUSE::ClickFlush(void)
{
	ClickFlag = -1;
}


void AVG32MOUSE::GetState(int* x, int* y, int* flag)
{
	Point		pt;
	int			t;

	sys->GetLocalMouse(&pt);
	if(sys->IsActive())
	{
		*x = pt.h;
		*y = pt.v;
		// Flush�����܂ł͑O�̃f�[�^���ǂ߂�̂��ȁH
		t = sys->GetCurrentTimer()-ClickTime;
		if((t<0) || (t>200))
			ClickFlag = -1;		// �ꉞ���Ԑ����������Ă������E�E�E
	}
	else
	{
		*x = 0;
		*x = 0;
		ClickFlag = -1;
	}
	*flag = ClickFlag;
}


int AVG32MOUSE::GetButton(void)
{
	int ret = 0;
	int t = sys->GetCurrentTimer()-ClickTime;
	if ( (t>=0)&&(t<200)&&(!ClickFlag) ) ret = 1;
	ClickFlag = -1;
	return ret;
}



void AVG32MOUSE::DrawCursor(void)
{
}


void AVG32MOUSE::HideCursor(void)
{
}
