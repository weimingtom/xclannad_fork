/*
 *  CD.h
 *  CD
 *
 *  Created by keta on Thu Jan 16 2003.
 *  Copyright (c) 2003 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef CDAUDIO
#define CDAUDIO


#include <Carbon/Carbon.h>
#include <QuickTime/QuickTime.h>

#include <map>

using namespace std;


const int kMaxTrackNum = 99;


class soundFile
{
    public:
                soundFile( FSSpec * );
        virtual	~soundFile();

        OSErr	play();
        OSErr	stop();
        OSErr	pause();
        OSErr	resume();
        OSErr	isDone( bool & );
    
    private:
        Movie	mSound;
};




class CD
{
    public:
        virtual ~CD();

        virtual OSErr	play( int track );
        virtual OSErr	play();
        virtual OSErr	stop();
        virtual OSErr	pause();
        virtual OSErr	resume();
        virtual OSErr	task();
        
        virtual OSErr	setVolume( int volume );
        virtual OSErr	getVolume( int &volume );
        
        static CD	*create();

    protected:
                CD();
        void	add( int, FSSpec );

    private:
        
        map<int, soundFile *>	mTrackMap;
        soundFile		*mNowPlaying;
        
};



const UInt16 kAudioCDFilesystemID = (UInt16)(('J' << 8) | 'H' );

/*
#define kRawTOCDataString			"Format 0x02 TOC Data"
#define kSessionsString				"Sessions"
#define kSessionTypeString			"Session Type"
#define kTrackArrayString			"Track Array"
#define kFirstTrackInSessionString		"First Track"
#define kLastTrackInSessionString		"Last Track"
#define kLeadoutBlockString			"Leadout Block"
#define	kDataKeyString 				"Data"
#define kPointKeyString				"Point"
#define kSessionNumberKeyString			"Session Number"
#define kStartBlockKeyString		 	"Start Block"
*/


class CDAudio : public CD
{
    public:
                CDAudio();
        virtual	~CDAudio();
    
    private:
        void	CheckTOCData( const FSRef * );
};



class alternativeCDSound : public CD
{
    public:
                alternativeCDSound();
        virtual	~alternativeCDSound();
    
    private:
    
        OSErr	find( int trackNum );
        void	getParentDirID();
        
        FSSpec	mFSSpec;
        UInt32	mParentDirID;
};


class nullCDSound : public CD
{
    public:
                nullCDSound();
        virtual	~nullCDSound();

        virtual OSErr	play( int track ){ return noErr; };
        virtual OSErr	play(){ return noErr; };
        virtual OSErr	stop(){ return noErr; };
        virtual OSErr	pause(){ return noErr; };
        virtual OSErr	resume(){ return noErr; };
        virtual OSErr	task(){ return noErr; };
        
        virtual OSErr	setVolume( int volume ){ return noErr; };
        virtual OSErr	getVolume( int &volume ){ return noErr; };
};


#endif