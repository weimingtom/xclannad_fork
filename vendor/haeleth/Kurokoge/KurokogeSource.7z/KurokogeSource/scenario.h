/*=======================================================================
  AVG32-like scriptor for Macintosh
  Copyright 2000, K.Takagi(Kenjo)

  scenario.h
    �V�i���I�Ǘ��E�f�R�[�h�N���X
=======================================================================*/

#ifndef _scenario_h
#define _scenario_h

#include "system.h"
#include "flags.h"

class PDTBUFFER;
class SOUND;
class AVG32MOUSE;


class SCENARIO
{
private:
	SYSTEM* sys;
	FLAGS* flags;
	SOUND* sound;
	AVG32MOUSE* mouse;

	bool d00(void), d01(void), d02(void), d03(void), d04(void), d05(void), d06(void), d07(void);
	bool d08(void), d09(void), d0a(void), d0b(void), d0c(void), d0d(void), d0e(void), d0f(void);
	bool d10(void), d11(void), d12(void), d13(void), d14(void), d15(void), d16(void), d17(void);
	bool d18(void), d19(void), d1a(void), d1b(void), d1c(void), d1d(void), d1e(void), d1f(void);
	bool d20(void), d21(void), d22(void), d23(void), d24(void), d25(void), d26(void), d27(void);
	bool d28(void), d29(void), d2a(void), d2b(void), d2c(void), d2d(void), d2e(void), d2f(void);
	bool d30(void), d31(void), d32(void), d33(void), d34(void), d35(void), d36(void), d37(void);

	int seennum;
	int curpos;

	int lastsaveseen;
	int lastsavepos;

	unsigned char* databuf;
	unsigned char* databuf_base;
	int bufsize;
	unsigned char cmd;
	unsigned int waitbase;
	unsigned int waittime;
	unsigned int waitcancelindex;
	unsigned int waitcmd;

	unsigned int fadecmd;
	unsigned int fadecount;
	unsigned int fadestep;
	unsigned int fadeprevtime;

	unsigned int flashbase;
	unsigned int flashtime;
	unsigned int flashr;
	unsigned int flashg;
	unsigned int flashb;
	unsigned int flashcount;

	int automodecount;

	int mesflag;
	unsigned int meswaitbase;

	unsigned char* areabuf;
	unsigned char areaflag[256];

	int areax, areay;

	int fader, fadeg, fadeb;

	int selectflag;
	int selectindex;

	bool shakeflag;

	bool anmflag;
	int multianmflag;

	bool loading;

	int koetextskip;
	int soundwait;

	struct ENDING {
		bool flag;
		unsigned char cmd;
		unsigned char poscmd;
		int num;
		int pos;
		int wait;
		int pixel;
		int line;
		int totalline;
		int curtime;
		int pdtx[256];
		int pdty[256];
		int pdtpos[256];
		PDTBUFFER* pdt[256];
		char file[256][16];
	} ending;
	
	EFFECT effect;

	struct SCNMENUS {
		int start;
		int loopback;
		unsigned char num;
		unsigned char subnum[8];
		unsigned char strid[8];
		unsigned char id[8];
		unsigned char subcountmax[8][8];
		unsigned char subcount[8][8];
		unsigned char substrid[8][8];
		unsigned char subid[8][8];
		unsigned char flag[8][8][8];
		int substart[8][8][8];
		unsigned char* str[72];
		int cur;
		int cursub;
		int cursubsub;
		unsigned char bit;
		unsigned char bitcount;
		unsigned char subbit;
		unsigned char subbitcount;
//		unsigned char subbit[8];
//		unsigned char subbitcount[8];
	} smenu;
	
	int jumpbase;

	void MakeTable(void);

	int ReadInt(void);
	int ReadInt(int);
	int ReadValue(void);
	void ReadText(char* buf);
	int ReadFormattedText(char* buf, int* attr);

	bool Decode(void);

/*
	void DecodeValueHandling(void);
	void DecodeStringHandling(void);
	void DecodeTextHandling(void);
	void DecodeGraphicsHandling(void);
	void DecodeGraphicsLoadHandling(void);
	void DecodeJumpHandling(void);
	void DecodeWaitHandling(void);
	void DecodeAnimationHandling(void);
	void DecodeMusicHandling(void);
*/
	void DecodeEndingHandling(void);
	int DecodeConditions(void);
	int DecodeAutoCGMode(void);
	void Han2Zen(char* buf);

	void Area_Read(char* f);
	int Area_Find(int x, int y);
	void Area_Enable(int n);
	void Area_Disable(int n);
	void Area_Clear(void);
	
	void PrintMessage(void);
	
	void SavePoint(void);
	void ReadHeader(void);
	void ScnMenuSel(void);
	int ChangeSeen(int seen);
public:
	SCENARIO(SYSTEM* s, FLAGS* f, SOUND* snd, AVG32MOUSE* m);
	~SCENARIO(void);

	void Reset(int seen, int pos);
	void Run(void);
	
	void SetPos(int pos) { curpos = pos; };
	
	int GetSavePos(void) { return lastsavepos; };
	int GetSaveSeen(void) { return lastsaveseen; };
};

#endif
