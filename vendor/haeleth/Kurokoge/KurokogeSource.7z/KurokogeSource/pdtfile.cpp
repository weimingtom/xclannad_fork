/*=======================================================================
  AVG32-like scriptor for Macintosh
  Copyright 2000, K.Takagi(Kenjo)

  pdtfile.cpp
    PDT�t�@�C���ւ̃A�N�Z�X
=======================================================================*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "pdtfile.h"
#include "pdtbuf.h"
#include "common.h"
#include "debug.h"
#include "system.h"

/************************************************************************
  �}�N���݂����Ȃ�
************************************************************************/
inline int ReadInt(unsigned char* b, int pos)
{
	int ret;
	ret  =  b[pos];
	ret += (b[pos+1]<<8);
	ret += (b[pos+2]<<16);
	ret += (b[pos+3]<<24);
	return ret;
};

inline bool CheckHeader(unsigned char* b, char* header)
{
	int i = 0;
	while(header[i]) {
		if ( (char)(b[i]) != header[i] ) return false;
		i++;
	}
	return true;
};


/************************************************************************
  class PDTFILE
    �摜�t�@�C��. ���k����Ă��
************************************************************************/

PDTFILE::PDTFILE(char* fname, SYSTEM* sys)
{
	int num, srccount, i, bit, count, maskptr, n;
	unsigned char *repeat, *buf, *bufend, *src;
	unsigned char *srcbuf;
	unsigned char flag;
	int index[16];
	char f[256];

	for (i=0; fname[i]; i++) {
		if ( (fname[i]>='a')&&(fname[i]<='z') ) fname[i]-=0x20;
	}
	mask = NULL;
	buffer = NULL;
	srcbuf = 0;

	sprintf(f, "%s.PDT", fname);
	srcbuf = sys->ReadFile(f, "PDT", &filesize);
	if ( srcbuf ) {

		if ( CheckHeader(srcbuf, "PDT1\0") ) {
			xsize   = ReadInt(srcbuf, 12);
			ysize   = ReadInt(srcbuf, 16);
			size    = xsize * ysize;
			maskptr = ReadInt(srcbuf, 28);

		} else {
			delete[] srcbuf;
			srcbuf = 0;
		}
	}

	if ( srcbuf ) {
		if ( maskptr ) {	// Mask������ꍇ
			mask = new unsigned char[size];
			memset(mask, 0, size);
			src = srcbuf+maskptr;
			bit = 0;
			srccount = filesize-maskptr;
			bufend = mask+size;
			buf = mask;
			while ( (buf<bufend)&&(srccount>0) ) {
				if (!bit) {
					bit = 8;
					flag = *src++;
					srccount--;
				}
				if ( flag&0x80 ) {
					*buf++ = *src++;
					srccount--;
				} else {
					count = (*src++)+2;
					repeat = buf-((*src++)+1);
					srccount -= 2;
					for (i=0; (i<count)&&(buf<bufend); i++) *buf++ = *repeat++;
				}
				bit--;
				flag <<= 1;
			}
		}

		size *= 3;	// RGB�e1�o�C�g
		buffer = new unsigned char[size];

		if ( !strcmp((char*)srcbuf, "PDT10") ) {
		// PDT10�`��
			src = srcbuf+32;
			bit = 0;
			if ( maskptr )
				srccount = maskptr-32;
			else
				srccount = filesize-32;
			bufend = buffer+size;
			buf = buffer;
			while ( (buf<bufend)&&(srccount>0) ) {
				if (!bit) {
					bit = 8;
					flag = *src++;
					srccount--;
				}
				if ( flag&0x80 ) {
					*buf++ = *src++;
					*buf++ = *src++;
					*buf++ = *src++;
					srccount -= 3;
				} else {
					num  = *src++;
					num += ((*src++)<<8);			// �����̓��g���G���f�B�A����WORD
					srccount -= 2;
					count = ((num&15)+1)*3;			// ����4bit���R�s�[��. 2�񂪍ŏ��P�ʁH
					repeat = buf-((num>>4)+1)*3;	// buf�͎��̏������݈ʒu���w���Ă�̂ŁA1�o�C�g���߂ɖ߂�
					for (i=0; (i<count)&&(buf<bufend); i++) *buf++ = *repeat++;
				}
				bit--;
				flag <<= 1;
			}

		} else {
		// PDT11
			for (i=0; i<16; i++) {					// ���s�[�g����IndexTable
				index[i]  = (srcbuf[i*4+0x420]);
				index[i] |= (srcbuf[i*4+0x421]<<8);
				index[i] |= (srcbuf[i*4+0x422]<<16);
				index[i] |= (srcbuf[i*4+0x423]<<24);
			}
			src = srcbuf+0x460;
			bit = 0;
			if ( maskptr )
				srccount = maskptr-32;
			else
				srccount = filesize-32;
			bufend = buffer+size;
			buf = buffer;
			while ( (buf<bufend)&&(srccount>0) ) {
				if (!bit) {
					bit = 8;
					flag = *src++;
					srccount--;
				}
				if ( flag&0x80 ) {
					n = (*src++)*4+0x20;
					*buf++ = srcbuf[n];
					*buf++ = srcbuf[n+1];
					*buf++ = srcbuf[n+2];
					srccount--;
				} else {
					num  = *src++;					// ������BYTE
					srccount--;
					count = (((num>>4)&15)+2)*3;	// ���4bit���R�s�[��. 2�񂪍ŏ��P�ʁH
					if ( (buf+count)>=bufend ) count = bufend-buf;
					repeat = buf-(index[num&15])*3;	// Index�Ŗ߂�ʒu�����߂�H
					for (i=0; (i<count)&&(buf<bufend); i++) *buf++ = *repeat++;
				}
				bit--;
				flag <<= 1;
			}
		}

		delete[] srcbuf;
//		free(srcbuf);
	}
};

PDTFILE::~PDTFILE(void)
{
	delete[] buffer;
	delete[] mask;
};

void PDTFILE::CopyBuffer(PDTBUFFER* pdt)
{
	unsigned char *dst, *src, *srcbuf, *dstbuf, *msk1, *msk2;
	int dstx, dsty, bpl, bpp, x, y;
	int xx, yy;

	if ( !buffer ) return;

	dstx = pdt->GetSizeX();
	dsty = pdt->GetSizeY();
	bpl = pdt->GetBPL();
	bpp = pdt->GetBPP();
	dstbuf = pdt->GetBuffer();
	if ( bpp==4 ) dstbuf++;
	srcbuf = buffer;
	msk1 = pdt->GetMaskBuffer();
	msk2 = mask;

	xx = ((xsize<dstx)?xsize:dstx);
	yy = ((ysize<dsty)?ysize:dsty);

	for(y=0; y<yy; y++) {
		src = srcbuf;
		dst = dstbuf;
		for (x=0; x<xx; x++) {
			dst[0] = src[2];
			dst[1] = src[1];
			dst[2] = src[0];
			dst += bpp;
			src += 3;
		}
		srcbuf += xsize*3;
		dstbuf += bpl;
	}
	if ( xx>0 ) {
		if (mask) {
			for(y=0; y<yy; y++) {
				memcpy(msk1, msk2, xx);
				msk1 += dstx;
				msk2 += xsize;
			}
		} else {
			for(y=0; y<yy; y++) {
				memset(msk1, 255, xx);
				msk1 += dstx;
			}
		}
	}
};
