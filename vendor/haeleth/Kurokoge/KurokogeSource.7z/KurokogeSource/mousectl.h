/*=======================================================================
  AVG32-like scriptor for Macintosh
  Copyright 2000, K.Takagi(Kenjo)

  mousectl.h
    �}�E�X�֘A
=======================================================================*/

#ifndef _avg32mouse_h
#define _avg32mouse_h

class SYSTEM;

class AVG32MOUSE {
private:
	SYSTEM* sys;

	int Style;
	int PosX;
	int PosY;
	int EnableFlag;
	int PopupFlag;
	int DrawFlag;
	int MenuFlag;
	int ClickFlag;
	int RightClick;
	unsigned int ClickTime;

	void DrawCursor(void);
	void HideCursor(void);

public:
	AVG32MOUSE(SYSTEM* s);
	~AVG32MOUSE(void);

	void Show(void);
	void Hide(void);
	void StartPDTDraw(void);
	void FinishPDTDraw(void);
	void TextIconStart(void);
	void TextIconEnd(void);
	void EnablePopup(void);
	void DisablePopup(void);
	int GetPopupFlag(void);
	void SetStyle(int n);

	void Move(int x, int y);
	void GetPos(int* x, int* y);

	void ButtonDown(void);
	void ButtonUp(void);
	void ClickFlush(void);

	void GetState(int* x, int* y, int* flag);
	int GetButton(void);
};

#endif
