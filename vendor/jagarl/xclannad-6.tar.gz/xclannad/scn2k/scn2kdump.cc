/*
 *
 *  Copyright (C) 2002-   Kazunori Ueno(JAGARL) <jagarl@creator.club.ne.jp>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
*/

#include<stdlib.h>
#include<stdarg.h>
#include<stdio.h>
#include<string.h>
#include<string>
#include<vector>

using namespace std;

#include"system/file.h"
#include"system/file_impl.h"

/* �������� @@@ ��ɽ�� */

struct VarInfo {
#define TYPE_VARSTR 18
#define TYPE_STR 58
#define TYPE_VAL 68
#define TYPE_SYS 0xc8
	int type;
	int number;
	int value;
	VarInfo() { type = TYPE_VAL; value = 0;}
	VarInfo(int n) { type = TYPE_VAL; value = n;}
	VarInfo(const VarInfo& i) { type = i.type; number = i.number; value = i.value;}
};
class Flags {
/* flag: type 0-6 : ��������2000��
**	type 18: ʸ����2000��
**	type 25: �����ƥ��ѿ��ʥޥ�����ɸ�ʤɡ��� 1000 �ġ�
**	type 29: LO �ǡ���������Ƥ���ʡ���
**		284 :  0x23 - cmd 01-0b:0001:00[ 2] args:V<0>[0],V<0>[1999]
**		317 :  0x23 - cmd 01-0b:0001:00[ 2] args:V<27>[0],V<27>[63999]
**		350 :  0x23 - cmd 01-0b:0001:00[ 2] args:V<2>[0],V<2>[1999]
**		383 :  0x23 - cmd 01-0a:0001:01[ 2] args:V<18>[0],V<18>[1999]
**		̵�뤷�Ƥ褵����
*/
	typedef unsigned int uint;
	int sys;
	int var[7][2000];
	string str[2000];
public:
	int operator () () const;
	int operator () (VarInfo info) const;
	void Str(unsigned int number, char* buf, int sz) const;

	void Set(VarInfo info, int value);
	void SetSys(int value);
	void SetStr(unsigned int number, string val);
};

int Flags::operator()() const {
	return rand() % 10000;
}
int Flags::operator() (VarInfo info) const {
	if (uint(info.type) > 6 || uint(info.number) >= 2000) return 0;
	return var[info.type][info.number];
}
void Flags::Set(VarInfo info, int value) {
	if (uint(info.type) > 6 || uint(info.number) >= 2000) return;
	var[info.type][info.number] = value;
}
void Flags::SetSys(int value) {
	sys = value;
}
void Flags::SetStr(unsigned int number, string val) {
	if (number >= 2000) return;
	str[number] = val;
}
void Flags::Str(unsigned int number, char* buf, int sz) const {
	if (number >= 20000) {if(sz>0) buf[0] = 0; return;}
	const string& s = str[number];
	int len = s.length();
	if (sz-1 > len) sz = len;
	s.copy(buf, sz, 0);
	buf[sz] = 0;
	return;
}

/* commands */
enum Cmdtype { CMD_FLAGS, CMD_JMP, CMD_TEXT, CMD_OTHER};
class Cmd {
	Cmdtype cmd_type;
	int cmd1, cmd2, cmd3, cmd4;
	int argc;
	bool errorflag;
	char cmdstr[1024];
	const Flags& flags;
	vector<VarInfo> args;

	int GetArgs(const char*& d);
	int GetArgsSpecial(int normal_args,const char*& d);
	void GetSelection(const char*& d);
	int GetSwitch(const char*& d);
	int GetSimpleSwitch(const char*& d);
	int GetExpression(const char*& d, struct VarInfo* info = 0);
	int GetExpressionCond(const char*& d);
	int GetLeftToken(const char*& d, struct VarInfo& info);
	static int GetString(const char*& d);
	int StrVar(int number);
	static char strtype[256];
	static int StrType(const char* d) { return strtype[*(unsigned const char*)d];}
#define STRHEAP_SIZE 10000
	static char strheap[STRHEAP_SIZE];
	static int strend;
	void SetError(void) { errorflag = true;}
	static void ResetString(void) {
		strend = 0;
	}
public:
	void GetCmd(Flags& f, const char*& d);
	bool IsError() { return errorflag;}
	bool ClearError() { errorflag = false;}
	Cmd(const Flags& f) : flags(f) { argc = 0; errorflag = false; cmdstr[0] = 0;}

};

bool debug_flag = false;
void dprintf(const char* fmt, ...) {
	if (debug_flag) {
		va_list ap; va_start(ap, fmt);
		vprintf(fmt, ap);
		va_end(ap);
	}
}


#define SCN_DUMP

int system_version = 0;
bool ruby_flag = false;
bool ret_flag = false;
bool text_flag = false;
bool selection_flag = false;
char Cmd::strheap[STRHEAP_SIZE];
int Cmd::strend = 0;

/* ���� num := 0x24 0xff <int num> */
/* �ѿ� var := 0x24 <uchar type> 0x5b <exp> 0x5d */
/* �� token := num | var | 0x28 <exp> 0x29 | <plus|minus> token */

int Cmd::GetLeftToken(const char*& d, VarInfo& info) {
	bool var_flag = true;
	int minus_flag = 0;
	int value = 0;
	if (d[0] == 0x5c && (d[1] == 1 || d[1] == 0) ) {
		if (d[1] == 1)	{dprintf("minus-"); minus_flag ^= 1;}
		else dprintf("plus-");
		d += 2;
		var_flag = false;
	}
	if (d[0] == 0x24 && ((unsigned const char*)d)[1] == 0xff) {
	// if ( (d[0] == 0x30 || d[0] == 0x31) && d[1] == 0x24 && ((unsigned const char*)d)[2] == 0xff) 	/* @@@ not supported; selection ��ǡ�0x30|0x31 ���տ魯�뤳�Ȥ����� */
		// numerical atom
		d += 6;
		value = read_little_endian_int(d-4);
		dprintf("%d",value);
		var_flag = false;
	} else if (d[0] == 0x24 && *(unsigned char*)(d+1) == 0xc8) {
		dprintf("V<sys>");
		d += 2;
		info.type = TYPE_SYS; info.number = 0;
		value = info.value =  flags();
	} else if (d[0] == 0x24 && d[2] == 0x5b) {
		// 0x24,<type>,0x5b,<expr>,0x5d-terminated term
		info.type = *(unsigned char*)(d+1);
		d += 3;
		dprintf("V<%d>[",info.type);
		info.number = GetExpression(d);
		dprintf("]");
		if (*d == 0x5d) d++;
		else SetError();
		if (info.type == TYPE_VARSTR) {
			value = 0;
			info.value = StrVar(info.number);
		} else {
			value = info.value = flags(info);
		}
		dprintf("(=%d)",value);
	} else SetError();

	if (minus_flag) value = -value;
	if (!var_flag) {
		info.type = TYPE_VAL;
		info.value = value;
	}
	return value;
}

static char* op_str[70] = {
//	 0      1      2      3      4      5      6      7      8     9
	"+",   "-",   "*",   "/",   "%",   "&",   "|",   "^",   "<<",  ">>",	// +00
	"err.","err.","err.","err.","err.","err.","err.","err.","err.","err.",	// +10
	"+=",  "-=",  "*=",  "/=",  "%=",  "&=",  "|=",  "^=",  "<<=", ">>=",	// +20
	"=",   "err.","err.","err.","err.","err.","err.","err.","err.","err.",	// +30
	"==",  "!=",  "<=",  "<",   ">=",  ">",   "err.","err.","err.","err.",	// +40
	"err.","err.","err.","err.","err.","err.","err.","err.","err.","err.",	// +50
	"&&",  "||",  "err.","err.","err.","err.","err.","err.","err.","err.",	// +60
};

static int op_pri_tbl[12] = {
//	+  -  *  /  %  &  |  ^ << >>
	1, 1, 0, 0, 0, 3, 5, 4, 2, 2, 10, 10};

inline int op_pri(int op) {
	if (op > 11) return 10;
	return op_pri_tbl[op];
}
inline int op_pri_cond(int op) {
	if (op <= 11) return op_pri_tbl[op];
	else if (op < 50) return 7;
	else if (op == 60) return 8;
	else if (op == 61) return 9;
	else return 10;
}


inline int eval(int v1, int op, int v2) {
	switch(op) {
		case 0: return v1+v2;
		case 1: return v1-v2;
		case 2: return v1*v2;
		case 3: return v2!=0 ? v1/v2 : v1;
		case 4: return v2!=0 ? v1%v2 : v1;
		case 5: return v1&v2;
		case 6: return v1|v2;
		case 7: return v1^v2;
		case 8: return v1<<v2;
		case 9: return v1>>v2;
		case 40: return v1 == v2;
		case 41: return v1 != v2;
		case 42: return v1 <= v2;
		case 43: return v1 <  v2;
		case 44: return v1 >= v2;
		case 45: return v1 >  v2;
		case 60: return v1 && v2;
		case 61: return v1 || v2;
	}
	return v2;
}

/* �黻�� op := 0x5c <uchar op> */
/* ���� exp: [op] <token> [op <token> [...]] */
int Cmd::GetExpression(const char*& d, VarInfo* info_ptr) {
#define STACK_DEPTH 1024
#define OP_LB 11
	char op_stack[STACK_DEPTH];
	int val_stack[STACK_DEPTH];
	int stack_count = 0;
	
	// ������ɤ߹���
	while(*d == 0x28) {
		d++;
		dprintf("(");
		op_stack[stack_count++] = OP_LB;
	}
	VarInfo info;
	int value = GetLeftToken(d, info);
	
	while(*d == 0x29 && stack_count > 0 && op_stack[stack_count-1] == OP_LB) {
		d++;
		dprintf(")");
		stack_count--;
	}
	
	if (*d != 0x5c && stack_count == 0) {
		if (info_ptr) *info_ptr = info;
		return value; // ñ���left-term�Ϥ����ǽ�λ��ͭ����info_ptr�򵢤��ʲ�ǽ���������
	}
	
	while(*d == 0x5c) {
		int op_type = *(unsigned char*)(d+1);
		d += 2;
		if (op_type < 70) dprintf("%s",op_str[op_type]);
		else dprintf("err.");
		if (op_type >= 10) SetError();
		int cur_pri = op_pri(op_type);
		while(stack_count != 0 && op_pri(op_stack[stack_count-1]) <= cur_pri) {
			// ͥ���̤ι⤤����Ԥ���黻��Ԥ�
			value = eval(val_stack[stack_count-1], op_stack[stack_count-1], value);
			stack_count--;
		}
		val_stack[stack_count] = value;
		op_stack[stack_count++] = op_type;
		while(*d == 0x28) {
			d++;
			dprintf("(");
			op_stack[stack_count++] = OP_LB;
		}
		if (stack_count >= STACK_DEPTH) SetError();
		value = GetLeftToken(d, info);

		while (*d != 0x5c && stack_count > 0) {
			// ̤�¹Ԥα黻�򽪤�餻��
			if (op_stack[stack_count-1] != OP_LB) {
				value = eval(val_stack[stack_count-1], op_stack[stack_count-1], value);
				stack_count--;
			} else if (*d == 0x29) { /* op_stack == OP_LB */
			// bracket ��ü������С��Ĥ��Ƥ���
				d++;
				dprintf(")");
				stack_count--;
			} else break; // error
		}
	}
	if (stack_count) SetError(); // unbalanced bracket
	dprintf("(=%d)",value);
	if (info_ptr) {
		info_ptr->type = TYPE_VAL;
		info_ptr->value = value;
	}
	return value;
}

// ���ʬ�����Ѥˡ����黻�Ȼ��ѱ黻�κ�����ΤǤ������ѥ롼����������GetExpression�Ǻ����٤��ʤ�)
int Cmd::GetExpressionCond(const char*& d) {
	char op_stack[STACK_DEPTH];
	int val_stack[STACK_DEPTH];
	int valattr_stack[STACK_DEPTH];
#define ATTR_VAL 0
#define ATTR_FLAG 1
	int stack_count = 0;
	
	// ������ɤ߹���
	while(*d == 0x28) {
		d++;
		dprintf("(");
		op_stack[stack_count++] = OP_LB;
	}
	VarInfo info;
	int value = GetLeftToken(d, info);
	bool valattr = ATTR_VAL;
	
	while(*d == 0x5c) {
		int op_type = *(unsigned char*)(d+1);
		d += 2;
		if (op_type < 70) dprintf("%s",op_str[op_type]);
		else dprintf("err.");
		int cur_pri = op_pri_cond(op_type);
		while(stack_count != 0 && op_pri_cond(op_stack[stack_count-1]) <= cur_pri) {
			// ͥ���̤ι⤤����Ԥ���黻��Ԥ�
			if (op_stack[stack_count-1] >= 60) {
				if (valattr_stack[stack_count-1] != ATTR_FLAG || valattr != ATTR_FLAG) SetError();
			} else {
				if (valattr_stack[stack_count-1] != ATTR_VAL || valattr != ATTR_VAL) SetError();
			}
			value = eval(val_stack[stack_count-1], op_stack[stack_count-1], value);
			if (op_stack[stack_count-1] >= 40) valattr = ATTR_FLAG;
			stack_count--;
		}
		val_stack[stack_count] = value;
		valattr_stack[stack_count] = valattr;
		op_stack[stack_count++] = op_type;
		while(*d == 0x28) {
			d++;
			dprintf("(");
			op_stack[stack_count++] = OP_LB;
		}
		if (stack_count >= STACK_DEPTH) SetError();
		value = GetLeftToken(d, info);
		valattr = ATTR_VAL;

		while (*d != 0x5c && stack_count > 0) {
			// ̤�¹Ԥα黻�򽪤�餻��
			if (op_stack[stack_count-1] != OP_LB) {
				if (op_stack[stack_count-1] >= 60) {
					if (valattr_stack[stack_count-1] != ATTR_FLAG || valattr != ATTR_FLAG) SetError();
				} else {
					if (valattr_stack[stack_count-1] != ATTR_VAL || valattr != ATTR_VAL) SetError();
				}
				value = eval(val_stack[stack_count-1], op_stack[stack_count-1], value);
				if (op_stack[stack_count-1] >= 40) valattr = ATTR_FLAG;
				stack_count--;
			// bracket ��ü������С��Ĥ��Ƥ���
			} else if (*d == 0x29) { /* op_stack == OP_LB */
				d++;
				dprintf(")");
				stack_count--;
			} else break; // error
		}
	}
	if (stack_count) SetError(); // unbalanced bracket
	if (value) dprintf("(=true)");
	else dprintf("(=false)");
	return value;
}


/*
str = 
arg = 
args = 0x28 <exp> [[0x2c] <exp> [[0x2c] <exp> [...] ]]
*/

int Cmd::GetArgs(const char*& d) {
	if (*d != 0x28) return 0; /* �����ʤ� */
	d++;
	dprintf("args:");
	VarInfo var;
	int i; for (i=0; i<100 ; i++) {
		/* number, variable, string �μ��̤ʤ��ͤ����� */
		if (*d == 0x24 || (*d == 0x5c && (d[1] == 1 || d[1] == 0)) || *d == 0x28) {
			GetExpression(d, &var);
		} else if (StrType(d)) {
			var.type = TYPE_STR;
			var.value = GetString(d);
		} else SetError();
		args.push_back(var);
		if (*d == 0x29) break;
		if (*d == 0x2c) {d++;} // ���� arg ���黻�ҤǻϤޤ롢�ʤɤ��ʤ����¸�ߤ��ʤ�
		dprintf(",");
	}
	if (*d == 0x29) d++;
	else SetError();
	return i;
}

int Cmd::GetArgsSpecial(int normal_args,const char*& d) {
	if (*d != 0x28) return 0; /* �����ʤ� */
	d++;
	dprintf("args:");
	int i; for (i=0; i<normal_args; i++) {
		/* number, variable, string �μ��̤ʤ��ͤ����� */
		if (*d == 0x24 || (*d == 0x5c && (d[1] == 1 || d[1] == 0)) || *d == 0x28) {
			GetExpression(d);
		} else if (StrType(d)) {
			GetString(d);
		} else SetError();
		if (*d == 0x29) break;
		if (*d == 0x2c) {d++;} // ���� arg ���黻�ҤǻϤޤ롢�ʤɤ��ʤ����¸�ߤ��ʤ�
		dprintf(",");
	}
	for (i=0; i<argc ; i++) {
		if (*d == 0x28) {
/*
** cmd 01-22:0c1c, 01-22:0835
** Princess Bride �Υ����ɤ�����륢�˥�ξ���
** �ʤ���_PBCARDANM* �β����Ϥ��Υ��ޥ�ɤǤΤ߻Ȥ��Ƥ���Τǡ��ü�����Ȥ���̵�뤹�뤳�Ȥ��ǽ
**
** cmd 01-04:0276, 026c, 0270
** ʣ���� enum �� args �ο�����³���������ü�����Ȥ���ʬΥ����
*/
dprintf("enum.<");
			/* (...) ����� or ��¤�Τβ�ǽ�������� */
			const char* d_orig = d;
			int pt = args.size(); args.push_back(VarInfo(0));
			int count = GetArgs(d);
			args[pt] = VarInfo(count);
dprintf(">");
		} else if (*d == 0x61 && (d[1] >= 0x00 && d[1] <= 0x04) && d[2] == 0x28 ) {
			/* �Ȥ��륳�ޥ�ɤ� 01-21:004b, 01-28:0064 �Τ����줫��R,C,PB,LO)
			** �����Υ��ޥ�ɤ�
			** arg1: �����ե�����̾
			** arg2 : Sel �ֹ�
			** �餷����arg3 �ʹߤ� 0x61 <00-04> (a,b,c,...) �Ȥʤ�ʥ���׾�� enum ��ɽ�������)
			** () ��ΰ����Ϥ��ޤ��ޤǡ�a �Τߡʲ����ե�����̾�ˡ�
			** a,b b=SEL?
			** a,b,c (b,c)=��ɸ��
			** a,(b,c,d,e,f,g) b-g = src / dest?
			** �餷��
			*/
			dprintf("kasane. #%d <",d[1]);
			d += 2;
			int pt = args.size(); args.push_back(VarInfo(0));
			int count = GetArgs(d);
			args[pt] = VarInfo(count);
			dprintf(">");
		} else SetError();
		if (*d == 0x29) break;
		if (*d == 0x2c) {d++;} // ���� arg ���黻�ҤǻϤޤ롢�ʤɤ��ʤ����¸�ߤ��ʤ�
		dprintf(",");
	}
	if (*d == 0x29) d++;
	else SetError();
	return 0;
}

/* switch
	<exp>
	0x7b
		<exp> <int>
		...
	0x7d
*/

int Cmd::GetSwitch(const char*& d) {
	if (*d != 0x28) {SetError(); return -1;}
	d++;
	dprintf("switch. ");
	int var = GetExpression(d);
	if (*d != 0x29) {SetError(); return -1;}
	d++;
	dprintf("->\n");
	if (*d == 0x7b) {
		d++;
	} else SetError();

	int default_jmp = -1; int jmpto = -1;
	int i; for (i=0; i<argc; i++) {
		dprintf("\t");
		if (*d++ != 0x28) {SetError(); return -1;}
		int item = -1; // default
		if (*d != 0x29) {
			int item = GetExpression(d);
			if (*d++ != 0x29) {SetError(); return -1;}
			int jmp = read_little_endian_int(d);
			if (var == item) {
				dprintf("(selected)");
				jmpto = jmp;
			}
			dprintf(" -> %d\n", jmp);
		} else {
			d++;
			default_jmp = read_little_endian_int(d);
		}
		d += 4;
	}
	if (default_jmp != -1) {
		dprintf("default -> %d\n",default_jmp);
		if (jmpto == -1) jmpto = default_jmp;
	}
	if (*d == 0x7d) {
		d++;
	} else SetError();
	return jmpto;
}
/* simple switch
	<exp>
	0x7b
		<int>
		...
	0x7d
*/
int Cmd::GetSimpleSwitch(const char*& d) {
	if (*d != 0x28) {SetError(); return -1;}
	d++;
	dprintf("simple switch. ");
	int var = GetExpression(d);
	if (*d != 0x29) {SetError(); return -1;}
	d++;
	dprintf(" ->\n");
	int jumpto = -1;
	if (*d == 0x7b) {
		d++;
	} else SetError();
	int i; for (i=0; i<argc; i++) {
		int j = read_little_endian_int(d);
		d += 4;
		dprintf("\t%d -> %d\n", i+1, j);
		if (var == i+1) jumpto = j;
	}
	if (*d == 0x7d) {
		d++;
	} else SetError();
	return jumpto;
}

/*
selection
	? <exp>
	0x7b
		<0x0a|0x40> <ushort | uint> 
*/
void Cmd::GetSelection(const char*& d) {
	dprintf("selection. ");
	if (*d == 0x28) {
		d++;
		GetExpression(d);
		if (*d != 0x29) { SetError(); return;}
		d++;
	}
	if (*d == 0x7b) {
		d++;
		dprintf("{\n\t");
	} else SetError();
	int arg_count = 0;
	while(*d != 0x7d) {
		if (d[0] == 0x0a || d[0] == 0x40) {
			int var;
			if (system_version == 0) { var = read_little_endian_int(d+1); d += 5;}
			else { var = read_little_endian_short(d+1); d += 3;}
			dprintf("line %d; ",var);
		} else if (d[0] == 0x2c) {
			dprintf(":comma:");
		} else if (d[0] == 0x28) {
			dprintf(":cond:");
			d++;
			while(d[0] != 0x29) {
				GetExpressionCond(d); // PRINT- ��Ǥʤ��Ф��������ɽ��������ʸ���ᡢ�ޤ���PRINT��ΤϤ�
				if (*d == 0x32) { d++; dprintf("##");} // 0x32 �ʤ顢���ߤξ�����ɽ�����ʤ�
				dprintf(":");
			}
			d++;
		} else if (StrType(d)) {
			GetString(d);
			arg_count++;
			dprintf("\n\t");
		} else if (*d == 0x23 && strncmp(d,"###PRINT",8) == 0) {
			d += 8;
			if (d[0] != 0x28) SetError();
			else { // ʸ���ѿ������Ƥ�ɽ��
				d++;
				dprintf("Print.");
				VarInfo info;
				GetLeftToken(d, info);
				if (d[0] != 0x29 || info.type == -1) SetError();
				d++;
				dprintf(";");
			}
		} else { SetError(); break;}
	}
	d++;
	/* @@@ */
	/* ���פ��ʤ���礬����Τǥ����ȥ����� */
	// if (arg_count != argc) SetError();
	dprintf("\n}\n");
	return;
}

char* op_str3[11] = { "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=", "<<=", ">>=", "="};
void Cmd::GetCmd(Flags& flags_orig, const char*& d ) {
	ResetString();

	cmdstr[0] = 0;
	debug_flag = true;
	if (*d == 0x23) { /* ���ޥ�� */
		cmd_type = CMD_OTHER;
		cmd1 = *(unsigned const char*)(d+1);
		cmd2 = *(unsigned const char*)(d+2);
		cmd3 = read_little_endian_short(d+3);
		argc = read_little_endian_short(d+5);
		cmd4 = *(unsigned const char*)(d+7);
		d += 8;
		/* verbose */
			// dprintf(" 0x23 - cmd %02x-%02x:%04x:%02x[%2d] \n",cmd1,cmd2,cmd3,cmd4,argc);
			sprintf(cmdstr, "%02x-%02x:%04x:%02x",cmd1,cmd2,cmd3,cmd4);
		/* ���������� */
		/* �ü�����Τ�� */
		int is_special = 0;
		if (cmd1 == 0) {
			if (cmd2 == 1) {
				int jump_arg = -1;
				if (cmd3 == 0 || cmd3 == 5) {
					/* gosub / goto */
					jump_arg =read_little_endian_int(d);
					d += 4;
					dprintf("\tjmp -> %d\n", jump_arg);
					is_special = 1;
				} else if (cmd3 == 1 || cmd3 == 2) {
					/* conditional jump (if / unless) */
					if (*d++ != 0x28) { SetError(); return;}
					dprintf("\t");
					int cond = GetExpressionCond(d);
					if (*d++ != 0x29) { SetError(); return; }
					int jumpto = read_little_endian_int(d);
					d += 4;
					dprintf("-> %d\n", jumpto);
					if (cond) jump_arg = jumpto;
					is_special = 1;
				} else if (cmd3 == 4) {
					/* switch to */
					jump_arg = GetSwitch(d);
					is_special = 1;
				} else if (cmd3 == 8) {
					/* switch to */
					jump_arg = GetSimpleSwitch(d);
					is_special = 1;
				}
				cmd_type = CMD_OTHER;
				args.push_back(VarInfo(jump_arg));
			} else if (cmd2 == 2 && (cmd3 == 0 || cmd3 == 1 || cmd3 == 2 || cmd3 == 3 || cmd3 == 0x0d) ) {
				/* selection */
				GetSelection(d);
				is_special = 1;
			}
		}
		/* ���̰����Τ�� */
		if (!is_special) {
			dprintf(" 0x23 - cmd %02x-%02x:%04x:%02x[%2d] \n",cmd1,cmd2,cmd3,cmd4,argc);
			dprintf("\t");
			if (cmd1 == 1 && cmd2 == 0x22 && (cmd3 == 0xc1c || cmd3 == 0x835)) GetArgsSpecial(3, d);
			else if (cmd1 == 1 && cmd2 == 4 && (cmd3 == 0x26c || cmd3 == 0x270 || cmd3 == 0x276)) GetArgsSpecial(0, d);
			else if (cmd1 == 1 && (cmd2 == 0x21 && cmd3 == 0x4b) || (cmd2 == 0x28 && cmd3 == 0x64)) GetArgsSpecial(2,d);
			else GetArgs(d);
			dprintf("\n");

		}
		if (cmd2 == 3 && cmd3 == 0x78 && cmd4 == 0) ruby_flag = true;
		if (cmd2 == 3 && cmd3 == 0x11) ret_flag = true;
	} else if (*d == 0x24) { /* �����黻 */
		if (d[1] == 0x12 || d[2] != 0x5b) SetError();
		dprintf("expr: ");
		sprintf(cmdstr, "expr");

		VarInfo info;
		int value = GetLeftToken(d, info);
		if (d[0] != 0x5c) SetError();
		int type = d[1];
		if (type < 20 || type > 30) SetError();
		else dprintf("%s",op_str[type]);
		d += 2;
		int value2 = GetExpression(d);
		// ���������������
		if (type != 30) value2 = eval(value, type-20, value2);
		cmd_type = CMD_FLAGS;
		args.push_back(info);
		args.push_back(value2);
		dprintf("\n");
	} else if (StrType(d)) { /* ʸ������ */
		VarInfo info;
		info.type = TYPE_STR;
		info.value = GetString(d);
		args.push_back(info);
		cmd_type = CMD_TEXT;
		text_flag = true;
		dprintf("\n");
	} else if (*d == 0x0a || *d == 0x40) { /* ??? */
		if (*d == 0x0a) dprintf("line ");
		else dprintf("pos. ");
		d++;
		if (system_version == 0) {
			cmd3 = read_little_endian_int(d);
			d += 4;
		} else {
			cmd3 = read_little_endian_short(d);
			d += 2;
		}
		dprintf("%d\n", cmd3);
	} else if (*d == 0x2c) { /* ??? */
		dprintf("commd;0x2c\n"); // conditional jump �ιԤ���ˤ褯����餷���ʾ�ˡ����Ϥ狼��ʤ���
		d++;
	} else { 
		SetError();
	}
	return;
}

char Cmd::strtype[256] = {
	0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, /* +00 */
	0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, /* +10 */
	0,0,3,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, /* +20 */
	1,1,1,1, 1,1,1,1, 1,1,0,0, 0,0,0,1, /* +30 */
	0,1,1,1, 1,1,1,1, 1,1,1,1, 1,1,1,1, /* +40 */
	1,1,1,1, 1,1,1,1, 1,1,1,0, 0,0,0,1, /* +50 */
	0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, /* +60 */
	0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, /* +70 */
	2,2,2,2, 2,2,2,2, 2,2,2,2, 2,2,2,2, /* +80 */
	2,2,2,2, 2,2,2,2, 2,2,2,2, 2,2,2,2, /* +90 */
	0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, /* +A0 */
	0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, /* +B0 */
	0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, /* +C0 */
	0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, /* +D0 */
	2,2,2,2, 2,2,2,2, 2,2,2,2, 2,2,2,2, /* +E0 */
	2,2,2,2, 2,2,2,2, 2,2,2,2, 2,2,0,0  /* +F0 */
};

int Cmd::GetString(const char*& d) {
	int retnum = -1;
	if (*d == '"') {
		d++;
		retnum = strend;
		while(*d != '"') strheap[strend++] = *d++;
		d++; strheap[strend++]=0;
	} else if (StrType(d)) {
		retnum = strend;
		int stype;
		while( (stype = StrType(d)) ) {
			strheap[strend++] = *d++;
			if (stype == 2) strheap[strend++] = *d++;
		}
		strheap[strend++] = 0;
	}
	dprintf("\"%s\"", strheap + retnum);
	if (strend >= STRHEAP_SIZE) {
		dprintf("Error: string heap overflow\n");
	}
	return retnum;
}

int Cmd::StrVar(int var_num) {
	int retnum = strend;
	flags.Str(var_num, strheap+strend, STRHEAP_SIZE-strend);
	strend += strlen(strheap+strend)+1;
	return retnum;
}

void usage(void) {
	fprintf(stderr,"usage : scn2kdump [inputfile] [outputfile]\n");
	fprintf(stderr,"  inputfile:  seen.txt(default)\n");
	fprintf(stderr,"  outputfile: seen.txt_out(default)\n");
	exit(-1);
}
int main(int argc, char** argv) {
	/* determine file names */
	bool verbose = false;
	char* inname = "seen.txt";
	char* outname = 0;
	if (argc > 2 && strcmp(argv[1],"-v") == 0) {
		int i; for (i=1; i<argc; i++) argv[i] = argv[i+1];
		argc--;
		verbose = true;
	}
	switch(argc) {
	case 1: break;
	case 2: inname = argv[1]; break;
	case 3: inname = argv[1]; outname = argv[2]; break;
	default: usage();
	}
	/* open output file */
	FILE* outstream = stdout;
	/* create archive instance */
	SCN2kFILE archive(inname);
	archive.Init();
	if (archive.Deal() == 0) {
		fprintf(stderr,"Cannot open / Invalid archive file %s\n",inname);
		usage();
	}
	/* dump files */
	archive.InitList();
	char* fname;
	fprintf(stderr,"Dump start\n");
	while( (fname = archive.ListItem()) != 0) {
		ARCINFO* info = archive.Find(fname,"");
		if (info == 0) continue;
		char* data = info->CopyRead();
		char* d = data;
		char* dend = d + info->Size();
		/* version ��ǧ */
		if (read_little_endian_int(d) == 0x1cc) {
			system_version = 0;
		} else if (read_little_endian_int(d) == 0x1d0) {
			system_version = 1;
		} else {
			continue;
		}
		if (read_little_endian_int(d+4) != 0x2712) continue;
		int header_size;
		if (system_version == 0) {
			header_size = 0x1cc + read_little_endian_int(d+0x20) * 4;
		} else {
			header_size = read_little_endian_int(d+0x20);
		}
		d += header_size;

		const char* dcur = d;
		const char* dstart = d;
		fprintf(stderr,"Dumping %s\n",fname);
		fprintf(stdout,"Dumping %s\n",fname);
{ int i; for (i=0; i<100; i++) {
		int n = read_little_endian_int(data + 0x34 + i*4);
		if (n != 6) fprintf(stdout,"subroutine table %2d: %6d\n",i,n);
}}
		Flags flags;
		/* �ǽ餫��Ǹ�ޤǥ��ޥ�ɼ��� -> ���Ϥ򷫤��֤� */
		while(dcur<dend) {
			const char* dprev = dcur;
			Cmd cmd(flags); cmd.ClearError();

			/* end? */
			if (*dcur == -1) {
				/* 0xff x 32byte + 0x00 : end sign */
				int i; for (i=0; i<0x20; i++)
					if (dcur[i] != -1) break;
				if (i == 0x20 && dcur[i] == 0) break;
			}
			dprintf("%d : ",dcur-dstart);
			cmd.GetCmd(flags, dcur);
			if (cmd.IsError()) {
				fprintf(outstream, "Error at %6d\n",dprev-dstart);
				while(dcur < dend) {
					if (*dcur == 0x29 && dcur[1] == 0x0a) {dcur++;break;}
					dcur++;
				}
				dprev -= 2*16;
				int ilen = (dcur-dprev+15)/16;
				int i; for (i=0; i<ilen; i++) {
					fprintf(outstream, "%6d: ",dprev-dstart);
					int j; for (j=0; j<16; j++) {
						if (dprev >= dend) break;
						if (dprev < data) continue;
						fprintf(outstream, "%02x ",*(unsigned char*)(dprev));
						dprev++;
					}
					fprintf(outstream, "\n");
				}
			}
		}
		delete info;
	}
	return 0;
}

/*
SetStr
	0x23 - cmd 01-0a:0000:00[ 2] 
	args:V<18>[17],"PB47"
CatStr
	0x23 - cmd 01-0a:0002:00[ 2] 
	args:V<18>[17],V<18>[20]

WaitClick
	0x23 - cmd 00-03:0011:00[ 0] 
	
ChangeFaceGraphics
	0x23 - cmd 00-03:03e8:00[ 1] 
	args:V<18>[17]
DeleteFaceGraphics
	0x23 - cmd 00-03:03e9:01[ 0] 
KoePlay
	0x23 - cmd 01-17:0000:01[ 2] 
	args:100000026,5
DrawGraphics(���ʲ褢���
	0x23 - cmd 01-21:004b:00[ 1] 
	args:V<18>[1],10,kasane. #1 <args:V<18>[17],11>

DrawGraphics(�طʤΤ�)
	0x23 - cmd 01-21:0049:00[ 2] 
	args:V<18>[1],10
	
Ruby
	0x23 - cmd 00-03:0078:01[ 0] 
	"��ͳ"
	0x23 - cmd 00-03:0078:00[ 1] 
	"�櫓"
SetTitle
	0x23 - cmd 01-04:0000:00[ 1] 
	args:"Long Long Time Ago..."
WaitTime
	0x23 - cmd 01-14:0069:00[ 1] 
	args:3000
ChangeBGM	���Ͱ����ϥե����ɥ����ȡ�����λ��֤ȿ�¬
0x23 - cmd 01-14:0000:02[ 3] 
	args:"BGM18",700,700
*/
