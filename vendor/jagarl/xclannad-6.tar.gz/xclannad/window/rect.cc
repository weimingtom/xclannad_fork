/*
 *
 *  Copyright (C) 2004-   Kazunori Ueno(JAGARL) <jagarl@creator.club.ne.jp>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
*/

#include "rect.h"

using namespace std;

inline int MAX(int a, int b) {
	if (a>b) return a;
	return b;
}
inline int MIN(int a, int b) {
	if (a>b) return b;
	return a;
}

Rect::Rect(int x1, int y1) {
	lx = rx = x1;
	ty = by = y1;
}
Rect::Rect(int x1, int y1, int x2, int y2) {
	lx = MIN(x1,x2);
	rx = MAX(x1,x2);
	ty = MIN(y1,y2);
	by = MAX(y1,y2);
}
Rect::Rect(const Rect& r) {
	lx = r.lx;
	rx = r.rx;
	ty = r.ty;
	by = r.by;
}

bool Rect::is_inner(const Rect& inner_rect) {
	Rect r = *this;
	r.intersect(inner_rect);
	return r == inner_rect;
}
bool Rect::is_nearly_inner(const Rect& inner_rect, int delta) {
	Rect r = *this;
	r.lx -= delta;
	r.ty -= delta;
	r.rx += delta;
	r.by += delta;
	r.intersect(inner_rect);
	return r == inner_rect;
}
bool Rect::is_crossed(const Rect& rect) {
	Rect r = *this;
	r.intersect(rect);
	return !(r.empty());
}
void Rect::intersect(const Rect& r) {
	if (lx > r.rx) rx = lx;
	else if (rx < r.lx) lx = rx;
	else {
		lx = MAX(lx, r.lx);
		rx = MIN(rx, r.rx);
	}

	if (ty > r.by) by = ty;
	else if (by < r.ty) ty = by;
	else {
		ty = MAX(ty, r.ty);
		by = MIN(by, r.by);
	}
}
void Rect::join(const Rect& r) {
	lx = MIN(lx, r.lx);
	rx = MAX(rx, r.rx);
	ty = MIN(ty, r.ty);
	by = MAX(by, r.by);
}
void Rect::rmove(int add_x, int add_y) {
	lx += add_x;
	rx += add_x;
	ty += add_y;
	by += add_y;
}
void Rect::subtract(const Rect& rect, vector<Rect>& ret_array) const {
	Rect r = *this;
	r.intersect(rect);
	if (r.empty()) { // not intersect the rects
		ret_array.push_back(*this);
		return;
	}
	if (r ==*this) { // identical; no rect rests
		return;
	}
	// push top area
	if (ty != r.ty) {
		ret_array.push_back(Rect(lx, ty, rx, r.ty));
	}
	// push bottom area
	if (by != r.by) {
		ret_array.push_back(Rect(lx, r.by, rx, by));
	}
	// push left area
	if (lx != r.lx) {
		ret_array.push_back(Rect(lx, r.ty, r.lx, r.by));
	}
	// push right area
	if (rx != r.rx) {
		ret_array.push_back(Rect(r.rx, r.ty, rx, r.by));
	}
	return;
}
