#ifndef __MUSIC_SYSTEM_H__
#define __MUSIC_SYSTEM_H__

#include<unistd.h>
struct MuSys {
	class AyuSysConfig& config;
	char cdrom_track[128]; char effec_track[128];
	int movie_id;
	int music_enable;
	MuSys(AyuSysConfig& _config);

	void SetCDROMDevice(char* dev);
	void SetPCMDevice(char* dev);
	void SetMixDevice(char* dev);
	void SetPCMRate(int rate);
	void PlayCDROM(char* name, int time, int play_count);
	void StopCDROM(void);
	void FadeCDROM(int time);
	void SetWaveMixer(int is_mix);
	void PlayWave(char* fname, int time, int play_count);
	void StopWave(void);
	void PlaySE(const char* name);
	void PlaySE(int number);
	void StopSE(void);
	bool IsStopSE(void);
	void PlayKoe(const char* fname);
	void StopKoe(void);
	void WaitStartKoe(void);
	void FadeKoe(int time);
	bool IsStopKoe(void);
	void PlayMovie(const char* fname, int x1, int y1, int x2, int y2, int loop_count);
	void StopMovie(void);
	void PauseMovie(void);
	void ResumeMovie(void);
	bool IsStopMovie(void);
	void WaitStopMovie(int is_click);
	void SyncMusicState(void);
	void DisableMusic(void);
	void InitMusic(void);
	void FinalizeMusic(void);
	void ReceiveMusicPacket(void);
	/* ���Ϥޤǻ����Ԥ����Ѥ�stab */
	void* setTimerBase(void);
	int getTime(void*);
	void freeTimerBase(void*);
	void CallIdleEvent(void) {};
	void CallProcessMessages(void) { usleep(0);}
};

#endif
