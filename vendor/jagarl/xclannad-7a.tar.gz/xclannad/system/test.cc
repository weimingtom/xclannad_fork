#include<zlib.h>
#include<stdio.h>
#include<string.h>

static int read_little_endian_int(const char* buf) {
	const unsigned char *p = (const unsigned char *) buf;
	return (p[3] << 24) | (p[2] << 16) | (p[1] << 8) | p[0];
}

int main(int argc, char** argv) {
	char head[0x114];
	FILE* f;
	if (argc==2)
		f = fopen(argv[1],"rb");
	else
		f = fopen("image.pak","rb");
	if (f == 0) return 0;
	fread(head, 0x114, 1, f);
	if (read_little_endian_int(head) != 2 ||
		read_little_endian_int(head+0x10) != 0x66 ||
		strncmp(head+0x14, "DEMONBANE", 9) != 0) return 0;
	int files = read_little_endian_int(head+4);
	uLong index_size = read_little_endian_int(head+8);
	int id = index_size;
	int index_size_comp = read_little_endian_int(head+12);
	char* cbuf = new char[index_size_comp];
	char* buf = new char[index_size];
	fread(cbuf, index_size_comp, 1, f);
	int status = uncompress( (Bytef*)buf, &index_size, (const Bytef*)cbuf, index_size_comp);
	if (status != Z_OK) {
		printf("err.\n");
	}
	fprintf(stderr,"size %d index %d\n",index_size,id);
	fprintf(stderr,"files %d div: %f\n",files,double(index_size)/double(files));
	int i; int cur = 0;
	char name[1024];
	for (i=0; i<files; i++) {
		int namelen = read_little_endian_int(buf+cur);
		cur += 4;
		strncpy(name, buf+cur, namelen);
		name[namelen] =0;
		cur += namelen;
		int p1 = read_little_endian_int(buf+cur+0);
		int p2 = read_little_endian_int(buf+cur+4);
		int p3 = read_little_endian_int(buf+cur+8);
		int p4 = read_little_endian_int(buf+cur+12);
		int p5 = read_little_endian_int(buf+cur+16);
		printf("%40s: %8d %8d %8d %8d %8d\n",name,p1,p2,p3,p4,p5);
		cur += 20;
	}
//	fwrite(buf,index_size,1,stdout);
}
