#define ROOTPATH "/mnt/KEY/CLANNAD"
#define FONT "msgothic.ttc"
	/* kochi-mincho-subst.ttf ���뤤�� -*-*-*-r-*--24-*-*-*-*-*-jisx0208.1983-* �ʤ� */
	/* TrueType Font �� /usr/X11R6/lib/X11/fonts/TrueType/ �ʤɤ�¸�ߤ���ɬ�פ����� */

extern void SetFont(const char* font);

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

#include<SDL.h>
#include<vector>

#include"system/file.h"
#include"system/system_config.h"
#include"window/widget.h"
#include"window/system.h"

#include"music/system.h"

#include"scn2k/scn2k.h"
#include"scn2k/scn2k_impl.h"

int main(void) {
	AyuSysConfig config;
	printf("%s\n",setlocale(LC_ALL,""));
	file_searcher.InitRoot(ROOTPATH);
	config.LoadInitFile();
int deal=0;
const int* s = config.GetParamArray("#SHAKE.001",deal);
int i; for (i=0; i<deal; i++) { printf("%d, ",s[i]);}
printf("shake end\n");

	SetFont(FONT);

	MuSys mu(config);
	mu.InitMusic();
	
	SDL_Init(SDL_INIT_VIDEO);
	SDL_SetVideoMode(640, 480, 0, SDL_HWSURFACE /*| SDL_FULLSCREEN */);
	{
		System::Main main;
		PicContainer* main_panel = main.root.create_node(Rect(0, 0, main.root.width, main.root.height), 0);
		main_panel->show();
		{
			Scn2k scn(main.event, *main_panel, mu, config);
			main.Mainloop();
		}
		delete main_panel;
	}

	mu.FinalizeMusic();

	SDL_Quit();
}

