/*
 *
 *  Copyright (C) 2004-   Kazunori Ueno(JAGARL) <jagarl@creator.club.ne.jp>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
*/

#ifndef __RECT_H__
#define __RECT_H__

#include<vector>

struct Rect {
	int lx, rx; // x = [lx,rx)
	int ty, by; // y = [ty,by)

	Rect(int x1, int y1);
	Rect(int x1, int y1, int x2, int y2);
	Rect(const Rect& rect);
	Rect(const class Surface& rect);
	Rect(const class TextGlyph& glyph);
	void intersect(const Rect& rect);
	bool is_crossed(const Rect& rect);
	bool is_inner(const Rect& inner_rect);
	bool is_nearly_inner(const Rect& inner_rect, int delta);
	void join(const Rect& rect);
	void rmove(int add_x, int add_y);
	/** Subtracts rect from this. The resulting area is the set of pixels contained in this but not in the rect.
	  * result will be push_backed to ret_array.
	  */
	void subtract(const Rect& rect, std::vector<Rect>& ret_array) const;
	bool point_in(int x, int y) const;
	bool empty(void) const {
		return (lx == rx) || (ty == by);
	}
	int width(void) const {
		return rx-lx;
	}
	int height(void) const {
		return by-ty;
	}
};

inline bool operator ==(const Rect& r1, const Rect& r2) {
	return (r1.lx == r2.lx && r1.rx == r2.rx && r1.ty == r2.ty && r1.by == r2.by);
}
inline bool Rect::point_in(int x, int y) const {
	return (lx <= x && x < rx && ty <= y && y < by);
}

struct Color {
	int r,g,b,a;
	Color(int _r, int _g, int _b) : r(_r),g(_g),b(_b),a(0xff) {}
	Color(int _r, int _g, int _b, int _a) : r(_r),g(_g),b(_b),a(_a) {}
};
#endif
