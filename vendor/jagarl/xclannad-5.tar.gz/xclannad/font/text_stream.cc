/*
 * Copyright (c) 2004  Kazunori "jagarl" Ueno
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "text.h"
#include "codeconv.h"

TextStream::TextStream(void) {
	kanji_type = euc;
}
void TextStream::SetSize(double scale) {
	TextElem elem;
	elem.type = TextElem::size;
	elem.impl.Size.scale = scale;
	container.push_back(elem);
}
void TextStream::SetColor(unsigned char r, unsigned char g, unsigned char b) {
	TextElem elem;
	elem.type = TextElem::color;
	elem.impl.Color.r = r;
	elem.impl.Color.g = g;
	elem.impl.Color.b = b;
	container.push_back(elem);
}
void TextStream::Clear(void) {
	container.clear();
}
void TextStream::Add(const char* str) {
	TextElem elem;
	for (; *str; str++) {
		if (*str >= 0x20) {
			elem.type = TextElem::glyph;
			elem.impl.Glyph.code = *str;
		} else if (*str < 0 && str[1] != 0) {
			elem.type = TextElem::glyph;
			elem.impl.Glyph.code = ((int(*(unsigned char*)str))<<8) | int(*(unsigned char*)(str+1));
			if (kanji_type == sjis) elem.impl.Glyph.code = codeconv_sjis_to_euc(elem.impl.Glyph.code);
			str++;
		} else {
			continue;
		}
		container.push_back(elem);
	}
}
void TextStream::AddReturn(void) {
	TextElem elem;
	elem.type = TextElem::escape;
	elem.impl.Escape.type = TextElem::ret;
	container.push_back(elem);
}
void TextStream::AddName(const char* str) {
	TextElem elem;
	elem.type = TextElem::escape;
	elem.impl.Escape.type = TextElem::name_start;
	container.push_back(elem);
	Add(str);
	elem.impl.Escape.type = TextElem::name_end;
	container.push_back(elem);
}

void TextStream::AddRuby(const char* str, const char* ruby) {
	TextElem elem;
	elem.type = TextElem::escape;
	elem.impl.Escape.type = TextElem::ruby_start;
	container.push_back(elem);
	Add(str);
	elem.impl.Escape.type = TextElem::ruby_startruby;
	container.push_back(elem);
	Add(ruby);
	elem.impl.Escape.type = TextElem::ruby_end;
	container.push_back(elem);
}

void TextStream::RemoveName(char* name, int namelen) {
	Iterator it;
	for (it = container.begin(); it != container.end(); it++) {
		if (it->type == TextElem::escape && it->impl.Escape.type == TextElem::name_start) {
			// ��Ƭ��̾����
			int pt = it - container.begin();
			Iterator name_start = it;
			for (; it != container.end(); it++) {
				if (it->type == TextElem::escape && it->impl.Escape.type == TextElem::name_end) break;
			}
			if (it != container.end()) {
				// ̾�������Ĥ��ä��ΤǺ��
				if (name) { // ��¸�褬����ʤ���¸����
					Iterator name_end = it;
					int pos = 0;
					namelen--;
					for (it=name_start; it != name_end; it++) {
						if (it->type == TextElem::glyph) {
							unsigned int code = it->impl.Glyph.code;
							if (code < 0x100) {
								if (pos < namelen) name[pos++] = code;
							} else {
								if (pos < namelen) name[pos++] = code>>8;
								if (pos < namelen) name[pos++] = code;
							}
						}
					}
					name[pos] = 0;
					name = 0; // �ǽ�˽Ф�̾���Τ���¸����
				}
				it++;
				container.erase(name_start, it);
				it = container.begin() + pt;
			}
		}
		for (;it != container.end(); it++) {
			if (it->type == TextElem::escape && it->impl.Escape.type == TextElem::ret) break;
		}
		if (it == container.end()) break;
	}
}

void TextGlyphStream::SetColor(int r, int g, int b) {
	iterator it;
	for (it=begin(); it != end(); it++) {
		it->r = r;
		it->g = g;
		it->b = b;
	}
}
void TextGlyphStream::SetReverse(bool is_rev) {
	iterator it;
	for (it=begin(); it != end(); it++) {
		it->is_rev = is_rev;
	}
}
