/*  system_music.cc
 *      AyuSys �� music.h ��Ĥʤ� interface
 */

/*
 *
 *  Copyright (C) 2000-   Kazunori Ueno(JAGARL) <jagarl@creator.club.ne.jp>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
*/

#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <ctype.h>
#include <signal.h>
#include <map>
#include <errno.h>
#include <vector>
#include <list>
#include <algorithm>
#include"system/system_config.h"
#include"system/file.h"

extern "C" {
#include "music.h"
#include "mixer.h"
}

using namespace std;

#include"system.h"

MuSys::MuSys(AyuSysConfig& _config) : config(_config), movie_id(-1), music_enable(1) {
	cdrom_track[0] = 0;
	effec_track[0] = 0;
}


// #define delete fprintf(stderr,"smus.cc: %d.",__LINE__), delete

void MuSys::SetCDROMDevice(char* dev) {
	cd_set_devicename(dev);
}
void MuSys::SetPCMDevice(char* dev) {
	pcm_setDeviceName(dev);
}
void MuSys::SetMixDevice(char* dev) {
	mixer_setDeviceName(dev);
}
void MuSys::SetPCMRate(int rate) {
	if (rate <= 0) return;
	mus_set_default_rate(rate);
}

void MuSys::PlayCDROM(char* name, int time, int play_count) {
	char wave[128]; wave[127] = '\0'; wave[0] = '\0';

	strcpy(cdrom_track, name);

	StopCDROM();
	strcpy(cdrom_track, name);

	if (time <= 0) time = 0;

	/* name -> track */
	int track =config.track_name.CDTrack(name);
	if (config.track_name.WaveTrack(name) != 0) strncpy(wave, config.track_name.WaveTrack(name), 127);
	if (track == -1) track = atoi(name);
	if (track != 0 && (! cdrom_enable)) { /* CDROM �������Բ�ǽ�ʾ�硢pcm ���ߤ� */
		sprintf(wave, "audio_%02d",track);
		track = 0;
	}
	if (track == 0) { // play wave file
		if (wave == 0) return;
		// wave file ��Ĺ��������
		char wave_tmp[128];
		int len = strlen(wave); if (len > 100) len = 100;
		strncpy(wave_tmp, wave, len); wave_tmp[len] = '\0';
		// BGM ����
		if (!pcm_enable) return;
		mus_bgm_start(wave_tmp, play_count, config.track_name.TrackStart(name));
		// �Ϥޤ�ޤ��Ԥ�
		int pos;
		void* timer = setTimerBase();
		const int wait_time = 2000; // �������Ϥޤǡ����磲���Ԥ�
		while(mus_bgm_getStatus(&pos) == 0 && getTime(timer) < wait_time)  {
			CallIdleEvent();
			CallProcessMessages();
		}
		freeTimerBase(timer);
		/* ���̤����ˤ��� */
		mus_mixer_fadeout_start(MIX_PCM_BGM, time, 100, 0);
	} else { // play CDROM once
		if (! cdrom_enable) return;
		/* CDROM ���� */
		mus_setLoopCount(play_count);
		mus_cdrom_start(track);
		/* �������Ϥޤ��Ԥ� */
		cd_time tm;
		void* timer = setTimerBase();
		const int wait_time = 2000; // �������Ϥޤǡ����磲���Ԥ�
		do {
			mus_cdrom_getPlayStatus(&tm);
			CallIdleEvent();
			CallProcessMessages();
		} while( tm.t != track && getTime(timer) < wait_time);
		/* ���̤����ˤ��� */
		mus_mixer_fadeout_start(MIX_CD, 0, time, 0);
	}
	return;
}

void MuSys::StopCDROM(void)
{
	cdrom_track[0] = '\0';
		if (! pcm_enable) return;
		mus_bgm_stop();
		mus_mixer_fadeout_start(MIX_PCM_BGM, 0, 0, 1);
		if (! cdrom_enable) return;
		// CDROM �� fadeout ��ߤ��
		mus_mixer_stop_fadeout(MIX_CD);
		while(mus_mixer_get_fadeout_state(MIX_CD) == 0) {
			CallProcessMessages();
		}
		mus_mixer_fadeout_start(MIX_CD, 0, 0, 1);
}

void MuSys::FadeCDROM(int time)
{
	cdrom_track[0] = '\0';
		if ( pcm_enable)
			mus_mixer_fadeout_start(MIX_PCM_BGM, time, 0, 1);
		if (cdrom_enable)
			mus_mixer_fadeout_start(MIX_CD, time, 0, 1);
}


void MuSys::SetWaveMixer(int is_mix) {
	mus_pcm_set_mix(is_mix);
}

void MuSys::PlayWave(char* fname, int time, int play_count) {
	if (! pcm_enable) return;

	if (time <= 0) time = 0;

	if (strlen(fname) > 128) {
		effec_track[0] = '\0';
	} else strcpy(effec_track, fname);
	/* ���� */
	mus_effec_start(fname,play_count);
	// �Ϥޤ�ޤ��Ԥ�
	int pos;
	void* timer = setTimerBase();
	const int wait_time = 2000; // �������Ϥޤǡ����磲���Ԥ�
	while(mus_effec_getStatus(&pos) == 0 && getTime(timer) < wait_time)  {
		CallIdleEvent();
		CallProcessMessages();
	}
	freeTimerBase(timer);
	/* ���̤����ˤ��� */
	mus_mixer_fadeout_start(MIX_PCM_EFFEC, time, 100, 0);
	return;
}

void MuSys::StopWave(void) {
	effec_track[0] = '\0';
	if (! pcm_enable) return;
	mus_effec_stop();
}

void MuSys::PlaySE(const char* se) {
	if (! pcm_enable) return;
	/* ���̺���Ǻ��� */
	mus_effec_start(se, 1);
	mus_mixer_fadeout_start(MIX_PCM_EFFEC, 0, 100, 0);
	return;
}
void MuSys::PlaySE(int number) {
	if (! pcm_enable) return;
	const char* se_name = config.track_name.SETrack(number);
	if (se_name == 0) return;
	/* ���̺���Ǻ��� */
	mus_effec_start(se_name, 1);
	mus_mixer_fadeout_start(MIX_PCM_EFFEC, 0, 100, 0);
	return;
}
void MuSys::StopSE(void) {
	if (! pcm_enable) return;
	mus_effec_stop();
}
bool MuSys::IsStopSE(void) {
	if (! pcm_enable) return true;
	int pos;
	if (mus_effec_getStatus(&pos) != 0) return false;
	return true;
}

void MuSys::PlayKoe(const char* fname) {
	if (! pcm_enable) return;
	/* ���� */
	mus_koe_start(fname);
	// �Ϥޤ�ޤ��Ԥ�
#if 0
	int pos;
	void* timer = setTimerBase();
	const int wait_time = 500; // �������Ϥޤǡ�����0.5���Ԥ�
	while(mus_koe_getStatus(&pos) == 0 && getTime(timer) < wait_time)  {
		CallIdleEvent();
		CallProcessMessages();
	}
	freeTimerBase(timer);
#endif
	mus_mixer_fadeout_start(MIX_PCM_KOE, 0, 100, 0);
	return;
}

void MuSys::StopKoe(void) {
	if (! pcm_enable) return;
	mus_koe_stop();
}

void MuSys::FadeKoe(int time) {
	if (! pcm_enable) return;
	mus_mixer_fadeout_start(MIX_PCM_KOE, time, 0, 1);
}
bool MuSys::IsStopKoe(void) {
	if (! pcm_enable) return true;
	int pos;
	if (mus_koe_getStatus(&pos) != 0) return false;
	return true;
}

void MuSys::PlayMovie(char* fname, int x1, int y1, int x2, int y2, int loop_count) {
	// if (movie_id != -1) DeletePartWindow(movie_id);
	// movie_id = MakePartWindow(x1, y1, x2-x1+1, y2-y1+1);
	movie_id = -1; // �Ȥꤢ����̵��
	if (movie_id == -1) return;
	/* ���� */
	mus_movie_start(fname, movie_id, 0, 0, x2-x1, y2-y1, loop_count);
	// �Ϥޤ�ޤ��Ԥ�
	int pos;
	void* timer = setTimerBase();
	const int wait_time = 2000; // �������Ϥޤǡ����磲���Ԥ�
	while(mus_movie_getStatus(&pos) == 0 && getTime(timer) < wait_time)  {
		CallIdleEvent();
		CallProcessMessages();
	}
	if (mus_movie_getStatus(&pos) == 0) {
		/* ���Ԥ��� */
		mus_movie_stop();
		// DeletePartWindow(movie_id);
		movie_id = -1;
	}
	freeTimerBase(timer);
	return;
}

void MuSys::StopMovie(void) {
	mus_movie_stop();
}
void MuSys::PauseMovie(void) {
	mus_movie_pause();
}
void MuSys::ResumeMovie(void) {
	mus_movie_resume();
}

void MuSys::SyncMusicState(void) {
	// CDROM / ���̲��κ���������äƤ����
	// �������� track �� "\0" �ˤ���
	int dummy;
	//if (GetCDROMMode() == MUSIC_ONCE) {
		if (mus_bgm_getStatus(&dummy) == 0) {
			cdrom_track[0] = '\0';
		} else {
			cd_time tm;
			mus_cdrom_getPlayStatus(&tm);
			if (tm.t == 999) { // error exit -> cdrom stop
				cdrom_track[0] = '\0';
			}
		}
	// }
}

void MuSys::DisableMusic(void) {
	if (music_enable == 2) FinalizeMusic();
	music_enable = 0;
}

void MuSys::InitMusic(void)
{
	if (music_enable != 1) return;
	cdrom_track[0] = '\0';
	if (config.GetParaInt("#MUSIC_LINEAR_PAC")) mus_set_8to16_usetable(1);
	mus_init();
	if (mus_mixer_get_default_level(MIX_CD) == 0)
		mus_mixer_set_default_level(MIX_CD, 63);
	if (mus_mixer_get_default_level(MIX_PCM) == 0)
		mus_mixer_set_default_level(MIX_PCM, 80);
	music_enable = 2;
}

void MuSys::FinalizeMusic(void)
{
	if (music_enable == 2) {
		mus_exit(0);
		music_enable = 1;
	}
}

char* System_tmpDir = "/tmp";
void System_error(const char* msg) {
	fprintf(stderr, "Error  : %s\n",msg);
	fflush(stderr);
}
void System_errorOutOfMemory(const char* msg) {
	System_error(msg);
}


/* ���ڡ������ڤ�ǥ��ޥ�ɥ饤�������ʬ�䤹�� */
/* pipe ������ɤ߹����� */
static char** SplitCmdArg(const char* cmd_orig, const char* cmdarg_orig, const char* lastarg_orig) {
	char** args_orig = new char*[strlen(cmdarg_orig)+3];
	char** args = args_orig;
	char* cmd = new char[strlen(cmd_orig)+1]; strcpy(cmd, cmd_orig);
	char* lastarg = new char[strlen(lastarg_orig)+1]; strcpy(lastarg, lastarg_orig);
	char* cmdarg = new char[strlen(cmdarg_orig)+1]; strcpy(cmdarg, cmdarg_orig);
	*args++ = cmd;
	while(1) {
		while(*cmdarg <= 0x20 && *cmdarg != 0) cmdarg++; /* ���ڡ����������ɤ����Ф� */
		if (*cmdarg == 0) break;
		*args++ = cmdarg;
		while(*cmdarg > 0x20) cmdarg++; /* ���ڡ��������ְʳ��ɤ����Ф� */
		if (*cmdarg == 0) break;
		*cmdarg++ = '\0';
	}
	*args++ = lastarg;
	*args = 0;
	return args_orig;
}

const char* fileext_orig[] = {"nwa","mp3", "mid", 0};
const char* player_orig[] = {"nwatowav",MP3CMD, MIDICMD, 0};
const char* cmdline_orig[] = {"",MP3ARG, MIDIARG, 0};
extern "C" pid_t fork_local(void);
extern "C" FILE* OpenWaveFile(const char* path, int* size, int start_pt) {
	char cmdline_buf[1024];
	/* �ޤ� wav �ե������õ�� */
	ARCINFO* info = file_searcher.Find(FILESEARCH::WAV,path,".wav");
	if (info == 0) info = file_searcher.Find(FILESEARCH::BGM,path,"wav");
	if (info) {
		FILE* f = info->OpenFile(size);
		delete info;
		return f;
	}
	/* �ʤ���� mp3 �ʤɤ�õ�� */
	const char** fileext = fileext_orig;
	const char** player = player_orig;
	const char** cmdline = cmdline_orig;
	if (size) *size = -1;
	while( *fileext != 0) {
		info = file_searcher.Find(FILESEARCH::WAV, path, *fileext);
		if (info == 0) info = file_searcher.Find(FILESEARCH::BGM, path, *fileext);
		if (info != 0 && **player != '\0') break;
		fileext++; player++; cmdline++;
	}
	if (info == 0) return 0;
	/* �ѥ��פ򳫤� */
	int pipes[2] = {-1,-1};
	int child_id;
	if (pipe(pipes) != -1 && (child_id=fork_local()) == 0) {
		/* �ҥץ����� */
		/* �ѥ��פ� stdout �˳�����ơ�exec ���� */
		close(pipes[0]);
		close(1);
		dup(pipes[1]);
		close(pipes[1]);
		int null_fd = open("/dev/null", O_WRONLY);
		if (null_fd != -1) {
			close(2);
			dup(null_fd);
			close(null_fd);
		}
		/* ���ޥ�ɥ饤������β��� */
		/* XXX... GiGiGi */
		if (start_pt) {
			if (strcmp(*player, "nwatowav") == 0) {
				sprintf(cmdline_buf, "--skip %d %s",start_pt, *cmdline);
			} else {
				strcpy(cmdline_buf, *cmdline);
			}
		} else {
			strcpy(cmdline_buf, *cmdline);
		}
		char** args = SplitCmdArg(*player, cmdline_buf, info->Path());
		if (strcmp(*player, "nwatowav") == 0)
			execvp(*player, args);
		else
			execv(*player, args);
		sleep(1000); /* ���顼������Хץ쥤�Բ�ǽ�ʤΤǤʤˤ⤷�ʤ� */
		exit(-1);
	}
	if (child_id == -1) { /* ���顼 */
		/* ���顼�������� */
		if (pipes[0] != -1) { close(pipes[0]); close(pipes[1]); }
		delete info;
		return 0;
	} else {
		close(pipes[1]);
		FILE* f = fdopen(pipes[0],"r");
		delete info;
		return f;
	}
}

extern "C" const char* FindMovieFile(const char* path) {
	ARCINFO* info = file_searcher.Find(FILESEARCH::MOV,path,"avi");
	if (info == 0) 
		info = file_searcher.Find(FILESEARCH::MOV,path,"mpg");
	if (info == 0) return 0;
	const char* file = info->Path();
	delete info;
	return file;
}

void MuSys::ReceiveMusicPacket(void) {
	SRVMSG   msg;

	memset(&msg, 0, sizeof(msg));
	RecvMsgServerToClient(&msg, 0);
#if FreeBSD_PTHREAD_ERROR == 1
	raise(SIGPROF);
#endif /* PTHREAD_ERROR */
	switch(msg.msg_type) {
	case NoProcess:
		break;
	case MUS_MOV_INFORM_END:
		// DeletePartWindow(movie_id);
		movie_id = -1;
		break;
	default:
		printf("unknown msg get from server \n");
	}
}

/* ���ե�����Υ����������ѤΥ���å��� */
#define koe_cache_size 7
struct AvgKoeTable {
	int koe_num;
	int length;
	int offset;
	AvgKoeTable(char* buf, int original_offset) {
		koe_num = read_little_endian_short(buf);
		length = read_little_endian_short(buf+2);
		offset = original_offset + read_little_endian_int(buf+4);
	}
	bool operator <(int number) const {
		return koe_num < number;
	}
	bool operator <(const AvgKoeTable& to) const {
		return koe_num < to.koe_num;
	}
	bool operator ==(const AvgKoeTable& to) const {
		return koe_num == to.koe_num;
	}
	bool operator ==(const int to) const {
		return koe_num == to;
	}
};
struct AvgKoeHead {
	FILE* stream;
	int file_number;
	int rate;
	vector<AvgKoeTable> table;
	AvgKoeHead(FILE* stream, int file_number);
	AvgKoeHead(const AvgKoeHead& from);
	~AvgKoeHead();
	AvgKoeTable* Find(int koe_num);
	bool operator !=(int num) const { return file_number != num; }
	bool operator ==(int num) const { return file_number == num; }
};
struct AvgKoeCache {
	list<AvgKoeHead> cache;
	AvgKoeInfo Find(int file_number, int index);
};
static AvgKoeCache koe_cache;

AvgKoeInfo AvgKoeCache::Find(int file_number, int index) {
	AvgKoeInfo info;
	info.stream = 0; info.length = 0; info.offset = 0;

	list<AvgKoeHead>::iterator it;
	it = find(cache.begin(), cache.end(), file_number);
	if (it == cache.end()) {
		/* ������ head ���� */
		char fname[100];
		sprintf(fname, "z%03d.koe", file_number);
		ARCINFO* arcinfo = file_searcher.Find(FILESEARCH::KOE,fname,".koe");
		if (arcinfo == 0) return info;
		FILE* stream = arcinfo->OpenFile();
		delete arcinfo;
		if (stream == 0) return info;
		cache.push_front(AvgKoeHead(stream, file_number));
		if (cache.size() >= koe_cache_size) cache.pop_back();
		it = cache.begin();
	}
	if (it->file_number != file_number) return info; // �ֹ椬��������
	AvgKoeTable* table = it->Find(index);
	if (table == 0) return info; // index �����դ���ʤ�
	// info ���������
	info.length = table->length;
	info.offset = table->offset;
	info.rate = it->rate;
	int new_fd = dup(fileno(it->stream));
	if (new_fd == -1) info.stream = 0;
	else info.stream = fdopen(new_fd, "rb");
	return info;
}

AvgKoeHead::AvgKoeHead(const AvgKoeHead& from) {
	if (from.stream) {
		int new_fd = dup(fileno(from.stream));
		if (new_fd == -1) stream = 0;
		else stream = fdopen(new_fd, "rb");
	}
	file_number = from.file_number;
	rate = from.rate;
	table = from.table;
}
AvgKoeHead::AvgKoeHead(FILE* _s, int _file_number) {
	char head[0x20];
	stream = _s; file_number = _file_number;
	int offset = ftell(stream);
	rate = 22050;
	if (stream == 0) return;
	/* header �ɤ߹��� */
	fread(head, 0x20, 1, stream);
	if (strncmp(head, "KOEPAC", 7) != 0) { // invalid header
		stream = 0;
		return;
	}
	int table_len = read_little_endian_int(head+0x10);
	rate = read_little_endian_int(head+0x18);
	if (rate == 0) rate = 22050;
	/* table �ɤ߹��� */
	table.reserve(table_len);
	char* buf = new char[table_len*8];
	fread(buf, table_len, 8, stream);
	int i; for (i=0; i<table_len; i++) {
		table.push_back(AvgKoeTable(buf+i*8, offset));
	}
	sort(table.begin(), table.end());
}
AvgKoeHead::~AvgKoeHead(void) {
	if (stream) fclose(stream);
	stream = 0;
}
AvgKoeTable* AvgKoeHead::Find(int koe_num) {
	if (table.empty()) return 0;
	vector<AvgKoeTable>::iterator it;
	it = lower_bound(table.begin(), table.end(), koe_num);
	if (it == table.end() || it->koe_num != koe_num) return 0;
	return &table[it-table.begin()];
}

extern "C" AvgKoeInfo OpenKoeFile(const char* path) {
	int radix = 10000;
	/* if (global_system.Version() >= 2) */ radix *= 10;
	AvgKoeInfo info;
	info.stream = 0; info.length = 0; info.offset = 0;
	if (isdigit(path[0])) { // ����
		/* avg32 �����β������������֤Υ���å���򸡺� */
		int pointer = atoi(path);
		int file_no = pointer / radix;
		int index = pointer % radix;
		info = koe_cache.Find(file_no, index);
	} else { // �ե�����
		int length;
		ARCINFO* arcinfo = file_searcher.Find(FILESEARCH::KOE,path,".WPD");
		if (arcinfo == 0) return info;
		info.stream = arcinfo->OpenFile(&length);
		info.rate = 22050;
		info.length = length;
		info.offset = ftell(info.stream);
		delete arcinfo;
	}
	return info;
}


#if 0
/* Scn2k:: ¦�˻�������٤���ǽ */
void MuSys::WaitStopMovie(int is_click) {
	int pos;
	if (is_click) {
		SetMouseMode(0);
		ClearMouseInfo();
	}
	while(mus_movie_getStatus(&pos) != 0) {
		if (pos < 0) break;
		if (IsIntterupted()) break;
		if (is_click) {
			int x, y, flag;
			GetMouseInfo(x, y, flag);
			if (flag == 0 || flag == 2 || flag == 4) { // �ޥ����������줿�齪λ
				StopMovie();
			}
			ClearMouseInfo();
		}
		CallIdleEvent();
		CallProcessMessages();
		usleep(10000);
	}
	if (is_click) {
		ClearMouseInfo();
	}
}

void MuSys::WaitStopCDROM(void) {
	int dev;
	if (IsUseBGM()) {
		if (! pcm_enable) return;
		dev = MIX_PCM_BGM;
	} else {
		if (! cdrom_enable) return;
		dev = MIX_CD;
	}
	if (mus_mixer_get_fadeout_state(dev)) return;
	void* timer = setTimerBase();
	const int wait_time = 4000; // �ʤν�λ�ޤǡ����磴���Ԥ�
	while(mus_mixer_get_fadeout_state(dev) == 0 && getTime(timer) < wait_time && (!IsIntterupted()))  {
		CallIdleEvent();
		CallProcessMessages();
	}
	freeTimerBase(timer);
}
void MuSys::WaitStopWave(void) {
	if (! pcm_enable) return;
	void* timer = setTimerBase();
	const int wait_time = 10000; // �ʤν�λ�ޤǡ�����10���Ԥ�
	int pos;
	while(mus_effec_getStatus(&pos) != 0 && getTime(timer) < wait_time && (!IsIntterupted()))  {
		CallIdleEvent();
		CallProcessMessages();
	}
	freeTimerBase(timer);
}

void MuSys::WaitStopSE(void) {
	WaitStopWave();
}

#endif


/* system.cc �������Ū�˻��äƤ��� */
#include<unistd.h>
#include<sys/types.h>

static struct timeval tm_old;
void* MuSys::setTimerBase(void) {
	gettimeofday( &tm_old, 0);
	return 0;
}
int MuSys::getTime(void* tm_void) {
	struct timeval tm_new; gettimeofday(&tm_new,0);
	return (tm_new.tv_sec - tm_old.tv_sec)*1000 + (tm_new.tv_usec-tm_old.tv_usec)/1000;
}

void MuSys::freeTimerBase(void* tm_void) {
}

