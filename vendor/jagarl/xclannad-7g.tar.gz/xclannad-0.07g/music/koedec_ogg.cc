#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"music.h"
#include"wavfile.h"

extern "C" int is_koe_ogg(char* head);
extern "C" short* decode_koe_ogg(AvgKoeInfo info, int* dest_len);

extern "C" int is_koe_ogg(char* head) {
#if HAVE_LIBVORBISFILE
	if (strncmp(head, "OggS", 4) == 0) return 1;
#endif
	else return 0;
}

#if HAVE_LIBVORBISFILE

#include<vorbis/vorbisfile.h>

#define INITSIZE 65536

static int cur_size = 0;
static short* out = 0;
static void Resize(void) {
	short* new_out = (short*)realloc(out, cur_size+INITSIZE);
	if (new_out == 0) {
		new_out = (short*)malloc(cur_size+INITSIZE);
		memcpy(new_out, out, cur_size);
		free(out);
	}
	out = new_out;
	cur_size += INITSIZE;
}

struct OggInfo {
	FILE* stream;
	int length;
	int offset;
};
/* ogg stream �ɤ߹����Ѥ� dummy callback */
static size_t ogg_readfunc(void* ptr, size_t size, size_t nmemb, void* datasource) {
	OggInfo* info = (OggInfo*)datasource;
	int pt = ftell(info->stream) - info->offset;
	if (pt+size*nmemb > info->length) {
		nmemb = (info->length-pt) / size;
	}
	return fread(ptr, size, nmemb, info->stream);
}
static int ogg_seekfunc(void* datasource, ogg_int64_t new_offset, int whence) {
	int pt;
	OggInfo* info = (OggInfo*)datasource;
	if (whence == SEEK_SET) pt = info->offset + new_offset;
	else if (whence == SEEK_CUR) pt = ftell(info->stream) + new_offset;
	else if (whence == SEEK_END) pt = info->offset + info->length + new_offset;
	int r = fseek(info->stream, pt, 0);
	return r;
}
static long ogg_tellfunc(void* datasource) {
	OggInfo* info = (OggInfo*)datasource;
	int pos = ftell(info->stream);
	if (pos == -1) return -1;
	return pos-info->offset;
}
static int ogg_closefunc(void* datasource) {
	return 0;
}

extern "C" short* decode_koe_ogg(AvgKoeInfo info, int* dest_len) {
	if (info.stream == 0) return 0;
	// Voice �ե������ľ�ܻ��ꤹ��������ȥ꡼���������Ƥ��ޤ��Τ�
	// ɬ�פ���ʬ�����ڤ�Ф��� callback ��ͳ�ǵ���
	fseek(info.stream, info.offset, 0);

	ov_callbacks callback;
	callback.read_func = &ogg_readfunc;
	callback.seek_func = &ogg_seekfunc;
	callback.close_func = &ogg_closefunc;
	callback.tell_func = &ogg_tellfunc;

	OggInfo oinfo;
	oinfo.stream = info.stream;
	oinfo.length = info.length;
	oinfo.offset = info.offset;

	OggVorbis_File vf;
	int r = ov_open_callbacks((void*)&oinfo, &vf, 0, 0, callback);
	if (r != 0) {
		fprintf(stderr,"ogg stream err: %d\n",r);
		return 0;
	}
	vorbis_info* vinfo = ov_info(&vf, 0);
	info.rate = vinfo->rate;

	int cur = 0;
	cur_size = INITSIZE;
	out = (short*)malloc(cur_size);

	do {
		r = ov_read(&vf, ((char*)(out))+cur, cur_size-cur, 0, 2, 1, 0); 
		if (r <= 0) break;
		cur += r;
		if (cur_size-INITSIZE/4 < cur) Resize();
	} while(1);
	ov_clear(&vf);

	*dest_len = cur/4; // ���ޤ�����С��ȤǤ��Ƥ�Τ��ʤ��ġ�
	short* ret = out;
	out = 0;

	return ret;
}
struct OggFILE_impl {
	OggVorbis_File vf;
	ov_callbacks callback;
	OggInfo oinfo;
	OggFILE_impl(FILE*, int);
};

OggFILE_impl::OggFILE_impl(FILE* stream, int length) {
	callback.read_func = &ogg_readfunc;
	callback.seek_func = &ogg_seekfunc;
	callback.close_func = &ogg_closefunc;
	callback.tell_func = &ogg_tellfunc;
	oinfo.stream = stream;
	oinfo.length = length;
	oinfo.offset = ftell(stream);
}

OggFILE::OggFILE(FILE* stream, int len) {
	pimpl = new OggFILE_impl(stream, len);
	int r = ov_open_callbacks( (void*)&(pimpl->oinfo), &(pimpl->vf), 0, 0, pimpl->callback);
	if (r != 0) {
		delete pimpl;
		pimpl = 0;
		return;
	}
	vorbis_info* vinfo = ov_info(&(pimpl->vf), 0);
	wavinfo.SamplingRate = vinfo->rate;
	wavinfo.SamplingRate = 44100;
	wavinfo.Channels = vinfo->channels == 1 ? Mono : Stereo;
	wavinfo.Channels = Stereo;
	wavinfo.DataBits = 16;
	wavinfo.DataBytes = 0;
}
OggFILE::~OggFILE() {
	if (pimpl) {
		ov_clear(&(pimpl->vf));
		delete pimpl;
	}
}
int OggFILE::Read(char* buf, int blksize, int blklen) {
	if (pimpl == 0) return -1;
	int r = ov_read( &(pimpl->vf), buf, blksize*blklen, 0, 2, 1, 0);
	if (r <= 0) { // end of file
		ov_clear(&(pimpl->vf));
		delete pimpl;
		pimpl = 0;
	}
	return r / blksize;
}
void OggFILE::Seek(int count) {
	ov_pcm_seek(&(pimpl->vf), count);
	return;
}
#else
extern "C" short* decode_koe_ogg(AvgKoeInfo info, int* dest_len) {
	return 0;
}
OggFILE::OggFILE(FILE* stream) {}
OggFILE::~OggFILE(){}
void OggFILE::Seek(int count){}
int OggFILE::Read(char* buf, int blksize, int blklen){return -1;}
#endif
